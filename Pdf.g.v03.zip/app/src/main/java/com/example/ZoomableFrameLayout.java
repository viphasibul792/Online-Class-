package com.example;

import android.content.Context;
import android.util.AttributeSet;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;
import android.widget.FrameLayout;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

public class ZoomableFrameLayout extends FrameLayout {

    public interface OnZoomChangedListener {
        void onZoomChanged(float scale);
    }

    private ScaleGestureDetector scaleDetector;
    private GestureDetector gestureDetector;
    private OnZoomChangedListener zoomChangedListener;

    private float currentScale = 1.0f;
    private static final float MIN_SCALE = 1.0f; // 100% cannot shrink below 100%
    private static final float MAX_SCALE = 3.5f; // Capped max zoom

    private float focusX = 0f;
    private float focusY = 0f;
    private float lastTouchX = 0f;
    private float lastTouchY = 0f;
    private boolean isScaling = false;

    // Single-finger horizontal panning when zoomed (Point 2)
    private float singleTouchStartX = 0f;
    private float singleTouchStartY = 0f;
    private float singleInitialTransX = 0f;
    private boolean isSingleFingerPanning = false;

    public ZoomableFrameLayout(@NonNull Context context) {
        super(context);
        init(context);
    }

    public ZoomableFrameLayout(@NonNull Context context, @Nullable AttributeSet attrs) {
        super(context, attrs);
        init(context);
    }

    public ZoomableFrameLayout(@NonNull Context context, @Nullable AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(context);
    }

    private void init(Context context) {
        scaleDetector = new ScaleGestureDetector(context, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override
            public boolean onScale(ScaleGestureDetector detector) {
                float prevScale = currentScale;
                currentScale *= detector.getScaleFactor();
                currentScale = Math.max(MIN_SCALE, Math.min(currentScale, MAX_SCALE));

                focusX = detector.getFocusX();
                focusY = detector.getFocusY();

                applyScale();

                if (zoomChangedListener != null && Math.abs(prevScale - currentScale) > 0.01f) {
                    zoomChangedListener.onZoomChanged(currentScale);
                }
                return true;
            }

            @Override
            public boolean onScaleBegin(ScaleGestureDetector detector) {
                isScaling = true;
                return true;
            }

            @Override
            public void onScaleEnd(ScaleGestureDetector detector) {
                isScaling = false;
                if (currentScale < 1.05f) {
                    resetZoom();
                }
            }
        });

        gestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onDoubleTap(MotionEvent e) {
                if (currentScale > 1.05f) {
                    resetZoom();
                } else {
                    focusX = e.getX();
                    focusY = e.getY();
                    currentScale = 2.0f;
                    applyScale();
                    if (zoomChangedListener != null) {
                        zoomChangedListener.onZoomChanged(currentScale);
                    }
                }
                return true;
            }
        });
    }

    public void setOnZoomChangedListener(OnZoomChangedListener listener) {
        this.zoomChangedListener = listener;
    }

    public float getCurrentScale() {
        return currentScale;
    }

    public void resetZoom() {
        currentScale = 1.0f;
        isSingleFingerPanning = false;
        View target = getChildAt(0);
        if (target != null) {
            target.animate()
                    .scaleX(1.0f)
                    .scaleY(1.0f)
                    .translationX(0f)
                    .translationY(0f)
                    .setDuration(200)
                    .start();
        }
        if (zoomChangedListener != null) {
            zoomChangedListener.onZoomChanged(1.0f);
        }
    }

    private void applyScale() {
        View target = getChildAt(0);
        if (target != null) {
            target.setPivotX(focusX);
            target.setPivotY(focusY);
            target.setScaleX(currentScale);
            target.setScaleY(currentScale);
        }
    }

    @Override
    public boolean dispatchTouchEvent(MotionEvent ev) {
        // Detect double tap
        gestureDetector.onTouchEvent(ev);

        // Multi-touch pinch zoom & 2-finger panning
        if (ev.getPointerCount() >= 2) {
            isSingleFingerPanning = false;
            scaleDetector.onTouchEvent(ev);
            if (isScaling || currentScale > 1.05f) {
                int action = ev.getActionMasked();
                if (action == MotionEvent.ACTION_MOVE && ev.getPointerCount() >= 2) {
                    float currentX = (ev.getX(0) + ev.getX(1)) / 2f;
                    float currentY = (ev.getY(0) + ev.getY(1)) / 2f;
                    if (lastTouchX != 0f && lastTouchY != 0f) {
                        float dx = currentX - lastTouchX;
                        View target = getChildAt(0);
                        if (target != null && currentScale > 1.05f) {
                            clampAndTranslateX(target, target.getTranslationX() + dx);
                        }
                    }
                    lastTouchX = currentX;
                    lastTouchY = currentY;
                } else if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_POINTER_DOWN) {
                    lastTouchX = (ev.getX(0) + ev.getX(1)) / 2f;
                    lastTouchY = (ev.getY(0) + ev.getY(1)) / 2f;
                }
                return true;
            }
        } else if (ev.getPointerCount() == 1 && currentScale > 1.05f) {
            // Requirement 2: Single-finger panning left and right when zoomed in!
            View target = getChildAt(0);
            int action = ev.getActionMasked();

            switch (action) {
                case MotionEvent.ACTION_DOWN:
                    singleTouchStartX = ev.getX();
                    singleTouchStartY = ev.getY();
                    singleInitialTransX = (target != null) ? target.getTranslationX() : 0f;
                    isSingleFingerPanning = false;
                    break;

                case MotionEvent.ACTION_MOVE:
                    float dx = ev.getX() - singleTouchStartX;
                    float dy = ev.getY() - singleTouchStartY;

                    // If moving mostly horizontally or already horizontal panning
                    if (isSingleFingerPanning || (Math.abs(dx) > 15 && Math.abs(dx) > Math.abs(dy) * 0.7f)) {
                        isSingleFingerPanning = true;
                        getParent().requestDisallowInterceptTouchEvent(true);
                        if (target != null) {
                            clampAndTranslateX(target, singleInitialTransX + dx);
                        }
                        // Don't propagate horizontal pan to vertical recycler
                        return true;
                    }
                    break;

                case MotionEvent.ACTION_UP:
                case MotionEvent.ACTION_CANCEL:
                    if (isSingleFingerPanning) {
                        isSingleFingerPanning = false;
                        getParent().requestDisallowInterceptTouchEvent(false);
                        return true;
                    }
                    break;
            }
        } else {
            lastTouchX = 0f;
            lastTouchY = 0f;
            isSingleFingerPanning = false;
        }

        return super.dispatchTouchEvent(ev);
    }

    private void clampAndTranslateX(View target, float targetX) {
        float maxTravel = (currentScale - 1.0f) * (getWidth() > 0 ? getWidth() : 1080) * 0.65f;
        float clampedX = Math.max(-maxTravel, Math.min(targetX, maxTravel));
        target.setTranslationX(clampedX);
    }
}
