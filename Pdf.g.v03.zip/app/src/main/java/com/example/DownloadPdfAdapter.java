package com.example;

import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.button.MaterialButton;
import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class DownloadPdfAdapter extends RecyclerView.Adapter<DownloadPdfAdapter.ViewHolder> implements PdfDownloadHelper.DownloadStateListener {

    public interface OnDownloadActionListener {
        void onReadClick(UrlPdfItem item, ViewHolder holder);
        void onDeleteClick(UrlPdfItem item);
        void onChangeThumbnailClick(UrlPdfItem item);
    }

    private final Context context;
    private final List<UrlPdfItem> items = new ArrayList<>();
    private final OnDownloadActionListener listener;
    private RecyclerView attachedRecyclerView;
    private final ExecutorService thumbnailExecutor = Executors.newFixedThreadPool(2);
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    public DownloadPdfAdapter(Context context, OnDownloadActionListener listener) {
        this.context = context;
        this.listener = listener;
        PdfDownloadHelper.getInstance(context).addStateListener(this);
    }

    @Override
    public void onAttachedToRecyclerView(@NonNull RecyclerView recyclerView) {
        super.onAttachedToRecyclerView(recyclerView);
        this.attachedRecyclerView = recyclerView;
    }

    @Override
    public void onDetachedFromRecyclerView(@NonNull RecyclerView recyclerView) {
        super.onDetachedFromRecyclerView(recyclerView);
        this.attachedRecyclerView = null;
    }

    public void unregisterListener() {
        PdfDownloadHelper.getInstance(context).removeStateListener(this);
    }

    public void setItems(List<UrlPdfItem> newItems) {
        items.clear();
        if (newItems != null) {
            items.addAll(newItems);
        }
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_download_pdf, parent, false);
        return new ViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        UrlPdfItem item = items.get(position);

        holder.tvUrlPdfTitle.setText(item.getTitle());

        // Cover thumbnail
        holder.ivUrlPdfThumbnail.setOnClickListener(v -> {
            if (listener != null) {
                listener.onChangeThumbnailClick(item);
            }
        });

        if (item.getCoverImagePath() != null && new File(item.getCoverImagePath()).exists()) {
            Bitmap bmp = BitmapFactory.decodeFile(item.getCoverImagePath());
            if (bmp != null) {
                holder.ivUrlPdfThumbnail.setImageBitmap(bmp);
            } else {
                holder.ivUrlPdfThumbnail.setImageResource(R.drawable.ic_pdf_file);
            }
        } else if (item.isDownloaded() && item.getLocalFilePath() != null && new File(item.getLocalFilePath()).exists()) {
            holder.ivUrlPdfThumbnail.setImageResource(R.drawable.ic_pdf_file);
            thumbnailExecutor.execute(() -> {
                File localFile = new File(item.getLocalFilePath());
                String thumbPath = PdfUtils.generateAndSaveFirstPageThumbnail(context, localFile, item.getId());
                if (thumbPath != null) {
                    item.setCoverImagePath(thumbPath);
                    new UrlPdfManager(context).updateCoverImagePath(item.getId(), thumbPath);
                    Bitmap bmp = BitmapFactory.decodeFile(thumbPath);
                    if (bmp != null) {
                        mainHandler.post(() -> {
                            if (holder.getBindingAdapterPosition() == position) {
                                holder.ivUrlPdfThumbnail.setImageBitmap(bmp);
                            }
                        });
                    }
                }
            });
        } else {
            holder.ivUrlPdfThumbnail.setImageResource(R.drawable.ic_pdf_file);
        }

        boolean isDownloaded = item.isDownloaded() && item.getLocalFilePath() != null && new File(item.getLocalFilePath()).exists();
        boolean isDownloading = PdfDownloadHelper.getInstance(context).isDownloading(item.getId());
        PdfDownloadHelper.DownloadProgressState progressState = PdfDownloadHelper.getInstance(context).getProgressState(item.getId());

        if (isDownloading) {
            holder.layoutDownloadProgress.setVisibility(View.VISIBLE);
            holder.tvUrlPdfStatus.setText("গুগল ড্রাইভ থেকে ডাউনলোড হচ্ছে...");
            holder.btnActionRead.setEnabled(false);
            holder.btnActionRead.setText("Wait");
            holder.btnActionRead.setBackgroundTintList(ContextCompat.getColorStateList(context, R.color.primary));

            int pct = (progressState != null) ? progressState.percent : 0;
            long cur = (progressState != null) ? progressState.downloadedBytes : 0;
            long total = (progressState != null) ? progressState.totalBytes : -1;

            holder.pbDownload.setProgress(Math.max(0, pct));
            String curMb = PdfDownloadHelper.formatBanglaSize(cur);
            if (total > 0) {
                String totalMb = PdfDownloadHelper.formatBanglaSize(total);
                holder.tvDownloadBytesProgress.setText(curMb + " / " + totalMb);
                holder.tvDownloadPercent.setText(PdfDownloadHelper.toBanglaDigits(String.valueOf(pct)) + "%");
            } else {
                holder.tvDownloadBytesProgress.setText(curMb);
                holder.tvDownloadPercent.setText("ডাউনলোড হচ্ছে...");
            }
        } else if (progressState != null && progressState.isPaused && progressState.downloadedBytes > 0 && !isDownloaded) {
            // Paused / partially downloaded state (Breakpoint saved!)
            holder.layoutDownloadProgress.setVisibility(View.VISIBLE);
            int pct = progressState.percent;
            long cur = progressState.downloadedBytes;
            long total = progressState.totalBytes;

            holder.pbDownload.setProgress(Math.max(0, pct));
            String curMb = PdfDownloadHelper.formatBanglaSize(cur);
            if (total > 0) {
                String totalMb = PdfDownloadHelper.formatBanglaSize(total);
                holder.tvDownloadBytesProgress.setText(curMb + " / " + totalMb);
                holder.tvDownloadPercent.setText("স্থগিত (" + PdfDownloadHelper.toBanglaDigits(String.valueOf(pct)) + "%)");
            } else {
                holder.tvDownloadBytesProgress.setText(curMb);
                holder.tvDownloadPercent.setText("স্থগিত");
            }

            holder.tvUrlPdfStatus.setText("ডাউনলোড স্থগিত ছিল • ট্যাপ করলে এখান থেকেই শুরু হবে");
            holder.btnActionRead.setEnabled(true);
            holder.btnActionRead.setText("Resume");
            holder.btnActionRead.setBackgroundTintList(ContextCompat.getColorStateList(context, R.color.primary));
        } else if (isDownloaded) {
            holder.layoutDownloadProgress.setVisibility(View.GONE);
            holder.tvUrlPdfStatus.setText("Downloaded • অফলাইনে পড়ার জন্য প্রস্তুত");
            holder.btnActionRead.setEnabled(true);
            holder.btnActionRead.setText("Read");
            holder.btnActionRead.setBackgroundTintList(ContextCompat.getColorStateList(context, R.color.emerald_green));
        } else {
            holder.layoutDownloadProgress.setVisibility(View.GONE);
            holder.tvUrlPdfStatus.setText("Google Drive Link • ট্যাপ করে ডাউনলোড করুন");
            holder.btnActionRead.setEnabled(true);
            holder.btnActionRead.setText("Download");
            holder.btnActionRead.setBackgroundTintList(ContextCompat.getColorStateList(context, R.color.primary));
        }

        // Cancel download button click ("বাতিল করুন")
        holder.btnCancelDownload.setOnClickListener(v -> {
            PdfDownloadHelper.getInstance(context).cancelDownload(item.getId());
            Toast.makeText(context, "ডাউনলোড স্থগিত করা হয়েছে। পরবর্তীতে পুনরায় শুরু করা যাবে।", Toast.LENGTH_SHORT).show();
            notifyItemChanged(holder.getBindingAdapterPosition());
        });

        // Copy Link Action: Copies the PDF link to clipboard and notifies user
        holder.btnCopyUrlItem.setOnClickListener(v -> {
            String linkToCopy = item.getOriginalUrl();
            if (linkToCopy == null || linkToCopy.isEmpty()) {
                linkToCopy = item.getDownloadUrl();
            }
            if (linkToCopy != null && !linkToCopy.isEmpty()) {
                ClipboardManager clipboard = (ClipboardManager) context.getSystemService(Context.CLIPBOARD_SERVICE);
                ClipData clip = ClipData.newPlainText("PDF Link", linkToCopy);
                if (clipboard != null) {
                    clipboard.setPrimaryClip(clip);
                }
                Toast.makeText(context, "PDF লিংক কপি করা হয়েছে!", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(context, "কপি করার মতো লিংক পাওয়া যায়নি", Toast.LENGTH_SHORT).show();
            }
        });

        // Delete Item Action
        holder.btnDeleteUrlItem.setOnClickListener(v -> {
            if (listener != null) {
                listener.onDeleteClick(item);
            }
        });

        // Read / Download / Resume Button Click
        holder.btnActionRead.setOnClickListener(v -> {
            if (listener != null) {
                listener.onReadClick(item, holder);
            }
        });
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    // Dynamic state listener methods to update UI seamlessly in real time
    @Override
    public void onDownloadProgress(String itemId, int percent, long downloadedBytes, long totalBytes) {
        int pos = findItemPosition(itemId);
        if (pos != -1 && attachedRecyclerView != null) {
            RecyclerView.ViewHolder vh = attachedRecyclerView.findViewHolderForAdapterPosition(pos);
            if (vh instanceof ViewHolder) {
                ViewHolder holder = (ViewHolder) vh;
                holder.layoutDownloadProgress.setVisibility(View.VISIBLE);
                holder.pbDownload.setProgress(Math.max(0, percent));
                String curMb = PdfDownloadHelper.formatBanglaSize(downloadedBytes);
                if (totalBytes > 0) {
                    String totalMb = PdfDownloadHelper.formatBanglaSize(totalBytes);
                    holder.tvDownloadBytesProgress.setText(curMb + " / " + totalMb);
                    holder.tvDownloadPercent.setText(PdfDownloadHelper.toBanglaDigits(String.valueOf(percent)) + "%");
                } else {
                    holder.tvDownloadBytesProgress.setText(curMb);
                    holder.tvDownloadPercent.setText("ডাউনলোড হচ্ছে...");
                }
                holder.btnActionRead.setEnabled(false);
                holder.btnActionRead.setText("Wait");
                holder.tvUrlPdfStatus.setText("গুগল ড্রাইভ থেকে ডাউনলোড হচ্ছে...");
            }
        }
    }

    @Override
    public void onDownloadSuccess(String itemId, File file) {
        int pos = findItemPosition(itemId);
        if (pos != -1) {
            UrlPdfItem item = items.get(pos);
            item.setDownloaded(true);
            item.setLocalFilePath(file.getAbsolutePath());
            item.setFileSize(file.length());
            if (item.getCoverImagePath() == null || !new File(item.getCoverImagePath()).exists()) {
                String thumb = PdfUtils.generateAndSaveFirstPageThumbnail(context, file, item.getId());
                if (thumb != null) {
                    item.setCoverImagePath(thumb);
                    new UrlPdfManager(context).updateCoverImagePath(item.getId(), thumb);
                }
            }
            notifyItemChanged(pos);
        }
    }

    @Override
    public void onDownloadError(String itemId, String errorMessage) {
        int pos = findItemPosition(itemId);
        if (pos != -1) {
            notifyItemChanged(pos);
        }
    }

    @Override
    public void onDownloadPausedOrCancelled(String itemId, long downloadedBytes, long totalBytes) {
        int pos = findItemPosition(itemId);
        if (pos != -1) {
            notifyItemChanged(pos);
        }
    }

    private int findItemPosition(String itemId) {
        if (itemId == null) return -1;
        for (int i = 0; i < items.size(); i++) {
            if (itemId.equals(items.get(i).getId())) {
                return i;
            }
        }
        return -1;
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        public ImageView ivUrlPdfThumbnail;
        public TextView tvUrlPdfTitle;
        public TextView tvUrlPdfStatus;
        public View layoutDownloadProgress;
        public ProgressBar pbDownload;
        public TextView tvDownloadBytesProgress;
        public TextView tvDownloadPercent;
        public TextView btnCancelDownload;
        public MaterialButton btnActionRead;
        public ImageButton btnCopyUrlItem;
        public ImageButton btnDeleteUrlItem;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            ivUrlPdfThumbnail = itemView.findViewById(R.id.ivUrlPdfThumbnail);
            tvUrlPdfTitle = itemView.findViewById(R.id.tvUrlPdfTitle);
            tvUrlPdfStatus = itemView.findViewById(R.id.tvUrlPdfStatus);
            layoutDownloadProgress = itemView.findViewById(R.id.layoutDownloadProgress);
            pbDownload = itemView.findViewById(R.id.pbDownload);
            tvDownloadBytesProgress = itemView.findViewById(R.id.tvDownloadBytesProgress);
            tvDownloadPercent = itemView.findViewById(R.id.tvDownloadPercent);
            btnCancelDownload = itemView.findViewById(R.id.btnCancelDownload);
            btnActionRead = itemView.findViewById(R.id.btnActionRead);
            btnCopyUrlItem = itemView.findViewById(R.id.btnCopyUrlItem);
            btnDeleteUrlItem = itemView.findViewById(R.id.btnDeleteUrlItem);
        }
    }
}
