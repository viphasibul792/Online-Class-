package com.example;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Bitmap;
import android.graphics.PixelFormat;
import android.net.Uri;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.ContextThemeWrapper;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.WindowManager;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.widget.ImageButton;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;

import java.io.File;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Shows a small "PDF Gallery" bar at the very top of the screen, on top of the real Google Lens
 * screen. The ◀ / ▶ buttons render the previous / next PDF page and hand it straight to Google
 * Lens again, so the user can browse the PDF page by page without going back into the app.
 */
public class LensNavigatorService extends Service {

    public static final String ACTION_STOP = "com.example.LENS_NAV_STOP";
    public static final String EXTRA_PDF_PATH = "lens_nav_pdf_path";
    public static final String EXTRA_PDF_URI = "lens_nav_pdf_uri";
    public static final String EXTRA_PAGE_INDEX = "lens_nav_page_index";
    public static final String EXTRA_TOTAL_PAGES = "lens_nav_total_pages";
    /** Identifier the Unlimited Note uses for this PDF (same value PdfNotesDialog receives). */
    public static final String EXTRA_NOTE_ID = "lens_nav_note_id";
    public static final String EXTRA_PDF_NAME = "lens_nav_pdf_name";

    private static final String CHANNEL_ID = "pdf_lens_navigator_channel";
    private static final int NOTIFICATION_ID = 2002;
    private static final int RENDER_WIDTH = 1600;
    /** Placed on the clipboard before Lens copies, so a failed copy is never mistaken for page text. */
    private static final String CLIP_SENTINEL = "\u200B__PDFGALLERY_LENS_PENDING__\u200B";
    private static final long LENS_COPY_TIMEOUT_MS = 20000;
    private static final int MAX_RETRIES = 3;
    private static final long LENS_SETTLE_MS = 450;

    public static boolean isRunning = false;
    private static volatile LensNavigatorService instance;

    /** Hides / shows the floating bar (hidden while the Unlimited Note screen is on top). */
    public static void setBarVisible(boolean visible) {
        final LensNavigatorService svc = instance;
        if (svc == null) return;
        svc.mainHandler.post(() -> {
            if (svc.barView != null) svc.barView.setVisibility(visible ? View.VISIBLE : View.GONE);
        });
    }

    private final ExecutorService agentExecutor = Executors.newSingleThreadExecutor();
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    /** Renders the NEXT page while Lens is still copying the current one. */
    private final ExecutorService prefetchExecutor = Executors.newSingleThreadExecutor();
    private Future<File> prefetchFuture;
    private int prefetchPage = -1;
    private String lastAgentText = "";
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    private WindowManager windowManager;
    private View barView;
    private TextView tvPageInfo;
    private ImageButton btnPrev;
    private ImageButton btnNext;
    private ImageButton btnNote;
    private ImageButton btnCopy;
    private ImageButton btnAgent;
    private ImageButton btnStopAgent;
    private View layoutAgentPanel;
    private TextView tvAgentTitle;
    private TextView tvAgentPage;
    private TextView tvAgentCompleted;
    private TextView tvAgentStatus;
    private ProgressBar pbAgent;

    private PdfNotesManager notesManager;
    private String noteId;
    private String pdfName;
    private String busyLabel = "লোড হচ্ছে…";
    private volatile boolean agentRunning = false;
    private volatile boolean stopRequested = false;
    private int agentCompleted = 0;
    private PowerManager.WakeLock wakeLock;

    private String pdfPath;
    private Uri pdfUri;
    private int currentPage = 0;   // 0-based
    private int totalPages = 0;
    private boolean busy = false;
    private File lastImage;

    @Override
    public void onCreate() {
        super.onCreate();
        isRunning = true;
        instance = this;
        notesManager = new PdfNotesManager(getApplicationContext());
        createNotificationChannel();
        startAsForeground();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (!Settings.canDrawOverlays(this)) {
            stopSelf();
            return START_NOT_STICKY;
        }
        if (intent != null) {
            pdfPath = intent.getStringExtra(EXTRA_PDF_PATH);
            String uriStr = intent.getStringExtra(EXTRA_PDF_URI);
            pdfUri = uriStr != null ? Uri.parse(uriStr) : null;
            currentPage = intent.getIntExtra(EXTRA_PAGE_INDEX, 0);
            totalPages = intent.getIntExtra(EXTRA_TOTAL_PAGES, 0);
            String id = intent.getStringExtra(EXTRA_NOTE_ID);
            if (id != null) noteId = id;
            String name = intent.getStringExtra(EXTRA_PDF_NAME);
            if (name != null) pdfName = name;
        }
        if (pdfUri == null && pdfPath != null) {
            pdfUri = Uri.fromFile(new File(pdfPath));
        }
        if (noteId == null) {
            noteId = pdfPath != null ? pdfPath : (pdfName != null ? pdfName : "current_pdf");
        }
        if (totalPages <= 0 && pdfUri != null) {
            totalPages = PdfUtils.getPageCount(this, pdfUri);
        }
        showBar();
        updateUi();
        return START_NOT_STICKY;
    }

    private void showBar() {
        if (barView != null) return;
        try {
            windowManager = (WindowManager) getSystemService(Context.WINDOW_SERVICE);
            ContextThemeWrapper themed = new ContextThemeWrapper(this, R.style.Theme_MyApplication);
            barView = LayoutInflater.from(themed).inflate(R.layout.layout_lens_nav_bar, null);

            tvPageInfo = barView.findViewById(R.id.tvLensNavPage);
            btnPrev = barView.findViewById(R.id.btnLensNavPrev);
            btnNext = barView.findViewById(R.id.btnLensNavNext);
            View btnClose = barView.findViewById(R.id.btnLensNavClose);
            btnNote = barView.findViewById(R.id.btnLensNavNote);
            btnCopy = barView.findViewById(R.id.btnLensNavCopy);
            btnAgent = barView.findViewById(R.id.btnLensNavAgent);
            btnStopAgent = barView.findViewById(R.id.btnLensNavStopAgent);
            layoutAgentPanel = barView.findViewById(R.id.layoutAgentPanel);
            tvAgentTitle = barView.findViewById(R.id.tvAgentTitle);
            tvAgentPage = barView.findViewById(R.id.tvAgentPage);
            tvAgentCompleted = barView.findViewById(R.id.tvAgentCompleted);
            tvAgentStatus = barView.findViewById(R.id.tvAgentStatus);
            pbAgent = barView.findViewById(R.id.pbAgent);

            // Narrow phones: drop the small logo so the page number never collides with the icons
            if (getResources().getConfiguration().screenWidthDp < 380) {
                View logo = barView.findViewById(R.id.ivLensNavLogo);
                if (logo != null) logo.setVisibility(View.GONE);
            }

            btnPrev.setOnClickListener(v -> goToPage(currentPage - 1));
            btnNext.setOnClickListener(v -> goToPage(currentPage + 1));
            btnClose.setOnClickListener(v -> stopSelf());
            btnNote.setOnClickListener(v -> onNoteClicked());
            btnCopy.setOnClickListener(v -> onCopyClicked());
            btnAgent.setOnClickListener(v -> startAgent());
            btnStopAgent.setOnClickListener(v -> requestStopAgent());

            int type = Build.VERSION.SDK_INT >= Build.VERSION_CODES.O
                    ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                    : WindowManager.LayoutParams.TYPE_PHONE;

            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.MATCH_PARENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    type,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL
                            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                    PixelFormat.TRANSLUCENT);
            lp.gravity = Gravity.TOP | Gravity.START;
            lp.x = 0;
            lp.y = getStatusBarHeight();
            windowManager.addView(barView, lp);
        } catch (Exception e) {
            e.printStackTrace();
            barView = null;
            stopSelf();
        }
    }

    private int getStatusBarHeight() {
        int id = getResources().getIdentifier("status_bar_height", "dimen", "android");
        return id > 0 ? getResources().getDimensionPixelSize(id) : 0;
    }

    private void updateUi() {
        if (tvPageInfo == null) return;
        if (busy) {
            tvPageInfo.setText(busyLabel);
        } else if (totalPages > 0) {
            tvPageInfo.setText(PdfUtils.toBengaliDigits("পৃষ্ঠা " + (currentPage + 1) + " / " + totalPages));
        } else {
            tvPageInfo.setText(PdfUtils.toBengaliDigits("পৃষ্ঠা " + (currentPage + 1)));
        }
        boolean idle = !busy && !agentRunning;
        setEnabledAlpha(btnPrev, idle && currentPage > 0);
        setEnabledAlpha(btnNext, idle && (totalPages <= 0 || currentPage < totalPages - 1));
        setEnabledAlpha(btnNote, idle);
        setEnabledAlpha(btnCopy, idle);
        setEnabledAlpha(btnAgent, !busy);
    }

    private void setEnabledAlpha(View v, boolean enabled) {
        v.setEnabled(enabled);
        v.setAlpha(enabled ? 1f : 0.35f);
    }

    private void goToPage(int target) {
        if (busy || agentRunning || pdfUri == null) return;
        if (target < 0 || (totalPages > 0 && target >= totalPages)) return;
        busy = true;
        updateUi();

        final Uri uri = pdfUri;
        executor.execute(() -> {
            Bitmap bmp = PdfUtils.renderPageToBitmap(getApplicationContext(), uri, target, RENDER_WIDTH);
            File file = bmp != null
                    ? PdfUtils.saveBitmapJpegToCache(getApplicationContext(), bmp, "lens_page_" + (target + 1) + "_")
                    : null;
            if (bmp != null) bmp.recycle();

            mainHandler.post(() -> {
                busy = false;
                if (file == null) {
                    Toast.makeText(this, "পেজ রেন্ডার করা যায়নি", Toast.LENGTH_SHORT).show();
                    updateUi();
                    return;
                }
                boolean launched = PdfUtils.launchOfficialGoogleLens(getApplicationContext(), file.getAbsolutePath());
                if (launched) {
                    currentPage = target;
                    if (lastImage != null && !lastImage.equals(file)) {
                        // previous page image is no longer needed
                        //noinspection ResultOfMethodCallIgnored
                        lastImage.delete();
                    }
                    lastImage = file;
                } else {
                    Toast.makeText(this, "Google Lens চালু করা যায়নি", Toast.LENGTH_SHORT).show();
                }
                updateUi();
            });
        });
    }


    // ---------------------------------------------------------------------
    // Feature 1: Note icon -> straight to the Unlimited Note editor
    // ---------------------------------------------------------------------
    private void onNoteClicked() {
        if (agentRunning) {
            Toast.makeText(this, "Agent চলছে — নোট খুলতে আগে Stop করুন", Toast.LENGTH_SHORT).show();
            return;
        }
        if (busy) return;
        openNoteScreen();
    }

    private void openNoteScreen() {
        setBarVisible(false);
        try {
            LensNoteActivity.launch(getApplicationContext(), noteId, pdfName);
        } catch (Exception e) {
            e.printStackTrace();
            setBarVisible(true);
            Toast.makeText(this, "নোট খোলা যায়নি", Toast.LENGTH_SHORT).show();
        }
    }

    // ---------------------------------------------------------------------
    // Feature 2: Copy icon -> Google Lens "Select text" + "Copy text" -> paste into Unlimited Note
    // ---------------------------------------------------------------------
    private void onCopyClicked() {
        if (busy || agentRunning || pdfUri == null) return;
        if (!ensureLensAccessibility()) return;
        final int page = currentPage;
        busy = true;
        busyLabel = "Lens থেকে লেখা কপি হচ্ছে…";
        updateUi();

        executor.execute(() -> {
            String message;
            boolean openNote = false;
            try {
                if (notesManager.isPagePasted(noteId, page)) {
                    message = "পৃষ্ঠা " + (page + 1) + " আগেই নোটে যুক্ত আছে";
                    openNote = true;
                } else {
                    // Google Lens page: tap "Select text" -> "Copy text" -> read clipboard
                    String text = grabTextFromLens();
                    if (text.isEmpty()) {
                        message = "Lens থেকে লেখা কপি করা যায়নি — Lens পেজে \"Select text\" বাটন আছে কিনা দেখুন";
                    } else if (appendWithRetry(page, text)) {
                        message = "✓ পৃষ্ঠা " + (page + 1) + " কপি হয়ে নোটে যুক্ত হয়েছে";
                        openNote = true;
                    } else {
                        message = "নোটে যুক্ত করা যায়নি (লেখা ক্লিপবোর্ডে কপি আছে)";
                    }
                }
            } catch (Exception e) {
                e.printStackTrace();
                message = "Lens থেকে টেক্সট কপি করা যায়নি";
            }

            final String toast = message;
            final boolean open = openNote;
            mainHandler.post(() -> {
                busy = false;
                busyLabel = "লোড হচ্ছে…";
                updateUi();
                Toast.makeText(this, toast, Toast.LENGTH_SHORT).show();
                if (open) openNoteScreen();
            });
        });
    }

    /** The accessibility service must be on, otherwise open its settings page. */
    private boolean ensureLensAccessibility() {
        if (LensAccessibilityService.get() != null) return true;
        Toast.makeText(this,
                "Accessibility তে \"PDF Gallery – Lens Auto Copy\" চালু করুন, তারপর আবার কপি চাপুন",
                Toast.LENGTH_LONG).show();
        try {
            Intent i = new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
        } catch (Exception ignored) {}
        return false;
    }

    /**
     * Runs on a BACKGROUND thread. Makes the real Google Lens screen select + copy all of its text
     * and returns that text ("" if it could not be copied).
     */
    private String grabTextFromLens() {
        final LensAccessibilityService acc = LensAccessibilityService.get();
        if (acc == null) return "";

        // 1) sentinel on the clipboard (so we can tell "Lens copied" from "old clipboard")
        final CountDownLatch primed = new CountDownLatch(1);
        mainHandler.post(() -> {
            try {
                ClipboardManager cb = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
                if (cb != null) cb.setPrimaryClip(ClipData.newPlainText("pdfgallery", CLIP_SENTINEL));
            } catch (Exception ignored) {}
            primed.countDown();
        });
        awaitQuietly(primed, 2);

        // 2) Lens: "Select text" -> "Copy text"
        boolean copied = acc.copyAllLensText(LENS_COPY_TIMEOUT_MS, () -> stopRequested);
        if (!copied) return "";

        // 3a) fastest: read the clipboard straight from the accessibility service (no screen flash)
        String direct = acc.readClipboardDirect().trim();
        if (!direct.isEmpty() && !direct.contains("__PDFGALLERY_LENS_PENDING__")) return direct;

        // 3b) otherwise read it from a focused (invisible) window
        final CountDownLatch got = new CountDownLatch(1);
        final AtomicReference<String> ref = new AtomicReference<>("");
        ClipboardGrabActivity.pending = t -> { ref.set(t == null ? "" : t); got.countDown(); };
        mainHandler.post(() -> {
            try {
                ClipboardGrabActivity.launch(getApplicationContext());
            } catch (Exception e) {
                got.countDown();
            }
        });
        awaitQuietly(got, 6);

        String text = ref.get().trim();
        if (text.contains("__PDFGALLERY_LENS_PENDING__")) return ""; // Lens never replaced the sentinel
        return text;
    }

    private void awaitQuietly(CountDownLatch latch, long seconds) {
        try {
            latch.await(seconds, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            stopRequested = true;
        }
    }

    /** Appends to the Unlimited Note and verifies. Already-pasted pages count as success. */
    private boolean appendWithRetry(int page, String text) {
        for (int i = 0; i < MAX_RETRIES; i++) {
            if (notesManager.appendPageToUnlimitedNote(noteId, page, text)) return true;
            if (notesManager.isPagePasted(noteId, page)) return true; // duplicate guard hit
            sleepQuietly(300L * (i + 1));
        }
        return false;
    }

    // ---------------------------------------------------------------------
    // Feature 3/4/5: Auto Agent, Stop button and progress indicator
    // ---------------------------------------------------------------------
    private void startAgent() {
        if (agentRunning || busy || pdfUri == null) return;
        if (totalPages <= 0) totalPages = PdfUtils.getPageCount(this, pdfUri);
        agentRunning = true;
        stopRequested = false;
        agentCompleted = 0;
        acquireWakeLock();
        showAgentRunningUi();
        agentExecutor.execute(this::runAgent);
    }

    private void requestStopAgent() {
        if (!agentRunning || stopRequested) return;
        stopRequested = true;
        setAgentStatus("Stopping...");
        btnStopAgent.setEnabled(false);
        btnStopAgent.setAlpha(0.5f);
    }

    private void runAgent() {
        final int total = totalPages;
        String endTitle = "🤖 Agent Stopped";
        String endStatus = "Stopped";
        boolean finishedAll = false;
        try {
            if (notesManager.wasAgentInterrupted(noteId)) {
                mainHandler.post(() -> Toast.makeText(this,
                        "আগের অসমাপ্ত কাজ থেকে চালিয়ে যাওয়া হচ্ছে", Toast.LENGTH_SHORT).show());
            }
            notesManager.saveAgentProgress(noteId, notesManager.getAgentLastCompleted(noteId), true);

            if (LensAccessibilityService.get() == null) {
                throw new AgentFailure("Accessibility সার্ভিস চালু নেই");
            }
            setAgentStatus("Reading PDF Page");

            // Never process a page twice: jump over pages already pasted in an earlier run.
            int page = nextUnprocessed(currentPage, total);
            if (page < total && page != currentPage) {
                if (!loadPage(page, true)) throw new AgentFailure("পৃষ্ঠা " + (page + 1) + " লোড করা যায়নি");
            }

            while (page < total && !stopRequested) {
                setAgentPage(page);

                // Lens page: Select text -> Copy text -> read clipboard
                setAgentStatus("Selecting & Copying Text in Lens");
                startPrefetch(nextUnprocessed(page + 1, total)); // render next page in parallel
                String text = grabTextFromLens();
                if (!text.isEmpty() && text.equals(lastAgentText) && !stopRequested) {
                    // Lens still showed the previous page -> wait a moment and copy again
                    sleepQuietly(1200);
                    text = grabTextFromLens();
                    if (text.equals(lastAgentText)) text = "";
                }
                if (!text.isEmpty()) lastAgentText = text;
                if (stopRequested) break; // nothing pasted for this page; it stays unprocessed

                if (!text.isEmpty()) {
                    setAgentStatus("Opening Unlimited Note");
                    String existing = notesManager.getUnlimitedNoteForPdf(noteId); // loads the note data source
                    if (existing == null) throw new AgentFailure("Unlimited Note খোলা যায়নি");
                    setAgentStatus("Pasting Text");
                    if (!appendWithRetry(page, text)) {
                        throw new AgentFailure("পৃষ্ঠা " + (page + 1) + " নোটে পেস্ট করা যায়নি");
                    }
                }
                agentCompleted++;
                notesManager.saveAgentProgress(noteId, page, true);
                setAgentCompleted();
                if (stopRequested) break;

                int next = nextUnprocessed(page + 1, total);
                if (next >= total) {
                    page = total;
                    break;
                }
                setAgentStatus("Loading Next Page");
                if (!loadPage(next, true)) throw new AgentFailure("পৃষ্ঠা " + (next + 1) + " লোড করা যায়নি");
                page = next;
            }

            finishedAll = !stopRequested && page >= total;
            if (finishedAll) {
                endTitle = "🤖 Agent Finished";
                endStatus = "All Pages Successfully Processed!";
                setAgentStatus("Completed");
                notesManager.saveAgentProgress(noteId, total - 1, false);
            } else {
                notesManager.saveAgentProgress(noteId, notesManager.getAgentLastCompleted(noteId), false);
            }
        } catch (AgentFailure f) {
            endTitle = "🤖 Agent Paused";
            endStatus = f.getMessage() + " — আবার Agent চালু করুন";
            notesManager.saveAgentProgress(noteId, notesManager.getAgentLastCompleted(noteId), false);
        } catch (Throwable t) {
            t.printStackTrace();
            endTitle = "🤖 Agent Paused";
            endStatus = "ত্রুটি হয়েছে — আবার Agent চালু করুন";
            notesManager.saveAgentProgress(noteId, notesManager.getAgentLastCompleted(noteId), false);
        }

        final String title = endTitle;
        final String status = endStatus;
        final boolean done = finishedAll;
        mainHandler.post(() -> showAgentEndedUi(title, status, done));
    }

    private static class AgentFailure extends RuntimeException {
        AgentFailure(String msg) { super(msg); }
    }

    private int nextUnprocessed(int from, int total) {
        java.util.Set<Integer> pasted = notesManager.getPastedPages(noteId);
        // If the note was cleared, old marks are meaningless
        if (!pasted.isEmpty() && notesManager.getUnlimitedNoteForPdf(noteId).trim().isEmpty()) {
            notesManager.clearPastedPages(noteId);
            pasted.clear();
        }
        int p = Math.max(0, from);
        while (p < total && pasted.contains(p)) p++;
        return p;
    }

    private void startPrefetch(int page) {
        if (pdfUri == null || page < 0 || (totalPages > 0 && page >= totalPages)) return;
        final Uri uri = pdfUri;
        prefetchPage = page;
        prefetchFuture = prefetchExecutor.submit(() -> renderLensImage(uri, page));
    }

    private File renderLensImage(Uri uri, int page) {
        Bitmap bmp = PdfUtils.renderPageToBitmap(getApplicationContext(), uri, page, RENDER_WIDTH);
        if (bmp == null) return null;
        try {
            return PdfUtils.saveBitmapJpegToCache(getApplicationContext(), bmp, "lens_page_" + (page + 1) + "_");
        } finally {
            bmp.recycle();
        }
    }

    /** Opens the page in Google Lens (image usually already prepared by {@link #startPrefetch}). */
    private boolean loadPage(int page, boolean showInLens) {
        if (showInLens) {
            File file = null;
            if (prefetchFuture != null && prefetchPage == page) {
                try {
                    file = prefetchFuture.get(8, TimeUnit.SECONDS);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                    stopRequested = true;
                } catch (ExecutionException | java.util.concurrent.TimeoutException ignored) {}
                prefetchFuture = null;
                prefetchPage = -1;
            }
            for (int i = 0; i < MAX_RETRIES && file == null && !stopRequested; i++) {
                file = renderLensImage(pdfUri, page);
                if (file == null) sleepQuietly(300L * (i + 1));
            }
            if (file == null) return false;
            if (PdfUtils.launchOfficialGoogleLens(getApplicationContext(), file.getAbsolutePath())) {
                if (lastImage != null && !lastImage.equals(file)) {
                    //noinspection ResultOfMethodCallIgnored
                    lastImage.delete();
                }
                lastImage = file;
                sleepQuietly(LENS_SETTLE_MS); // short: the copy step itself polls until Lens is ready
            }
        }
        currentPage = page;
        setAgentPage(page);
        return true;
    }

    private void sleepQuietly(long ms) {
        try {
            Thread.sleep(ms);
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            stopRequested = true;
        }
    }

    // ---- agent UI helpers (all safe to call from any thread) ----

    private void showAgentRunningUi() {
        btnAgent.setVisibility(View.GONE);
        btnStopAgent.setVisibility(View.VISIBLE);
        btnStopAgent.setEnabled(true);
        btnStopAgent.setAlpha(1f);
        layoutAgentPanel.setVisibility(View.VISIBLE);
        tvAgentTitle.setText("🤖 Agent Running...");
        tvAgentStatus.setText("Status: Starting...");
        setAgentPage(currentPage);
        setAgentCompleted();
        updateUi();
    }

    private void showAgentEndedUi(String title, String status, boolean done) {
        agentRunning = false;
        stopRequested = false;
        releaseWakeLock();
        btnStopAgent.setVisibility(View.GONE);
        btnAgent.setVisibility(View.VISIBLE);
        tvAgentTitle.setText(title);
        tvAgentStatus.setText("Status: " + status);
        setAgentCompleted();
        if (done) {
            pbAgent.setProgress(100);
            Toast.makeText(this, "All Pages Successfully Processed!", Toast.LENGTH_LONG).show();
        }
        updateUi();
        final View panel = layoutAgentPanel;
        mainHandler.postDelayed(() -> {
            if (!agentRunning && panel != null) panel.setVisibility(View.GONE);
        }, done ? 8000 : 5000);
    }

    private void setAgentStatus(String status) {
        mainHandler.post(() -> {
            if (tvAgentStatus != null) tvAgentStatus.setText("Status: " + status
                    + (status.endsWith("...") || status.equals("Completed") ? "" : "..."));
        });
    }

    private void setAgentPage(int page) {
        final int total = totalPages;
        mainHandler.post(() -> {
            if (tvAgentPage == null) return;
            tvAgentPage.setText("Current Page: " + (page + 1) + " / " + total);
            if (pbAgent != null && total > 0) pbAgent.setProgress((int) (page * 100L / total));
            updateUi();
        });
    }

    private void setAgentCompleted() {
        final int done = agentCompleted;
        mainHandler.post(() -> {
            if (tvAgentCompleted != null) tvAgentCompleted.setText("Completed Pages: " + done);
        });
    }

    private void acquireWakeLock() {
        try {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            if (pm != null) {
                wakeLock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "pdfgallery:lensagent");
                wakeLock.acquire(6 * 60 * 60 * 1000L);
            }
        } catch (Exception ignored) {}
    }

    private void releaseWakeLock() {
        try {
            if (wakeLock != null && wakeLock.isHeld()) wakeLock.release();
        } catch (Exception ignored) {}
        wakeLock = null;
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                    CHANNEL_ID, "Lens Page Navigator", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Google Lens এর উপরে পৃষ্ঠা পরিবর্তনের বার");
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(channel);
        }
    }

    private void startAsForeground() {
        Intent stopIntent = new Intent(this, LensNavigatorService.class);
        stopIntent.setAction(ACTION_STOP);
        PendingIntent stopPi = PendingIntent.getService(this, 3, stopIntent,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);

        Notification n = new NotificationCompat.Builder(this, CHANNEL_ID)
                .setContentTitle("PDF Gallery")
                .setContentText("Google Lens পৃষ্ঠা বার চালু আছে")
                .setSmallIcon(R.drawable.ic_google_lens)
                .addAction(R.drawable.ic_close, "বন্ধ করুন", stopPi)
                .setOngoing(true)
                .build();
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.UPSIDE_DOWN_CAKE) {
                startForeground(NOTIFICATION_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
            } else {
                startForeground(NOTIFICATION_ID, n);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onDestroy() {
        isRunning = false;
        instance = null;
        stopRequested = true;
        releaseWakeLock();
        if (windowManager != null && barView != null) {
            try { windowManager.removeView(barView); } catch (Exception ignored) {}
        }
        barView = null;
        executor.shutdownNow();
        prefetchExecutor.shutdownNow();
        agentExecutor.shutdownNow();
        super.onDestroy();
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
