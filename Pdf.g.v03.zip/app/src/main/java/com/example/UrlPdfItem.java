package com.example;

import org.json.JSONObject;
import java.io.Serializable;

public class UrlPdfItem implements Serializable {
    private String id;
    private String title;
    private String originalUrl;
    private String downloadUrl;
    private String coverImagePath; // local path to custom cover image, or null
    private String localFilePath;  // local downloaded pdf file path, or null if not downloaded
    private long dateAdded;
    private long fileSize;
    private boolean isDownloaded;

    public UrlPdfItem() {
    }

    public UrlPdfItem(String id, String title, String originalUrl, String downloadUrl, String coverImagePath) {
        this.id = id;
        this.title = title;
        this.originalUrl = originalUrl;
        this.downloadUrl = downloadUrl;
        this.coverImagePath = coverImagePath;
        this.dateAdded = System.currentTimeMillis();
        this.isDownloaded = false;
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getTitle() {
        return title != null ? title : "Document.pdf";
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getOriginalUrl() {
        return originalUrl != null ? originalUrl : "";
    }

    public void setOriginalUrl(String originalUrl) {
        this.originalUrl = originalUrl;
    }

    public String getDownloadUrl() {
        return downloadUrl != null ? downloadUrl : originalUrl;
    }

    public void setDownloadUrl(String downloadUrl) {
        this.downloadUrl = downloadUrl;
    }

    public String getCoverImagePath() {
        return coverImagePath;
    }

    public void setCoverImagePath(String coverImagePath) {
        this.coverImagePath = coverImagePath;
    }

    public String getLocalFilePath() {
        return localFilePath;
    }

    public void setLocalFilePath(String localFilePath) {
        this.localFilePath = localFilePath;
    }

    public long getDateAdded() {
        return dateAdded;
    }

    public void setDateAdded(long dateAdded) {
        this.dateAdded = dateAdded;
    }

    public long getFileSize() {
        return fileSize;
    }

    public void setFileSize(long fileSize) {
        this.fileSize = fileSize;
    }

    public boolean isDownloaded() {
        return isDownloaded;
    }

    public void setDownloaded(boolean downloaded) {
        isDownloaded = downloaded;
    }

    public JSONObject toJson() {
        JSONObject obj = new JSONObject();
        try {
            obj.put("id", id);
            obj.put("title", title);
            obj.put("originalUrl", originalUrl);
            obj.put("downloadUrl", downloadUrl);
            obj.put("coverImagePath", coverImagePath != null ? coverImagePath : "");
            obj.put("localFilePath", localFilePath != null ? localFilePath : "");
            obj.put("dateAdded", dateAdded);
            obj.put("fileSize", fileSize);
            obj.put("isDownloaded", isDownloaded);
        } catch (Exception ignored) {}
        return obj;
    }

    public static UrlPdfItem fromJson(JSONObject obj) {
        if (obj == null) return null;
        try {
            UrlPdfItem item = new UrlPdfItem();
            item.setId(obj.optString("id", String.valueOf(System.currentTimeMillis())));
            item.setTitle(obj.optString("title", "Untitled.pdf"));
            item.setOriginalUrl(obj.optString("originalUrl", ""));
            item.setDownloadUrl(obj.optString("downloadUrl", ""));
            String cover = obj.optString("coverImagePath", "");
            item.setCoverImagePath(cover.isEmpty() ? null : cover);
            String local = obj.optString("localFilePath", "");
            item.setLocalFilePath(local.isEmpty() ? null : local);
            item.setDateAdded(obj.optLong("dateAdded", System.currentTimeMillis()));
            item.setFileSize(obj.optLong("fileSize", 0));
            item.setDownloaded(obj.optBoolean("isDownloaded", false));
            return item;
        } catch (Exception e) {
            return null;
        }
    }
}
