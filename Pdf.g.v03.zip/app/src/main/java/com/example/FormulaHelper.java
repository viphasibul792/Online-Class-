package com.example;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class FormulaHelper {

    // Subscript digits: ₀₁₂₃₄₅₆₇₈₉
    private static final char[] SUBSCRIPT_DIGITS = {'₀', '₁', '₂', '₃', '₄', '₅', '₆', '₇', '₈', '₉'};
    // Superscript digits: ⁰¹²³⁴⁵⁶⁷⁸⁹
    private static final char[] SUPERSCRIPT_DIGITS = {'⁰', '¹', '²', '³', '⁴', '⁵', '⁶', '⁷', '⁸', '⁹'};

    /**
     * Converts ASCII digits in a string to Unicode subscript digits.
     */
    public static String toSubscript(String digits) {
        if (digits == null) return "";
        StringBuilder sb = new StringBuilder();
        for (char c : digits.toCharArray()) {
            if (c >= '0' && c <= '9') {
                sb.append(SUBSCRIPT_DIGITS[c - '0']);
            } else if (c == '+') {
                sb.append('₊');
            } else if (c == '-') {
                sb.append('₋');
            } else {
                sb.append(c);
            }
        }
        return sb.toString();
    }

    /**
     * Converts ASCII digits/signs in a string to Unicode superscript digits.
     */
    public static String toSuperscript(String digits) {
        if (digits == null) return "";
        StringBuilder sb = new StringBuilder();
        for (char c : digits.toCharArray()) {
            if (c >= '0' && c <= '9') {
                sb.append(SUPERSCRIPT_DIGITS[c - '0']);
            } else if (c == '+') {
                sb.append('⁺');
            } else if (c == '-') {
                sb.append('⁻');
            } else if (c == 'n') {
                sb.append('ⁿ');
            } else if (c == 'x') {
                sb.append('ˣ');
            } else if (c == 't') {
                sb.append('ᵗ');
            } else {
                sb.append(c);
            }
        }
        return sb.toString();
    }

    /**
     * Comprehensive formula formatter for Math, Physics, and Chemistry.
     * Converts raw text, pasted equations, LaTeX tags, and chemical formulas into clean,
     * beautifully rendered scientific symbols.
     */
    public static String formatScientificText(String input) {
        if (input == null || input.trim().isEmpty()) return input;

        String res = input;

        // 1. Clean LaTeX math delimiters like $$ ... $$ or $ ... $
        res = res.replaceAll("\\$\\$([^$]+)\\$\\$", "$1");
        res = res.replaceAll("\\$([^$]+)\\$", "$1");

        // 2. Physics & Chemistry arrows
        res = res.replaceAll("<==>|<=>|<->|<-->", " ⇌ ");
        res = res.replaceAll("-->|->", " → ");
        res = res.replaceAll("<--|<-", " ← ");
        res = res.replaceAll("\\\\rightarrow", " → ");
        res = res.replaceAll("\\\\leftarrow", " ← ");
        res = res.replaceAll("\\\\rightleftharpoons", " ⇌ ");
        res = res.replaceAll("\\\\uparrow", " ↑ ");
        res = res.replaceAll("\\\\downarrow", " ↓ ");

        // 3. Mathematical operators and relations
        res = res.replaceAll("\\\\times|\\s*\\*\\s*", " × ");
        res = res.replaceAll("\\\\div", " ÷ ");
        res = res.replaceAll("\\\\pm|\\+/-", " ± ");
        res = res.replaceAll("\\\\approx|~=", " ≈ ");
        res = res.replaceAll("\\\\neq|!=", " ≠ ");
        res = res.replaceAll("\\\\leq|<=", " ≤ ");
        res = res.replaceAll("\\\\geq|>=", " ≥ ");
        res = res.replaceAll("\\\\infty", " ∞ ");
        res = res.replaceAll("\\\\sqrt\\{([^}]+)\\}", "√($1)");
        res = res.replaceAll("\\\\sqrt", "√");
        res = res.replaceAll("\\\\int", "∫");
        res = res.replaceAll("\\\\sum", "∑");
        res = res.replaceAll("\\\\degree|\\\\deg", "°");

        // 4. Fractions: common fractions
        res = res.replaceAll("\\\\frac\\{([^}]+)\\}\\{([^}]+)\\}", "($1 / $2)");
        res = res.replaceAll("\\b1/2\\b", "½");
        res = res.replaceAll("\\b1/4\\b", "¼");
        res = res.replaceAll("\\b3/4\\b", "¾");
        res = res.replaceAll("\\b1/3\\b", "⅓");
        res = res.replaceAll("\\b2/3\\b", "⅔");

        // 5. Greek letters commonly used in Physics & Math
        res = res.replaceAll("\\\\alpha|\\balpha\\b", "α");
        res = res.replaceAll("\\\\beta|\\bbeta\\b", "β");
        res = res.replaceAll("\\\\gamma|\\bgamma\\b", "γ");
        res = res.replaceAll("\\\\Delta|\\bDelta\\b", "Δ");
        res = res.replaceAll("\\\\delta|\\bdelta\\b", "δ");
        res = res.replaceAll("\\\\theta|\\btheta\\b", "θ");
        res = res.replaceAll("\\\\lambda|\\blambda\\b", "λ");
        res = res.replaceAll("\\\\mu|\\bmu\\b", "μ");
        res = res.replaceAll("\\\\pi|\\bpi\\b", "π");
        res = res.replaceAll("\\\\rho|\\brho\\b", "ρ");
        res = res.replaceAll("\\\\sigma|\\bsigma\\b", "σ");
        res = res.replaceAll("\\\\tau|\\btau\\b", "τ");
        res = res.replaceAll("\\\\phi|\\bphi\\b", "φ");
        res = res.replaceAll("\\\\omega|\\bomega\\b", "ω");
        res = res.replaceAll("\\\\Omega|\\bOmega\\b", "Ω");
        res = res.replaceAll("\\\\epsilon|\\bepsilon\\b", "ε");

        // 6. Explicit superscripts: e.g. ^2, ^3, ^-1, ^n, ^{12}
        Matcher supBraces = Pattern.compile("\\^\\{([0-9+\\-nxt]+)\\}").matcher(res);
        StringBuffer sbSup = new StringBuffer();
        while (supBraces.find()) {
            supBraces.appendReplacement(sbSup, toSuperscript(supBraces.group(1)));
        }
        supBraces.appendTail(sbSup);
        res = sbSup.toString();

        Matcher supDirect = Pattern.compile("\\^([0-9+\\-nxt])").matcher(res);
        StringBuffer sbSupD = new StringBuffer();
        while (supDirect.find()) {
            supDirect.appendReplacement(sbSupD, toSuperscript(supDirect.group(1)));
        }
        supDirect.appendTail(sbSupD);
        res = sbSupD.toString();

        // 7. Explicit subscripts: e.g. _0, _1, _i, _f, _{12}
        Matcher subBraces = Pattern.compile("_\\{([0-9+\\-]+)\\}").matcher(res);
        StringBuffer sbSub = new StringBuffer();
        while (subBraces.find()) {
            subBraces.appendReplacement(sbSub, toSubscript(subBraces.group(1)));
        }
        subBraces.appendTail(sbSub);
        res = sbSub.toString();

        Matcher subDirect = Pattern.compile("_([0-9])").matcher(res);
        StringBuffer sbSubD = new StringBuffer();
        while (subDirect.find()) {
            subDirect.appendReplacement(sbSubD, toSubscript(subDirect.group(1)));
        }
        subDirect.appendTail(sbSubD);
        res = sbSubD.toString();

        // Specific physics subscripts: v_0 -> v₀, v_i -> vᵢ, v_f -> v𝒻, m_1 -> m₁
        res = res.replaceAll("([vVuUaAfFmMpPrRsStT])_0", "$1₀");
        res = res.replaceAll("([vVuUaAfFmMpPrRsStT])_1", "$1₁");
        res = res.replaceAll("([vVuUaAfFmMpPrRsStT])_2", "$1₂");
        res = res.replaceAll("([vVuUaAfFmMpPrRsStT])_i", "$1ᵢ");
        res = res.replaceAll("([vVuUaAfFmMpPrRsStT])_f", "$1𝒻");

        // 8. Chemical Formulas: automatically convert subscripts in chemical formulas
        // Known common chemical compounds
        res = formatCommonChemicalFormulas(res);

        // General chemical formula pattern: e.g., H2O, Ca(OH)2, KMnO4, Fe2O3, C6H12O6
        res = formatGeneralChemicalSubscripts(res);

        // Clean up any double spaces introduced by replacements
        res = res.replaceAll("  +", " ");

        return res;
    }

    private static String formatCommonChemicalFormulas(String text) {
        String res = text;
        // Water, Gases
        res = res.replaceAll("\\bH2O\\b", "H₂O");
        res = res.replaceAll("\\bCO2\\b", "CO₂");
        res = res.replaceAll("\\bO2\\b", "O₂");
        res = res.replaceAll("\\bH2\\b", "H₂");
        res = res.replaceAll("\\bN2\\b", "N₂");
        res = res.replaceAll("\\bCl2\\b", "Cl₂");
        res = res.replaceAll("\\bNH3\\b", "NH₃");
        res = res.replaceAll("\\bCH4\\b", "CH₄");
        res = res.replaceAll("\\bSO2\\b", "SO₂");
        res = res.replaceAll("\\bSO3\\b", "SO₃");
        res = res.replaceAll("\\bNO2\\b", "NO₂");

        // Acids and Bases
        res = res.replaceAll("\\bH2SO4\\b", "H₂SO₄");
        res = res.replaceAll("\\bHNO3\\b", "HNO₃");
        res = res.replaceAll("\\bH3PO4\\b", "H₃PO₄");
        res = res.replaceAll("\\bCH3COOH\\b", "CH₃COOH");
        res = res.replaceAll("\\bCa\\(OH\\)2\\b", "Ca(OH)₂");
        res = res.replaceAll("\\bMg\\(OH\\)2\\b", "Mg(OH)₂");
        res = res.replaceAll("\\bAl\\(OH\\)3\\b", "Al(OH)₃");

        // Salts and Minerals
        res = res.replaceAll("\\bCaCO3\\b", "CaCO₃");
        res = res.replaceAll("\\bNa2CO3\\b", "Na₂CO₃");
        res = res.replaceAll("\\bNaHCO3\\b", "NaHCO₃");
        res = res.replaceAll("\\bCuSO4\\b", "CuSO₄");
        res = res.replaceAll("\\bFe2O3\\b", "Fe₂O₃");
        res = res.replaceAll("\\bAl2O3\\b", "Al₂O₃");
        res = res.replaceAll("\\bKMnO4\\b", "KMnO₄");
        res = res.replaceAll("\\bK2Cr2O7\\b", "K₂Cr₂O₇");
        res = res.replaceAll("\\bC6H12O6\\b", "C₆H₁₂O₆");
        res = res.replaceAll("\\bC2H5OH\\b", "C₂H₅OH");
        res = res.replaceAll("\\bBaSO4\\b", "BaSO₄");
        res = res.replaceAll("\\bAgCl\\b", "AgCl");

        // Ion charges: Na+, Cl-, Fe2+, Fe3+, SO4 2-
        res = res.replaceAll("([A-Za-z0-9\\]\\)])\\^?(2\\+|\\+2)", "$1²⁺");
        res = res.replaceAll("([A-Za-z0-9\\]\\)])\\^?(3\\+|\\+3)", "$1³⁺");
        res = res.replaceAll("([A-Za-z0-9\\]\\)])\\^?(2\\-|\\-2)", "$1²⁻");
        res = res.replaceAll("([A-Za-z0-9\\]\\)])\\^\\+", "$1⁺");
        res = res.replaceAll("([A-Za-z0-9\\]\\)])\\^\\-", "$1⁻");

        return res;
    }

    private static String formatGeneralChemicalSubscripts(String text) {
        // Matches chemical element followed by a number:
        // e.g. H2, O3, Ca2, (SO4)3, etc.
        // We match an element symbol ([A-Z][a-z]?|\)) followed by digits [0-9]+
        // when preceded by word boundary or chemical formula characters.
        Pattern chemPattern = Pattern.compile("(?<=[A-Z][a-z]?|\\))([0-9]+)");
        Matcher matcher = chemPattern.matcher(text);
        StringBuffer sb = new StringBuffer();
        while (matcher.find()) {
            String digits = matcher.group(1);
            matcher.appendReplacement(sb, toSubscript(digits));
        }
        matcher.appendTail(sb);
        return sb.toString();
    }

    /**
     * Generates a fully styled HTML document containing MathJax / KaTeX rendering
     * for crisp, publication-grade math, physics equations, and chemistry formulas.
     */
    public static String generateHtmlForFormulas(String content, boolean isDarkMode) {
        String bgColor = isDarkMode ? "#121212" : "#FFFFFF";
        String textColor = isDarkMode ? "#E0E0E0" : "#1A1A1A";
        String cardBg = isDarkMode ? "#1E1E1E" : "#F8F9FA";
        String cardBorder = isDarkMode ? "#333333" : "#E2E8F0";
        String formulaColor = isDarkMode ? "#90CAF9" : "#1565C0";
        String badgeBg = isDarkMode ? "#0D47A1" : "#E3F2FD";
        String badgeText = isDarkMode ? "#BBDEFB" : "#0D47A1";

        // Escape HTML
        String safeContent = content != null ? content : "";
        safeContent = safeContent.replace("&", "&amp;")
                                 .replace("<", "&lt;")
                                 .replace(">", "&gt;");

        // Format page tags: (পৃষ্ঠা= ১০০) -> styled badges
        safeContent = safeContent.replaceAll("(\\((?:পৃষ্ঠা|Page)\\s*=\\s*[0-9০-৯]+\\))",
                "<span class='page-badge'>$1</span>");

        // Format line breaks
        safeContent = safeContent.replace("\n", "<br/>");

        return "<!DOCTYPE html>\n" +
                "<html>\n" +
                "<head>\n" +
                "    <meta charset=\"utf-8\"/>\n" +
                "    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0, user-scalable=yes\"/>\n" +
                "    <link rel=\"stylesheet\" href=\"https://cdn.jsdelivr.net/npm/katex@0.16.8/dist/katex.min.css\"/>\n" +
                "    <script defer src=\"https://cdn.jsdelivr.net/npm/katex@0.16.8/dist/katex.min.js\"></script>\n" +
                "    <script defer src=\"https://cdn.jsdelivr.net/npm/katex@0.16.8/dist/contrib/auto-render.min.js\"\n" +
                "            onload=\"renderMathInElement(document.body);\"></script>\n" +
                "    <style>\n" +
                "        body {\n" +
                "            background-color: " + bgColor + ";\n" +
                "            color: " + textColor + ";\n" +
                "            font-family: 'Noto Serif Bengali', 'Times New Roman', serif, sans-serif;\n" +
                "            font-size: 16px;\n" +
                "            line-height: 1.8;\n" +
                "            padding: 16px;\n" +
                "            margin: 0;\n" +
                "            word-wrap: break-word;\n" +
                "        }\n" +
                "        .content-card {\n" +
                "            background-color: " + cardBg + ";\n" +
                "            border: 1px solid " + cardBorder + ";\n" +
                "            border-radius: 12px;\n" +
                "            padding: 16px;\n" +
                "            margin-bottom: 24px;\n" +
                "            box-shadow: 0 2px 4px rgba(0,0,0,0.06);\n" +
                "        }\n" +
                "        .page-badge {\n" +
                "            background-color: " + badgeBg + ";\n" +
                "            color: " + badgeText + ";\n" +
                "            font-weight: bold;\n" +
                "            padding: 2px 8px;\n" +
                "            border-radius: 6px;\n" +
                "            font-size: 14px;\n" +
                "            display: inline-block;\n" +
                "            margin: 4px 2px;\n" +
                "        }\n" +
                "        .formula-highlight {\n" +
                "            color: " + formulaColor + ";\n" +
                "            font-family: 'Cambria Math', 'Times New Roman', serif;\n" +
                "            font-weight: 500;\n" +
                "        }\n" +
                "        .banner {\n" +
                "            font-size: 12px;\n" +
                "            color: #888888;\n" +
                "            text-align: right;\n" +
                "            margin-bottom: 8px;\n" +
                "        }\n" +
                "    </style>\n" +
                "</head>\n" +
                "<body>\n" +
                "    <div class=\"banner\">সমীকরণ ও সূত্র ভিউ (LaTeX & KaTeX Supported)</div>\n" +
                "    <div class=\"content-card formula-highlight\">\n" +
                safeContent + "\n" +
                "    </div>\n" +
                "</body>\n" +
                "</html>";
    }
}
