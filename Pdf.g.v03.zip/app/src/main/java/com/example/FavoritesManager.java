package com.example;

import android.content.Context;
import android.content.SharedPreferences;
import java.util.HashSet;
import java.util.Set;

public class FavoritesManager {

    private static final String PREF_NAME = "pdf_favorites_prefs";
    private static final String KEY_FAVORITES = "favorite_pdf_identifiers";

    private final SharedPreferences prefs;

    public FavoritesManager(Context context) {
        this.prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }

    public static String getPdfKey(PdfFile file) {
        if (file == null) return "";
        if (file.getPath() != null && !file.getPath().trim().isEmpty()) {
            return file.getPath().trim();
        }
        if (file.getUri() != null) {
            return file.getUri().toString();
        }
        return file.getName() != null ? file.getName() : String.valueOf(file.getId());
    }

    public boolean isFavorite(PdfFile file) {
        if (file == null) return false;
        String key = getPdfKey(file);
        Set<String> favs = prefs.getStringSet(KEY_FAVORITES, null);
        return favs != null && favs.contains(key);
    }

    public void setFavorite(PdfFile file, boolean favorite) {
        if (file == null) return;
        String key = getPdfKey(file);
        Set<String> current = prefs.getStringSet(KEY_FAVORITES, new HashSet<>());
        Set<String> updated = new HashSet<>(current);
        if (favorite) {
            updated.add(key);
        } else {
            updated.remove(key);
        }
        prefs.edit().putStringSet(KEY_FAVORITES, updated).apply();
    }

    public boolean toggleFavorite(PdfFile file) {
        boolean newState = !isFavorite(file);
        setFavorite(file, newState);
        return newState;
    }

    public Set<String> getAllFavoriteKeys() {
        Set<String> favs = prefs.getStringSet(KEY_FAVORITES, new HashSet<>());
        return favs != null ? new HashSet<>(favs) : new HashSet<>();
    }

    public void restoreFavoriteKeys(Set<String> keys) {
        if (keys == null) return;
        prefs.edit().putStringSet(KEY_FAVORITES, new HashSet<>(keys)).apply();
    }
}
