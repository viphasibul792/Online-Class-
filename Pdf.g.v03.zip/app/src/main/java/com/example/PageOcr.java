package com.example;

import android.content.Context;
import android.graphics.Bitmap;

import com.google.android.gms.tasks.Tasks;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;
import com.googlecode.tesseract.android.TessBaseAPI;

import java.io.Closeable;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.concurrent.TimeUnit;

/**
 * Extracts text from a rendered PDF page image. Must be used from a background thread only.
 *
 * Bengali + English: Tesseract (ben+eng). The language files are downloaded once into the app's
 * private storage the first time OCR is needed. If they cannot be downloaded (offline), the
 * existing ML Kit Latin recognizer is used as a fallback (English only).
 */
public class PageOcr implements Closeable {

    /** Base URL of the Tesseract "fast" LSTM models. Change to tessdata_best for higher accuracy. */
    private static final String TESSDATA_BASE =
            "https://github.com/tesseract-ocr/tessdata_fast/raw/main/";
    private static final String[] LANGS = {"ben", "eng"};
    private static final long MIN_VALID_BYTES = 100 * 1024;

    public interface StatusListener {
        void onStatus(String status);
    }

    private final Context context;
    private TessBaseAPI tess;
    private TextRecognizer mlKit;
    private boolean prepared = false;
    private boolean usingTesseract = false;
    private String tessLanguage = "";

    public PageOcr(Context context) {
        this.context = context.getApplicationContext();
    }

    private File tessRoot() {
        return new File(context.getFilesDir(), "ocr");
    }

    private File tessDataDir() {
        return new File(tessRoot(), "tessdata");
    }

    /** Prepares the engine (downloads language data on first run). Safe to call repeatedly. */
    public synchronized void prepare(StatusListener listener) {
        if (prepared) return;
        File dir = tessDataDir();
        //noinspection ResultOfMethodCallIgnored
        dir.mkdirs();

        StringBuilder available = new StringBuilder();
        for (String lang : LANGS) {
            File f = new File(dir, lang + ".traineddata");
            if (!isValid(f)) {
                if (listener != null) listener.onStatus("Downloading OCR data (" + lang + ")...");
                download(TESSDATA_BASE + lang + ".traineddata", f);
            }
            if (isValid(f)) {
                if (available.length() > 0) available.append('+');
                available.append(lang);
            }
        }

        if (available.length() > 0) {
            try {
                TessBaseAPI api = new TessBaseAPI();
                if (api.init(tessRoot().getAbsolutePath(), available.toString())) {
                    tess = api;
                    tessLanguage = available.toString();
                    usingTesseract = true;
                } else {
                    api.recycle();
                }
            } catch (Throwable t) {
                t.printStackTrace();
            }
        }

        if (!usingTesseract) {
            // Offline / init failure: English-only fallback with the OCR engine already in the app.
            mlKit = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        }
        prepared = true;
    }

    /** True when Bengali recognition is available (Tesseract with the ben model loaded). */
    public boolean supportsBengali() {
        return usingTesseract && tessLanguage.contains("ben");
    }

    /** Returns the recognized text of the page (may be empty for blank pages). */
    public synchronized String recognize(Bitmap bitmap) throws Exception {
        if (!prepared) prepare(null);
        String text;
        if (usingTesseract) {
            tess.setImage(bitmap);
            text = tess.getUTF8Text();
            tess.clear();
        } else {
            text = Tasks.await(
                    mlKit.process(InputImage.fromBitmap(bitmap, 0)), 60, TimeUnit.SECONDS).getText();
        }
        return normalize(text);
    }

    /** Light clean-up that keeps formulas, sub/superscripts and Bengali text untouched. */
    static String normalize(String raw) {
        if (raw == null) return "";
        String t = raw.replace("\r\n", "\n").replace('\r', '\n').replace(' ', ' ');
        // collapse 3+ blank lines, trim trailing spaces on each line
        t = t.replaceAll("[ \\t]+\\n", "\n").replaceAll("\\n{3,}", "\n\n");
        return t.trim();
    }

    private static boolean isValid(File f) {
        return f.exists() && f.length() > MIN_VALID_BYTES;
    }

    private void download(String url, File target) {
        File tmp = new File(target.getParentFile(), target.getName() + ".part");
        HttpURLConnection conn = null;
        try {
            conn = (HttpURLConnection) new URL(url).openConnection();
            conn.setConnectTimeout(15000);
            conn.setReadTimeout(30000);
            conn.setInstanceFollowRedirects(true);
            if (conn.getResponseCode() != 200) return;
            try (InputStream in = conn.getInputStream(); OutputStream out = new FileOutputStream(tmp)) {
                byte[] buf = new byte[16 * 1024];
                int n;
                while ((n = in.read(buf)) > 0) out.write(buf, 0, n);
            }
            if (tmp.length() > MIN_VALID_BYTES) {
                //noinspection ResultOfMethodCallIgnored
                tmp.renameTo(target);
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (conn != null) conn.disconnect();
            if (tmp.exists()) {
                //noinspection ResultOfMethodCallIgnored
                tmp.delete();
            }
        }
    }

    @Override
    public synchronized void close() {
        if (tess != null) {
            try { tess.recycle(); } catch (Throwable ignored) {}
            tess = null;
        }
        if (mlKit != null) {
            try { mlKit.close(); } catch (Throwable ignored) {}
            mlKit = null;
        }
        prepared = false;
        usingTesseract = false;
    }
}
