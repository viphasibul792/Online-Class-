package com.example;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.pdf.PdfDocument;
import android.graphics.pdf.PdfRenderer;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import androidx.core.content.FileProvider;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.zip.ZipEntry;
import java.util.zip.ZipOutputStream;

public class PdfUtils {

    public static final String FILE_PROVIDER_AUTHORITY = "com.example.fileprovider";

    /**
     * Cleans raw PDF file names by removing unwanted prefixes such as dl_url_1790159872928_ or dl_...
     */
    public static String cleanPdfName(String rawName) {
        if (rawName == null) return "Document.pdf";
        String cleaned = rawName.trim();
        cleaned = cleaned.replaceFirst("^(?i)dl_url_\\d+_", "");
        cleaned = cleaned.replaceFirst("^(?i)dl_[a-zA-Z0-9]+_", "");
        return cleaned;
    }

    /**
     * Generates a crisp cover thumbnail from the first page (page 0) of a PDF and saves it to app storage.
     */
    public static String generateAndSaveFirstPageThumbnail(Context context, File pdfFile, String itemId) {
        if (context == null || pdfFile == null || !pdfFile.exists()) return null;
        ParcelFileDescriptor pfd = null;
        PdfRenderer renderer = null;
        PdfRenderer.Page page = null;
        try {
            pfd = ParcelFileDescriptor.open(pdfFile, ParcelFileDescriptor.MODE_READ_ONLY);
            if (pfd == null) return null;
            renderer = new PdfRenderer(pfd);
            if (renderer.getPageCount() <= 0) return null;

            page = renderer.openPage(0);
            int originalW = page.getWidth();
            int originalH = page.getHeight();
            int targetWidth = 360;
            int targetHeight = (int) ((float) originalH * targetWidth / originalW);

            Bitmap bitmap = Bitmap.createBitmap(targetWidth, targetHeight, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(bitmap);
            canvas.drawColor(Color.WHITE);
            page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);

            File coversDir = new File(context.getFilesDir(), "covers");
            if (!coversDir.exists()) coversDir.mkdirs();

            String safeId = (itemId != null ? itemId : ("pdf_" + pdfFile.getName().hashCode())).replaceAll("[^a-zA-Z0-9_-]", "_");
            File dest = new File(coversDir, "thumb_" + safeId + ".jpg");
            FileOutputStream fos = new FileOutputStream(dest);
            bitmap.compress(Bitmap.CompressFormat.JPEG, 85, fos);
            fos.flush();
            fos.close();
            return dest.getAbsolutePath();
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        } finally {
            if (page != null) {
                try { page.close(); } catch (Exception ignored) {}
            }
            if (renderer != null) {
                try { renderer.close(); } catch (Exception ignored) {}
            }
            if (pfd != null) {
                try { pfd.close(); } catch (Exception ignored) {}
            }
        }
    }

    /**
     * Attempts to download the public Google Drive first page preview thumbnail.
     */
    public static String downloadDriveThumbnailIfAvailable(Context context, String originalUrl, String itemId) {
        if (context == null || originalUrl == null || originalUrl.isEmpty()) return null;
        String fileId = UrlPdfManager.extractGoogleDriveFileId(originalUrl);
        if (fileId == null || fileId.isEmpty()) return null;

        String thumbUrl = "https://drive.google.com/thumbnail?id=" + fileId + "&sz=w400";
        try {
            URL url = new URL(thumbUrl);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setConnectTimeout(6000);
            conn.setReadTimeout(6000);
            conn.setInstanceFollowRedirects(true);
            conn.connect();

            int code = conn.getResponseCode();
            if (code == 200) {
                InputStream is = conn.getInputStream();
                Bitmap bitmap = BitmapFactory.decodeStream(is);
                is.close();
                conn.disconnect();

                if (bitmap != null) {
                    File coversDir = new File(context.getFilesDir(), "covers");
                    if (!coversDir.exists()) coversDir.mkdirs();

                    String safeId = (itemId != null ? itemId : ("drive_" + fileId)).replaceAll("[^a-zA-Z0-9_-]", "_");
                    File dest = new File(coversDir, "thumb_" + safeId + ".jpg");
                    FileOutputStream fos = new FileOutputStream(dest);
                    bitmap.compress(Bitmap.CompressFormat.JPEG, 85, fos);
                    fos.flush();
                    fos.close();
                    return dest.getAbsolutePath();
                }
            } else {
                conn.disconnect();
            }
        } catch (Exception ignored) {}
        return null;
    }

    /**
     * Direct launcher for official Google Lens application using exact vendor intents.
     */
    public static boolean launchOfficialGoogleLens(Context context, String imagePath) {
        if (context == null || imagePath == null || imagePath.isEmpty()) return false;
        File file = new File(imagePath);
        if (!file.exists()) return false;

        Uri contentUri;
        try {
            contentUri = FileProvider.getUriForFile(context, FILE_PROVIDER_AUTHORITY, file);
        } catch (Exception e) {
            return false;
        }

        PackageManager pm = context.getPackageManager();

        // 1. Google Lens direct launcher
        try {
            Intent lensDirect = new Intent(Intent.ACTION_SEND);
            lensDirect.setType("image/*");
            lensDirect.putExtra(Intent.EXTRA_STREAM, contentUri);
            lensDirect.setComponent(new ComponentName("com.google.ar.lens", "com.google.vr.apps.ornament.app.lens.LensLauncherActivity"));
            lensDirect.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            if (lensDirect.resolveActivity(pm) != null) {
                context.startActivity(lensDirect);
                return true;
            }
        } catch (Exception ignored) {}

        // 2. Google Lens VIEW_ACTION
        try {
            Intent lensView = new Intent("com.google.ar.lens.VIEW_ACTION");
            lensView.setDataAndType(contentUri, "image/*");
            lensView.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
            if (lensView.resolveActivity(pm) != null) {
                context.startActivity(lensView);
                return true;
            }
        } catch (Exception ignored) {}

        // 3. Google App specific Lens activities
        String[] lensActivities = new String[] {
                "com.google.android.apps.search.lens.LensShareActivity",
                "com.google.android.apps.search.lens.LensActivity",
                "com.google.android.apps.gsa.staticplugins.opa.lens.OpaLensActivity"
        };
        for (String act : lensActivities) {
            try {
                Intent gIntent = new Intent(Intent.ACTION_SEND);
                gIntent.setType("image/*");
                gIntent.putExtra(Intent.EXTRA_STREAM, contentUri);
                gIntent.setComponent(new ComponentName("com.google.android.googlequicksearchbox", act));
                gIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
                if (gIntent.resolveActivity(pm) != null) {
                    context.startActivity(gIntent);
                    return true;
                }
            } catch (Exception ignored) {}
        }
        return false;
    }

    public static Bitmap renderPageToBitmap(Context context, Uri uri, int pageIndex, int targetWidth) {
        ParcelFileDescriptor pfd = null;
        PdfRenderer renderer = null;
        PdfRenderer.Page page = null;
        try {
            if (uri.getScheme() != null && uri.getScheme().equals("file")) {
                File file = new File(uri.getPath());
                pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY);
            } else {
                pfd = context.getContentResolver().openFileDescriptor(uri, "r");
            }

            if (pfd == null) return null;

            renderer = new PdfRenderer(pfd);
            if (pageIndex < 0 || pageIndex >= renderer.getPageCount()) {
                return null;
            }

            page = renderer.openPage(pageIndex);
            int width = page.getWidth();
            int height = page.getHeight();

            if (targetWidth > 0 && width > 0) {
                float scale = (float) targetWidth / width;
                width = targetWidth;
                height = (int) (height * scale);
            }

            Bitmap bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(bitmap);
            canvas.drawColor(Color.WHITE);

            page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
            return bitmap;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        } finally {
            if (page != null) {
                try { page.close(); } catch (Exception ignored) {}
            }
            if (renderer != null) {
                try { renderer.close(); } catch (Exception ignored) {}
            }
            if (pfd != null) {
                try { pfd.close(); } catch (Exception ignored) {}
            }
        }
    }

    public static int getPageCount(Context context, Uri uri) {
        ParcelFileDescriptor pfd = null;
        PdfRenderer renderer = null;
        try {
            if (uri.getScheme() != null && uri.getScheme().equals("file")) {
                File file = new File(uri.getPath());
                pfd = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY);
            } else {
                pfd = context.getContentResolver().openFileDescriptor(uri, "r");
            }

            if (pfd != null) {
                renderer = new PdfRenderer(pfd);
                return renderer.getPageCount();
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (renderer != null) {
                try { renderer.close(); } catch (Exception ignored) {}
            }
            if (pfd != null) {
                try { pfd.close(); } catch (Exception ignored) {}
            }
        }
        return 1;
    }

    public static File compressPdfToZip(Context context, PdfFile pdfFile) throws IOException {
        File pdfSource = new File(pdfFile.getPath());
        File outputZip = new File(context.getExternalFilesDir(null), 
                pdfFile.getName().replace(".pdf", "") + "_compressed.zip");

        try (FileInputStream fis = new FileInputStream(pdfSource);
             FileOutputStream fos = new FileOutputStream(outputZip);
             ZipOutputStream zos = new ZipOutputStream(fos)) {

            ZipEntry entry = new ZipEntry(pdfFile.getName());
            zos.putNextEntry(entry);

            byte[] buffer = new byte[8192];
            int length;
            while ((length = fis.read(buffer)) > 0) {
                zos.write(buffer, 0, length);
            }
            zos.closeEntry();
        }
        return outputZip;
    }

    public static void sharePdf(Context context, PdfFile pdfFile) {
        Uri contentUri = pdfFile.getUri();
        if (pdfFile.getPath() != null && !pdfFile.getPath().isEmpty()) {
            File file = new File(pdfFile.getPath());
            if (file.exists()) {
                try {
                    contentUri = FileProvider.getUriForFile(context, FILE_PROVIDER_AUTHORITY, file);
                } catch (Exception ignored) {}
            }
        }

        if (contentUri == null) return;

        Intent shareIntent = new Intent(Intent.ACTION_SEND);
        shareIntent.setType("application/pdf");
        shareIntent.putExtra(Intent.EXTRA_STREAM, contentUri);
        shareIntent.putExtra(Intent.EXTRA_SUBJECT, pdfFile.getName());
        shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

        context.startActivity(Intent.createChooser(shareIntent, "Share PDF Document via"));
    }

    public static final String AI_PROMPT = "এই স্লাইডগুলোর সমস্ত হাতের + প্লেইন টেক্সট A to Z copy করে দাও";

    public static void shareSnippetImage(Context context, File imageFile) {
        shareSnippetImageWithPrompt(context, imageFile, AI_PROMPT);
    }

    public static void shareSnippetImageWithPrompt(Context context, File imageFile, String prompt) {
        if (!imageFile.exists()) return;

        Uri contentUri = FileProvider.getUriForFile(context, FILE_PROVIDER_AUTHORITY, imageFile);

        // Also copy prompt to clipboard so it's always ready to paste in any app
        try {
            android.content.ClipboardManager clipboard = (android.content.ClipboardManager) 
                    context.getSystemService(Context.CLIPBOARD_SERVICE);
            if (clipboard != null && prompt != null && !prompt.isEmpty()) {
                android.content.ClipData clip = android.content.ClipData.newPlainText("AI Prompt", prompt);
                clipboard.setPrimaryClip(clip);
            }
        } catch (Exception ignored) {}

        Intent shareIntent = new Intent(Intent.ACTION_SEND);
        shareIntent.setType("image/png");
        shareIntent.putExtra(Intent.EXTRA_STREAM, contentUri);
        if (prompt != null && !prompt.isEmpty()) {
            shareIntent.putExtra(Intent.EXTRA_TEXT, prompt);
            shareIntent.putExtra(Intent.EXTRA_SUBJECT, prompt);
        }
        shareIntent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);

        context.startActivity(Intent.createChooser(shareIntent, "Share Snippet to AI (Gemini) / Chat"));
    }

    /** Converts 0-9 into Bengali digits (০-৯). */
    public static String toBengaliDigits(String input) {
        if (input == null) return "";
        final char[] bn = {'০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯'};
        StringBuilder sb = new StringBuilder(input.length());
        for (int i = 0; i < input.length(); i++) {
            char c = input.charAt(i);
            sb.append(c >= '0' && c <= '9' ? bn[c - '0'] : c);
        }
        return sb.toString();
    }

    /** Fast JPEG (instead of 100% PNG) - much quicker to encode and for Google Lens to load. */
    public static File saveBitmapJpegToCache(Context context, Bitmap bitmap, String prefix) {
        File cacheDir = new File(context.getCacheDir(), "snippets");
        if (!cacheDir.exists()) {
            cacheDir.mkdirs();
        }
        File file = new File(cacheDir, (prefix != null ? prefix : "page_") + System.currentTimeMillis() + ".jpg");
        try (FileOutputStream fos = new FileOutputStream(file)) {
            bitmap.compress(Bitmap.CompressFormat.JPEG, 92, fos);
            return file;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static File saveBitmapToCache(Context context, Bitmap bitmap, String prefix) {
        File cacheDir = new File(context.getCacheDir(), "snippets");
        if (!cacheDir.exists()) {
            cacheDir.mkdirs();
        }
        String timestamp = new java.text.SimpleDateFormat("yyyyMMdd_HHmmss", java.util.Locale.getDefault()).format(new java.util.Date());
        File file = new File(cacheDir, (prefix != null ? prefix : "snippet_") + timestamp + ".png");
        try (FileOutputStream fos = new FileOutputStream(file)) {
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, fos);
            return file;
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public static List<PdfFile> createSamplePdfFiles(Context context) {
        List<PdfFile> createdList = new ArrayList<>();
        File docsDir = context.getExternalFilesDir(null);
        if (docsDir == null) docsDir = context.getFilesDir();

        createSamplePdf(docsDir, "Machine_Learning_Lecture_Notes.pdf",
                "Machine Learning: Core Principles & Architecture",
                new String[]{
                        "1. Deep Neural Networks & Backpropagation Foundations",
                        "2. Attention Mechanisms and Transformer Architectures",
                        "3. Model Optimization: Quantization, Pruning, and Latency Tuning",
                        "4. Reinforcement Learning via Human Feedback (RLHF)",
                        "5. Practical Implementations in Mobile Device Environments"
                }, 3);

        createSamplePdf(docsDir, "Product_Design_Sprint_Guide.pdf",
                "Product Design Sprint: Framework & Guidelines",
                new String[]{
                        "Day 1: Map the Problem & Target Key Challenges",
                        "Day 2: Sketch Competing Solutions & Ideate",
                        "Day 3: Decide on Top Concepts & Storyboard",
                        "Day 4: Prototype Realistic User Experiences",
                        "Day 5: Test Directly with Target Customers"
                }, 2);

        createSamplePdf(docsDir, "Quarterly_Financial_Summary_2026.pdf",
                "Enterprise Growth & Financial Performance Q3 2026",
                new String[]{
                        "Key Financial Highlights: Total Revenue +34% YoY",
                        "Operating Efficiency: Cloud Infrastructure Margins Reaching 62%",
                        "R&D Allocation: Focus on On-Device Machine Intelligence & Security",
                        "Capital Expenditures & Balance Sheet Summary",
                        "Forecast for Fiscal Year 2027 and Strategic Initiatives"
                }, 4);

        File[] files = docsDir.listFiles();
        if (files != null) {
            for (File file : files) {
                if (file.getName().toLowerCase().endsWith(".pdf")) {
                    Uri uri = FileProvider.getUriForFile(context, FILE_PROVIDER_AUTHORITY, file);
                    PdfFile pdf = new PdfFile(
                            file.hashCode(),
                            file.getName(),
                            file.getAbsolutePath(),
                            uri,
                            file.length(),
                            file.lastModified()
                    );
                    createdList.add(pdf);
                }
            }
        }
        return createdList;
    }

    private static void createSamplePdf(File dir, String fileName, String title, String[] points, int numPages) {
        File file = new File(dir, fileName);
        if (file.exists() && file.length() > 0) return;

        PdfDocument document = new PdfDocument();
        int pageWidth = 595;
        int pageHeight = 842;

        Paint paintTitle = new Paint();
        paintTitle.setColor(Color.rgb(211, 47, 47)); // Primary Red
        paintTitle.setTextSize(20);
        paintTitle.setFakeBoldText(true);
        paintTitle.setAntiAlias(true);

        Paint paintHeader = new Paint();
        paintHeader.setColor(Color.rgb(31, 41, 55));
        paintHeader.setTextSize(14);
        paintHeader.setFakeBoldText(true);
        paintHeader.setAntiAlias(true);

        Paint paintBody = new Paint();
        paintBody.setColor(Color.rgb(75, 85, 99));
        paintBody.setTextSize(12);
        paintBody.setAntiAlias(true);

        Paint paintDivider = new Paint();
        paintDivider.setColor(Color.rgb(229, 231, 235));
        paintDivider.setStrokeWidth(2);

        Paint paintBox = new Paint();
        paintBox.setColor(Color.rgb(248, 249, 250));
        paintBox.setStyle(Paint.Style.FILL);

        Paint paintBoxBorder = new Paint();
        paintBoxBorder.setColor(Color.rgb(220, 225, 230));
        paintBoxBorder.setStyle(Paint.Style.STROKE);
        paintBoxBorder.setStrokeWidth(1);

        for (int p = 1; p <= numPages; p++) {
            PdfDocument.PageInfo pageInfo = new PdfDocument.PageInfo.Builder(pageWidth, pageHeight, p).create();
            PdfDocument.Page page = document.startPage(pageInfo);
            Canvas canvas = page.getCanvas();

            // Background canvas
            canvas.drawColor(Color.WHITE);

            // Red Header Band
            Paint redBand = new Paint();
            redBand.setColor(Color.rgb(211, 47, 47));
            canvas.drawRect(0, 0, pageWidth, 8, redBand);

            // Document Title
            canvas.drawText(title, 40, 50, paintTitle);
            canvas.drawLine(40, 65, pageWidth - 40, 65, paintDivider);

            // Section Box
            canvas.drawRoundRect(40, 85, pageWidth - 40, 150, 8, 8, paintBox);
            canvas.drawRoundRect(40, 85, pageWidth - 40, 150, 8, 8, paintBoxBorder);
            canvas.drawText("Chapter " + p + ": Detailed Analytical Review", 55, 115, paintHeader);
            canvas.drawText("Document Reference ID: DOC-2026-" + p + " • Confidential", 55, 135, paintBody);

            int y = 185;
            for (int i = 0; i < points.length; i++) {
                canvas.drawCircle(50, y - 4, 3, paintTitle);
                canvas.drawText(points[i], 65, y, paintHeader);
                y += 24;
                canvas.drawText("Comprehensive analysis including technical parameters, metric evaluations,", 65, y, paintBody);
                y += 18;
                canvas.drawText("standard compliance checklists, and cross-functional performance reviews.", 65, y, paintBody);
                y += 36;
            }

            // Page footer
            canvas.drawLine(40, pageHeight - 50, pageWidth - 40, pageHeight - 50, paintDivider);
            canvas.drawText("PDF Assistant & Reader • Native Android System", 40, pageHeight - 30, paintBody);
            canvas.drawText("Page " + p + " of " + numPages, pageWidth - 110, pageHeight - 30, paintBody);

            document.finishPage(page);
        }

        try {
            FileOutputStream fos = new FileOutputStream(file);
            document.writeTo(fos);
            fos.close();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            document.close();
        }
    }
}
