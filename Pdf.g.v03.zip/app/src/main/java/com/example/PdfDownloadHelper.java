package com.example;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import okhttp3.Cookie;
import okhttp3.CookieJar;
import okhttp3.HttpUrl;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.ResponseBody;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PdfDownloadHelper {

    public interface DownloadCallback {
        void onProgress(int percent, long downloadedBytes, long totalBytes);
        void onSuccess(File downloadedFile);
        void onError(String errorMessage);
    }

    public interface DownloadStateListener {
        void onDownloadProgress(String itemId, int percent, long downloadedBytes, long totalBytes);
        void onDownloadSuccess(String itemId, File file);
        void onDownloadError(String itemId, String errorMessage);
        void onDownloadPausedOrCancelled(String itemId, long downloadedBytes, long totalBytes);
    }

    public static class DownloadProgressState {
        public String itemId;
        public String title;
        public int percent = 0;
        public long downloadedBytes = 0;
        public long totalBytes = -1;
        public boolean isDownloading = false;
        public boolean isPaused = false;
        public String errorMessage = null;

        public DownloadProgressState(String itemId, String title) {
            this.itemId = itemId;
            this.title = title;
        }
    }

    private static PdfDownloadHelper instance;
    private final Context context;
    private final OkHttpClient httpClient;
    private final ExecutorService executor = Executors.newFixedThreadPool(3);
    private final Handler mainHandler = new Handler(Looper.getMainLooper());

    private final ConcurrentHashMap<String, DownloadProgressState> progressStates = new ConcurrentHashMap<>();
    private final ConcurrentHashMap<String, Boolean> cancelledDownloads = new ConcurrentHashMap<>();
    private final List<DownloadStateListener> stateListeners = new CopyOnWriteArrayList<>();
    private final Map<String, List<Cookie>> cookieStore = new ConcurrentHashMap<>();

    private PdfDownloadHelper(Context context) {
        this.context = context.getApplicationContext();
        this.httpClient = new OkHttpClient.Builder()
                .connectTimeout(30, TimeUnit.SECONDS)
                .readTimeout(180, TimeUnit.SECONDS)
                .followRedirects(true)
                .followSslRedirects(true)
                .cookieJar(new CookieJar() {
                    @Override
                    public void saveFromResponse(HttpUrl url, List<Cookie> cookies) {
                        List<Cookie> existing = cookieStore.get(url.host());
                        if (existing == null) {
                            existing = new CopyOnWriteArrayList<>();
                            cookieStore.put(url.host(), existing);
                        }
                        for (Cookie c : cookies) {
                            existing.removeIf(old -> old.name().equals(c.name()));
                            existing.add(c);
                        }
                    }

                    @Override
                    public List<Cookie> loadForRequest(HttpUrl url) {
                        List<Cookie> result = new ArrayList<>();
                        for (Map.Entry<String, List<Cookie>> entry : cookieStore.entrySet()) {
                            if (url.host().endsWith(entry.getKey()) || entry.getKey().endsWith(url.host())) {
                                result.addAll(entry.getValue());
                            }
                        }
                        return result;
                    }
                })
                .build();
    }

    public static synchronized PdfDownloadHelper getInstance(Context context) {
        if (instance == null) {
            instance = new PdfDownloadHelper(context);
        }
        return instance;
    }

    public void addStateListener(DownloadStateListener listener) {
        if (listener != null && !stateListeners.contains(listener)) {
            stateListeners.add(listener);
        }
    }

    public void removeStateListener(DownloadStateListener listener) {
        if (listener != null) {
            stateListeners.remove(listener);
        }
    }

    public boolean isDownloading(String itemId) {
        DownloadProgressState state = progressStates.get(itemId);
        return state != null && state.isDownloading;
    }

    public boolean hasActiveDownloads() {
        for (DownloadProgressState s : progressStates.values()) {
            if (s.isDownloading) return true;
        }
        return false;
    }

    public DownloadProgressState getProgressState(String itemId) {
        DownloadProgressState state = progressStates.get(itemId);
        if (state == null) {
            // Check if there is an existing .part file on disk for this item
            File downloadsDir = new UrlPdfManager(context).getDownloadsDirectory();
            String safeId = (itemId != null) ? itemId.replaceAll("[^a-zA-Z0-9_-]", "") : "";
            File partFile = new File(downloadsDir, "dl_" + safeId + ".part");
            if (partFile.exists() && partFile.length() > 0) {
                state = new DownloadProgressState(itemId, "Document");
                state.downloadedBytes = partFile.length();
                state.isPaused = true;
                progressStates.put(itemId, state);
            }
        }
        return state;
    }

    public void cancelDownload(String itemId) {
        if (itemId == null) return;
        cancelledDownloads.put(itemId, true);
        DownloadProgressState state = progressStates.get(itemId);
        if (state != null) {
            state.isDownloading = false;
            state.isPaused = true;
            final long curDownloaded = state.downloadedBytes;
            final long curTotal = state.totalBytes;
            mainHandler.post(() -> {
                for (DownloadStateListener l : stateListeners) {
                    l.onDownloadPausedOrCancelled(itemId, curDownloaded, curTotal);
                }
            });
        }
    }

    public void deletePartFile(String itemId) {
        if (itemId == null) return;
        cancelDownload(itemId);
        File downloadsDir = new UrlPdfManager(context).getDownloadsDirectory();
        String safeId = itemId.replaceAll("[^a-zA-Z0-9_-]", "");
        File partFile = new File(downloadsDir, "dl_" + safeId + ".part");
        if (partFile.exists()) {
            try { partFile.delete(); } catch (Exception ignored) {}
        }
        progressStates.remove(itemId);
    }

    public void downloadPdf(UrlPdfItem item, DownloadCallback callback) {
        if (item == null) {
            if (callback != null) callback.onError("Invalid item");
            return;
        }

        final String itemId = item.getId();
        cancelledDownloads.put(itemId, false);

        final DownloadProgressState state = progressStates.computeIfAbsent(itemId, id -> new DownloadProgressState(id, item.getTitle()));
        state.title = item.getTitle();
        state.isDownloading = true;
        state.isPaused = false;
        state.errorMessage = null;

        // Start Foreground Service so download continues in background even if app closes
        PdfDownloadService.startDownload(context, itemId, item.getTitle());

        executor.execute(() -> {
            File partFile = null;
            File finalFile = null;
            try {
                String fileId = UrlPdfManager.extractGoogleDriveFileId(item.getOriginalUrl());
                if (fileId == null) {
                    fileId = UrlPdfManager.extractGoogleDriveFileId(item.getDownloadUrl());
                }

                String downloadUrl;
                if (fileId != null && !fileId.isEmpty()) {
                    downloadUrl = "https://drive.usercontent.google.com/download?id=" + fileId + "&export=download&authuser=0&confirm=t";
                } else {
                    downloadUrl = item.getDownloadUrl();
                    if (downloadUrl == null || downloadUrl.isEmpty()) {
                        downloadUrl = UrlPdfManager.extractDirectDownloadUrl(item.getOriginalUrl());
                    }
                }

                File downloadsDir = new UrlPdfManager(context).getDownloadsDirectory();
                String safeId = itemId.replaceAll("[^a-zA-Z0-9_-]", "");
                partFile = new File(downloadsDir, "dl_" + safeId + ".part");

                long existingBytes = 0;
                boolean resumeRequested = false;
                if (partFile.exists() && partFile.length() > 0) {
                    existingBytes = partFile.length();
                    resumeRequested = true;
                }

                Request.Builder reqBuilder = new Request.Builder()
                        .url(downloadUrl)
                        .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36")
                        .header("Accept", "application/pdf,application/octet-stream,*/*;q=0.8")
                        .header("Accept-Language", "bn,en;q=0.9");

                if (resumeRequested) {
                    reqBuilder.header("Range", "bytes=" + existingBytes + "-");
                }

                Response response = httpClient.newCall(reqBuilder.build()).execute();
                ResponseBody body = response.body();
                if (body == null) {
                    throw new Exception("সার্ভার থেকে কোনো রেসপন্স পাওয়া যায়নি");
                }

                int statusCode = response.code();
                boolean isResumeSuccess = (statusCode == 206);

                // If resume wasn't accepted (200 OK), server restarts from beginning
                if (!isResumeSuccess && statusCode == 200) {
                    existingBytes = 0;
                }

                String contentType = body.contentType() != null ? body.contentType().toString().toLowerCase() : "";

                // High speed buffer: 64KB
                byte[] firstChunk = new byte[65536];
                InputStream rawIn = body.byteStream();
                int firstChunkSize = 0;
                int r;
                while (firstChunkSize < 65536 && (r = rawIn.read(firstChunk, firstChunkSize, 65536 - firstChunkSize)) != -1) {
                    firstChunkSize += r;
                }

                boolean isPdf = false;
                if (isResumeSuccess) {
                    // When resuming, the chunk is continuation, so we assume valid PDF stream
                    isPdf = true;
                } else if (firstChunkSize >= 4 &&
                        firstChunk[0] == 0x25 && firstChunk[1] == 0x50 &&
                        firstChunk[2] == 0x44 && firstChunk[3] == 0x46) {
                    isPdf = true; // Starts with %PDF
                }

                // If not PDF and looks like HTML (Google Drive warning/token confirmation):
                if (!isPdf && (contentType.contains("text/html") || startsWithHtml(firstChunk, firstChunkSize))) {
                    String initialHtml = new String(firstChunk, 0, firstChunkSize, "UTF-8");
                    rawIn.close();
                    response.close();

                    String confirmUrl = extractGoogleDriveConfirmUrl(initialHtml, fileId);
                    if (confirmUrl != null && !confirmUrl.isEmpty()) {
                        Request.Builder confirmBuilder = new Request.Builder()
                                .url(confirmUrl)
                                .header("User-Agent", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36")
                                .header("Accept", "application/pdf,application/octet-stream,*/*;q=0.8");

                        if (existingBytes > 0) {
                            confirmBuilder.header("Range", "bytes=" + existingBytes + "-");
                        }

                        response = httpClient.newCall(confirmBuilder.build()).execute();
                        body = response.body();
                        if (body == null) throw new Exception("কনফার্ম করার পর সার্ভার রেসপন্স দেয়নি");

                        if (response.code() == 206) {
                            isResumeSuccess = true;
                        } else if (response.code() == 200) {
                            isResumeSuccess = false;
                            existingBytes = 0;
                        }

                        rawIn = body.byteStream();
                        firstChunkSize = 0;
                        while (firstChunkSize < 65536 && (r = rawIn.read(firstChunk, firstChunkSize, 65536 - firstChunkSize)) != -1) {
                            firstChunkSize += r;
                        }

                        isPdf = isResumeSuccess || (firstChunkSize >= 4 &&
                                firstChunk[0] == 0x25 && firstChunk[1] == 0x50 &&
                                firstChunk[2] == 0x44 && firstChunk[3] == 0x46);
                    } else {
                        String errorExplanation = explainDriveHtmlError(initialHtml);
                        throw new Exception(errorExplanation);
                    }
                }

                if (!isPdf && !isResumeSuccess) {
                    rawIn.close();
                    response.close();
                    throw new Exception("গুগল ড্রাইভ থেকে সঠিক PDF ফাইল পাওয়া যায়নি। লিংকটির এক্সেস 'Anyone with the link' আছে কিনা নিশ্চিত করুন।");
                }

                // Check Content-Disposition for filename
                String disposition = response.header("Content-Disposition");
                if (disposition != null) {
                    String extractedName = UrlPdfManager.parseFilenameFromContentDisposition(disposition);
                    if (extractedName != null) {
                        String clean = UrlPdfManager.cleanExtractedTitle(extractedName);
                        if (clean != null && (item.getTitle() == null || item.getTitle().startsWith("Drive_Document_"))) {
                            item.setTitle(clean);
                        }
                    }
                }

                long totalBytes = -1;
                String contentRange = response.header("Content-Range");
                if (contentRange != null && contentRange.contains("/")) {
                    try {
                        String totalStr = contentRange.substring(contentRange.lastIndexOf("/") + 1).trim();
                        totalBytes = Long.parseLong(totalStr);
                    } catch (Exception ignored) {}
                }
                if (totalBytes <= 0) {
                    long bodyLen = body.contentLength();
                    if (bodyLen > 0) {
                        totalBytes = existingBytes + bodyLen;
                    }
                }

                // High-performance buffered streams (64KB buffer)
                BufferedInputStream bis = new BufferedInputStream(rawIn, 65536);
                BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(partFile, isResumeSuccess), 65536);

                if (firstChunkSize > 0) {
                    bos.write(firstChunk, 0, firstChunkSize);
                }

                byte[] buffer = new byte[65536];
                long downloadedBytes = existingBytes + firstChunkSize;
                int read;
                long lastProgressPost = 0;

                state.totalBytes = totalBytes;
                state.downloadedBytes = downloadedBytes;

                while ((read = bis.read(buffer)) != -1) {
                    if (Boolean.TRUE.equals(cancelledDownloads.get(itemId))) {
                        // User cancelled / paused the download
                        bos.flush();
                        bos.close();
                        bis.close();
                        response.close();

                        state.isDownloading = false;
                        state.isPaused = true;
                        state.downloadedBytes = downloadedBytes;
                        final long curDownloaded = downloadedBytes;
                        final long curTotal = totalBytes;

                        mainHandler.post(() -> {
                            for (DownloadStateListener l : stateListeners) {
                                l.onDownloadPausedOrCancelled(itemId, curDownloaded, curTotal);
                            }
                        });
                        return;
                    }

                    bos.write(buffer, 0, read);
                    downloadedBytes += read;

                    long now = System.currentTimeMillis();
                    if (now - lastProgressPost > 180 || (totalBytes > 0 && downloadedBytes == totalBytes)) {
                        lastProgressPost = now;
                        final long curDownloaded = downloadedBytes;
                        final long curTotal = totalBytes;
                        final int percent = (curTotal > 0) ? (int) ((curDownloaded * 100) / curTotal) : -1;

                        state.percent = percent;
                        state.downloadedBytes = curDownloaded;
                        state.totalBytes = curTotal;

                        mainHandler.post(() -> {
                            if (callback != null) callback.onProgress(percent, curDownloaded, curTotal);
                            for (DownloadStateListener l : stateListeners) {
                                l.onDownloadProgress(itemId, percent, curDownloaded, curTotal);
                            }
                        });
                    }
                }

                bos.flush();
                bos.close();
                bis.close();
                response.close();

                // Verify file header validity
                if (!partFile.exists() || !UrlPdfManager.isValidPdfFile(partFile)) {
                    if (partFile.exists()) partFile.delete();
                    throw new Exception("ডাউনলোড সম্পূর্ণ হলেও ফাইলটি সঠিক PDF নয়");
                }

                String cleanTitle = PdfUtils.cleanPdfName(item.getTitle());
                String safeName = cleanTitle.replaceAll("[^a-zA-Z0-9._\\u0980-\\u09FF -]", " ").trim();
                if (safeName.isEmpty()) {
                    safeName = "Document";
                }
                if (!safeName.toLowerCase().endsWith(".pdf")) {
                    safeName += ".pdf";
                }
                finalFile = new File(downloadsDir, safeName);
                if (finalFile.exists()) {
                    // Unique naming without ugly dl_url_ prefix
                    String baseName = safeName.substring(0, safeName.length() - 4).trim();
                    int count = 1;
                    while (finalFile.exists()) {
                        finalFile = new File(downloadsDir, baseName + " (" + count + ").pdf");
                        count++;
                    }
                }
                boolean renamed = partFile.renameTo(finalFile);
                if (!renamed) {
                    finalFile = partFile; // fallback if rename fails
                }

                state.isDownloading = false;
                state.isPaused = false;
                state.percent = 100;
                state.downloadedBytes = finalFile.length();
                state.totalBytes = finalFile.length();

                // Auto generate thumbnail from first page if not already chosen by user
                if (item.getCoverImagePath() == null || !new File(item.getCoverImagePath()).exists()) {
                    String thumbPath = PdfUtils.generateAndSaveFirstPageThumbnail(context, finalFile, item.getId());
                    if (thumbPath != null) {
                        item.setCoverImagePath(thumbPath);
                    }
                }

                item.setLocalFilePath(finalFile.getAbsolutePath());
                item.setDownloaded(true);
                item.setFileSize(finalFile.length());
                new UrlPdfManager(context).saveItem(item);

                final File completedFile = finalFile;
                mainHandler.post(() -> {
                    if (callback != null) callback.onSuccess(completedFile);
                    for (DownloadStateListener l : stateListeners) {
                        l.onDownloadSuccess(itemId, completedFile);
                    }
                });

            } catch (Exception e) {
                state.isDownloading = false;
                state.isPaused = (partFile != null && partFile.exists() && partFile.length() > 0);
                state.errorMessage = e.getMessage() != null ? e.getMessage() : "ডাউনলোড ব্যর্থ হয়েছে";

                final String msg = state.errorMessage;
                mainHandler.post(() -> {
                    if (callback != null) callback.onError(msg);
                    for (DownloadStateListener l : stateListeners) {
                        l.onDownloadError(itemId, msg);
                    }
                });
            }
        });
    }

    public static String toBanglaDigits(String input) {
        if (input == null) return "";
        return input.replace('0', '০')
                .replace('1', '১')
                .replace('2', '২')
                .replace('3', '৩')
                .replace('4', '৪')
                .replace('5', '৫')
                .replace('6', '৬')
                .replace('7', '৭')
                .replace('8', '৮')
                .replace('9', '৯');
    }

    public static String formatBanglaSize(long bytes) {
        if (bytes <= 0) return "০ MB";
        double mb = bytes / (1024.0 * 1024.0);
        String formatted;
        if (mb < 0.1) {
            formatted = String.format(java.util.Locale.US, "%.2f MB", mb);
        } else if (mb >= 100) {
            formatted = String.format(java.util.Locale.US, "%.0f MB", mb);
        } else {
            formatted = String.format(java.util.Locale.US, "%.1f MB", mb);
        }
        return toBanglaDigits(formatted);
    }

    private static boolean startsWithHtml(byte[] bytes, int len) {
        if (len < 5) return false;
        String start = new String(bytes, 0, Math.min(len, 64)).trim().toLowerCase();
        return start.startsWith("<!doctype") || start.startsWith("<html") || start.startsWith("<?xml");
    }

    private static String extractGoogleDriveConfirmUrl(String html, String fileId) {
        if (html == null) return null;

        Pattern pForm = Pattern.compile("<form[^>]+id=[\"']download-form[\"'][^>]+action=[\"'](.*?)[\"']", Pattern.CASE_INSENSITIVE);
        Matcher mForm = pForm.matcher(html);
        String action = null;
        if (mForm.find()) {
            action = mForm.group(1);
        } else {
            Pattern pForm2 = Pattern.compile("<form[^>]+action=[\"'](https://drive\\.usercontent\\.google\\.com/download.*?)[\"']", Pattern.CASE_INSENSITIVE);
            Matcher mForm2 = pForm2.matcher(html);
            if (mForm2.find()) {
                action = mForm2.group(1);
            }
        }

        Pattern pConfirm = Pattern.compile("<input[^>]+name=[\"']confirm[\"'][^>]+value=[\"'](.*?)[\"']", Pattern.CASE_INSENSITIVE);
        Matcher mConfirm = pConfirm.matcher(html);
        String confirmVal = "t";
        if (mConfirm.find()) {
            confirmVal = mConfirm.group(1);
        }

        Pattern pUuid = Pattern.compile("<input[^>]+name=[\"']uuid[\"'][^>]+value=[\"'](.*?)[\"']", Pattern.CASE_INSENSITIVE);
        Matcher mUuid = pUuid.matcher(html);
        String uuidVal = null;
        if (mUuid.find()) {
            uuidVal = mUuid.group(1);
        }

        if (action != null) {
            String url = action;
            if (!url.startsWith("http")) {
                url = "https://drive.google.com" + (url.startsWith("/") ? "" : "/") + url;
            }
            if (!url.contains("confirm=")) {
                url += (url.contains("?") ? "&" : "?") + "confirm=" + confirmVal;
            }
            if (uuidVal != null && !url.contains("uuid=")) {
                url += "&uuid=" + uuidVal;
            }
            if (fileId != null && !url.contains("id=")) {
                url += "&id=" + fileId;
            }
            if (!url.contains("export=download")) {
                url += "&export=download";
            }
            return url;
        }

        Pattern pLink = Pattern.compile("<a[^>]+id=[\"']uc-download-link[\"'][^>]+href=[\"'](.*?)[\"']", Pattern.CASE_INSENSITIVE);
        Matcher mLink = pLink.matcher(html);
        if (mLink.find()) {
            String href = mLink.group(1).replace("&amp;", "&");
            if (!href.startsWith("http")) {
                href = "https://drive.google.com" + (href.startsWith("/") ? "" : "/") + href;
            }
            return href;
        }

        if (fileId != null) {
            return "https://drive.google.com/uc?export=download&id=" + fileId + "&confirm=t";
        }

        return null;
    }

    private static String explainDriveHtmlError(String html) {
        if (html == null) return "ড্রাইভ ফাইলটি ডাউনলোড করা সম্ভব হয়নি";
        String lower = html.toLowerCase();
        if (lower.contains("you need permission") || lower.contains("access denied") || lower.contains("request access") || lower.contains("sign-in - google accounts")) {
            return "ফাইলটিতে পাবলিক এক্সেস নেই। ড্রাইভ ফাইলটি 'Anyone with the link' শেয়ার করা আছে কিনা নিশ্চিত করুন।";
        }
        if (lower.contains("file not found") || lower.contains("does not exist") || lower.contains("error 404")) {
            return "Google Drive-এ ফাইলটি খুঁজে পাওয়া যায়নি। লিংকটি সঠিক কিনা যাচাই করুন।";
        }
        if (lower.contains("download quota") || lower.contains("too many users") || lower.contains("traffic limit")) {
            return "গুগল ড্রাইভ ডাউনলোডের লিমিট শেষ হয়েছে। কিছুক্ষণ পর পুনরায় চেষ্টা করুন।";
        }
        return "গুগল ড্রাইভের রেসপন্স যাচাই ব্যর্থ হয়েছে। লিংকটি সঠিক ও পাবলিক কিনা চেক করুন।";
    }
}
