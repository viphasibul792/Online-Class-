package com.example;

import android.content.Context;
import android.content.SharedPreferences;
import org.json.JSONArray;
import org.json.JSONObject;
import java.io.File;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;

public class PdfNotesManager {

    private static final String PREF_NAME = "pdf_user_notes_prefs";
    private static final String KEY_PREFIX = "note_";
    private static final String KEY_UNLIMITED_PREFIX = "unlimited_note_";
    private static final String KEY_PAGE_COUNTER_PREFIX = "page_counter_";
    public static final String COLUMN_SPLIT_DELIMITER = "\n===COLUMN_BREAK===\n";

    public static final String DEFAULT_NOTE_TEMPLATE_CH1 =
            "অধ্যায়:০১ name= here type  পৃষ্ঠা= Type\n" +
            "ক প্রশ্ন: পৃষ্ঠা= Type\n" +
            "খ প্রশ্ন : পৃষ্ঠা= Type\n" +
            "সৃজনশীল প্রশ্ন : পৃষ্ঠা= Type\n" +
            "Extra পৃষ্ঠা= Type";

    private final SharedPreferences prefs;

    public PdfNotesManager(Context context) {
        this.prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
    }

    private String getSafeKey(String pdfIdentifier) {
        if (pdfIdentifier == null) return "unknown_pdf";
        return KEY_PREFIX + pdfIdentifier.hashCode();
    }

    public float getNoteFontSize() {
        return prefs.getFloat("note_font_size", 12.5f);
    }

    public void saveNoteFontSize(float sp) {
        prefs.edit().putFloat("note_font_size", sp).apply();
    }

    public boolean isTwoColumnMode() {
        return prefs.getBoolean("note_two_column_mode", true);
    }

    public void setTwoColumnMode(boolean twoCol) {
        prefs.edit().putBoolean("note_two_column_mode", twoCol).apply();
    }

    /**
     * Retrieves unlimited note for a specific PDF.
     */
    public String getUnlimitedNoteForPdf(String pdfIdentifier) {
        if (pdfIdentifier == null) return "";
        String key = KEY_UNLIMITED_PREFIX + pdfIdentifier.hashCode();
        if (prefs.contains(key)) {
            return prefs.getString(key, "");
        }
        if (pdfIdentifier.contains("/") || pdfIdentifier.contains("\\")) {
            String name = new File(pdfIdentifier).getName();
            String altKey = KEY_UNLIMITED_PREFIX + name.hashCode();
            if (prefs.contains(altKey)) {
                return prefs.getString(altKey, "");
            }
        }
        return "";
    }

    /**
     * Saves unlimited note for a specific PDF.
     */
    public void saveUnlimitedNoteForPdf(String pdfIdentifier, String noteText) {
        if (pdfIdentifier == null) return;
        String key = KEY_UNLIMITED_PREFIX + pdfIdentifier.hashCode();
        String safeText = noteText != null ? noteText : "";
        prefs.edit()
                .putString(key, safeText)
                .putString("id_map_" + key, pdfIdentifier)
                .apply();
        if (pdfIdentifier.contains("/") || pdfIdentifier.contains("\\")) {
            String name = new File(pdfIdentifier).getName();
            String nameKey = KEY_UNLIMITED_PREFIX + name.hashCode();
            prefs.edit().putString(nameKey, safeText).apply();
        }
    }

    /**
     * Gets the last used page counter for the (+ পৃষ্ঠা) button for this PDF.
     */
    public int getLastUnlimitedPageForPdf(String pdfIdentifier) {
        if (pdfIdentifier == null) return 0;
        String key = KEY_PAGE_COUNTER_PREFIX + pdfIdentifier.hashCode();
        if (prefs.contains(key)) {
            return prefs.getInt(key, 0);
        }
        if (pdfIdentifier.contains("/") || pdfIdentifier.contains("\\")) {
            String name = new File(pdfIdentifier).getName();
            String altKey = KEY_PAGE_COUNTER_PREFIX + name.hashCode();
            if (prefs.contains(altKey)) {
                return prefs.getInt(altKey, 0);
            }
        }
        return 0;
    }

    /**
     * Saves the last used page counter for this PDF.
     */
    public void saveLastUnlimitedPageForPdf(String pdfIdentifier, int pageNumber) {
        if (pdfIdentifier == null) return;
        String key = KEY_PAGE_COUNTER_PREFIX + pdfIdentifier.hashCode();
        prefs.edit().putInt(key, pageNumber).apply();
        if (pdfIdentifier.contains("/") || pdfIdentifier.contains("\\")) {
            String name = new File(pdfIdentifier).getName();
            String nameKey = KEY_PAGE_COUNTER_PREFIX + name.hashCode();
            prefs.edit().putInt(nameKey, pageNumber).apply();
        }
    }

    // ---------------------------------------------------------------------
    // Lens Copy / Auto Agent support: append OCR text straight into the
    // Unlimited Note data source, with duplicate-page protection and progress.
    // ---------------------------------------------------------------------

    /** Exactly two fully blank lines between pages (previous text, \n, blank, blank, new text). */
    public static final String PAGE_SEPARATOR = "\n\n\n";

    private static final Object APPEND_LOCK = new Object();
    private static final String KEY_PASTED_PAGES_PREFIX = "lens_pasted_pages_";
    private static final String KEY_AGENT_LAST_PREFIX = "lens_agent_last_";
    private static final String KEY_AGENT_RUNNING_PREFIX = "lens_agent_running_";

    public Set<Integer> getPastedPages(String pdfIdentifier) {
        Set<Integer> result = new HashSet<>();
        if (pdfIdentifier == null) return result;
        String raw = prefs.getString(KEY_PASTED_PAGES_PREFIX + pdfIdentifier.hashCode(), "");
        if (raw == null || raw.isEmpty()) return result;
        for (String part : raw.split(",")) {
            try { result.add(Integer.parseInt(part.trim())); } catch (NumberFormatException ignored) {}
        }
        return result;
    }

    public boolean isPagePasted(String pdfIdentifier, int pageIndex) {
        return getPastedPages(pdfIdentifier).contains(pageIndex);
    }

    private void savePastedPages(String pdfIdentifier, Set<Integer> pages) {
        StringBuilder sb = new StringBuilder();
        for (Integer p : pages) {
            if (sb.length() > 0) sb.append(',');
            sb.append(p);
        }
        prefs.edit().putString(KEY_PASTED_PAGES_PREFIX + pdfIdentifier.hashCode(), sb.toString()).apply();
    }

    /** Forget which pages were pasted (used when the user clears the Unlimited Note). */
    public void clearPastedPages(String pdfIdentifier) {
        if (pdfIdentifier == null) return;
        prefs.edit()
                .remove(KEY_PASTED_PAGES_PREFIX + pdfIdentifier.hashCode())
                .remove(KEY_AGENT_LAST_PREFIX + pdfIdentifier.hashCode())
                .remove(KEY_AGENT_RUNNING_PREFIX + pdfIdentifier.hashCode())
                .apply();
    }

    public void saveAgentProgress(String pdfIdentifier, int lastCompletedIndex, boolean running) {
        if (pdfIdentifier == null) return;
        prefs.edit()
                .putInt(KEY_AGENT_LAST_PREFIX + pdfIdentifier.hashCode(), lastCompletedIndex)
                .putBoolean(KEY_AGENT_RUNNING_PREFIX + pdfIdentifier.hashCode(), running)
                .apply();
    }

    /** True if a previous agent run for this PDF was interrupted (killed) before finishing. */
    public boolean wasAgentInterrupted(String pdfIdentifier) {
        return pdfIdentifier != null
                && prefs.getBoolean(KEY_AGENT_RUNNING_PREFIX + pdfIdentifier.hashCode(), false);
    }

    public int getAgentLastCompleted(String pdfIdentifier) {
        if (pdfIdentifier == null) return -1;
        return prefs.getInt(KEY_AGENT_LAST_PREFIX + pdfIdentifier.hashCode(), -1);
    }

    /**
     * Appends the text of one PDF page to the end of the Unlimited Note. Never replaces or deletes
     * existing text. Returns false (and writes nothing) if the page was already pasted, or if the
     * write could not be verified.
     */
    public boolean appendPageToUnlimitedNote(String pdfIdentifier, int pageIndex, String pageText) {
        if (pdfIdentifier == null || pageText == null) return false;
        String clean = pageText.trim();
        if (clean.isEmpty()) return false;
        synchronized (APPEND_LOCK) {
            String existing = getUnlimitedNoteForPdf(pdfIdentifier);
            Set<Integer> pasted = getPastedPages(pdfIdentifier);
            // Note was cleared by the user -> old "already pasted" marks are no longer valid.
            if (existing.trim().isEmpty() && !pasted.isEmpty()) {
                pasted.clear();
            }
            if (pasted.contains(pageIndex)) return false;

            String base = stripTrailingWhitespace(existing);
            String updated = base.isEmpty() ? clean : base + PAGE_SEPARATOR + clean;
            saveUnlimitedNoteForPdf(pdfIdentifier, updated);

            // Verify the paste really landed at the end of the note.
            String verify = getUnlimitedNoteForPdf(pdfIdentifier);
            if (!verify.equals(updated)) {
                saveUnlimitedNoteForPdf(pdfIdentifier, existing); // roll back
                return false;
            }
            pasted.add(pageIndex);
            savePastedPages(pdfIdentifier, pasted);
            return true;
        }
    }

    private static String stripTrailingWhitespace(String s) {
        int end = s.length();
        while (end > 0 && Character.isWhitespace(s.charAt(end - 1))) end--;
        return s.substring(0, end);
    }

    public boolean hasCustomNotes(String pdfIdentifier) {
        if (pdfIdentifier == null) return false;
        String baseKey = getSafeKey(pdfIdentifier);
        if (prefs.contains(baseKey + "_col1") || prefs.contains(baseKey + "_col2") || prefs.contains(baseKey)) {
            return true;
        }
        if (pdfIdentifier.contains("/") || pdfIdentifier.contains("\\")) {
            String name = new File(pdfIdentifier).getName();
            String alt = getSafeKey(name);
            return prefs.contains(alt + "_col1") || prefs.contains(alt + "_col2") || prefs.contains(alt);
        }
        return false;
    }

    /**
     * Retrieves column 1 notes. Defaults to Chapters 01 to 05 if not saved yet.
     */
    public String getNoteCol1ForPdf(String pdfIdentifier) {
        if (pdfIdentifier == null) return generateChapters(1, 5);
        String key = getSafeKey(pdfIdentifier) + "_col1";
        if (prefs.contains(key)) {
            return prefs.getString(key, generateChapters(1, 5));
        }
        if (pdfIdentifier.contains("/") || pdfIdentifier.contains("\\")) {
            String name = new File(pdfIdentifier).getName();
            String altKey = getSafeKey(name) + "_col1";
            if (prefs.contains(altKey)) {
                return prefs.getString(altKey, generateChapters(1, 5));
            }
        }
        String legacy = getLegacyNote(pdfIdentifier);
        if (legacy != null && legacy.contains(COLUMN_SPLIT_DELIMITER)) {
            String[] parts = legacy.split(Pattern.quote(COLUMN_SPLIT_DELIMITER), 2);
            return parts[0];
        } else if (legacy != null && !legacy.trim().isEmpty() && !legacy.equals(DEFAULT_NOTE_TEMPLATE_CH1)) {
            return legacy;
        }
        return generateChapters(1, 5);
    }

    /**
     * Retrieves column 2 notes. Defaults to Chapters 06 to 10 if not saved yet.
     */
    public String getNoteCol2ForPdf(String pdfIdentifier) {
        if (pdfIdentifier == null) return generateChapters(6, 5);
        String key = getSafeKey(pdfIdentifier) + "_col2";
        if (prefs.contains(key)) {
            return prefs.getString(key, generateChapters(6, 5));
        }
        if (pdfIdentifier.contains("/") || pdfIdentifier.contains("\\")) {
            String name = new File(pdfIdentifier).getName();
            String altKey = getSafeKey(name) + "_col2";
            if (prefs.contains(altKey)) {
                return prefs.getString(altKey, generateChapters(6, 5));
            }
        }
        String legacy = getLegacyNote(pdfIdentifier);
        if (legacy != null && legacy.contains(COLUMN_SPLIT_DELIMITER)) {
            String[] parts = legacy.split(Pattern.quote(COLUMN_SPLIT_DELIMITER), 2);
            return parts.length > 1 ? parts[1] : "";
        }
        return generateChapters(6, 5);
    }

    private String getLegacyNote(String pdfIdentifier) {
        String key = getSafeKey(pdfIdentifier);
        return prefs.getString(key, null);
    }

    public String getNoteForPdf(String pdfIdentifier) {
        String key = getSafeKey(pdfIdentifier);
        if (prefs.contains(key)) {
            return prefs.getString(key, generateDefault10Chapters());
        }
        String c1 = prefs.getString(key + "_col1", null);
        String c2 = prefs.getString(key + "_col2", null);
        if (c1 != null || c2 != null) {
            return (c1 != null ? c1 : "") + "\n\n" + (c2 != null ? c2 : "");
        }
        return generateDefault10Chapters();
    }

    public void saveNoteForPdf(String pdfIdentifier, String noteText) {
        String key = getSafeKey(pdfIdentifier);
        prefs.edit()
                .putString(key, noteText)
                .putString("id_map_" + key, pdfIdentifier != null ? pdfIdentifier : "")
                .apply();
    }

    public void saveTwoColumnNotes(String pdfIdentifier, String col1, String col2) {
        String baseKey = getSafeKey(pdfIdentifier);
        String safeCol1 = col1 != null ? col1 : "";
        String safeCol2 = col2 != null ? col2 : "";
        prefs.edit()
                .putString(baseKey + "_col1", safeCol1)
                .putString(baseKey + "_col2", safeCol2)
                .putString(baseKey, safeCol1 + COLUMN_SPLIT_DELIMITER + safeCol2)
                .putString("id_map_" + baseKey, pdfIdentifier != null ? pdfIdentifier : "")
                .apply();
        if (pdfIdentifier != null && (pdfIdentifier.contains("/") || pdfIdentifier.contains("\\"))) {
            String name = new File(pdfIdentifier).getName();
            String nameKey = getSafeKey(name);
            prefs.edit()
                    .putString(nameKey + "_col1", safeCol1)
                    .putString(nameKey + "_col2", safeCol2)
                    .putString(nameKey, safeCol1 + COLUMN_SPLIT_DELIMITER + safeCol2)
                    .apply();
        }
    }

    public void clearNoteForPdf(String pdfIdentifier) {
        String baseKey = getSafeKey(pdfIdentifier);
        prefs.edit()
                .remove(baseKey)
                .remove(baseKey + "_col1")
                .remove(baseKey + "_col2")
                .remove("id_map_" + baseKey)
                .apply();
    }

    /**
     * Exports all notes saved in the application into a JSONArray for JSON backup.
     */
    public JSONArray exportAllNotesAsJson() {
        JSONArray notesArray = new JSONArray();
        try {
            Map<String, ?> all = prefs.getAll();
            Set<String> processedBases = new HashSet<>();

            for (String key : all.keySet()) {
                if (key.startsWith(KEY_PREFIX) && !key.endsWith("_col1") && !key.endsWith("_col2")) {
                    String baseKey = key;
                    if (!processedBases.contains(baseKey)) {
                        processedBases.add(baseKey);
                        JSONObject noteObj = new JSONObject();
                        noteObj.put("baseKey", baseKey);
                        String identifier = prefs.getString("id_map_" + baseKey, "");
                        noteObj.put("pdfIdentifier", identifier);
                        String col1 = prefs.getString(baseKey + "_col1", "");
                        String col2 = prefs.getString(baseKey + "_col2", "");
                        String combined = prefs.getString(baseKey, "");
                        noteObj.put("col1", col1);
                        noteObj.put("col2", col2);
                        noteObj.put("notes", combined);

                        if (!identifier.isEmpty()) {
                            String unlim = getUnlimitedNoteForPdf(identifier);
                            if (!unlim.isEmpty()) {
                                noteObj.put("unlimited_note", unlim);
                            }
                            int pageCounter = getLastUnlimitedPageForPdf(identifier);
                            if (pageCounter > 0) {
                                noteObj.put("last_page_counter", pageCounter);
                            }
                        }

                        notesArray.put(noteObj);
                    }
                } else if (key.startsWith(KEY_UNLIMITED_PREFIX)) {
                    String identifier = prefs.getString("id_map_" + key, "");
                    String baseKey = getSafeKey(identifier);
                    if (!processedBases.contains(baseKey)) {
                        processedBases.add(baseKey);
                        JSONObject noteObj = new JSONObject();
                        noteObj.put("baseKey", baseKey);
                        noteObj.put("pdfIdentifier", identifier);
                        String unlim = prefs.getString(key, "");
                        noteObj.put("unlimited_note", unlim);
                        if (!identifier.isEmpty()) {
                            int pageCounter = getLastUnlimitedPageForPdf(identifier);
                            if (pageCounter > 0) {
                                noteObj.put("last_page_counter", pageCounter);
                            }
                        }
                        notesArray.put(noteObj);
                    }
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return notesArray;
    }

    /**
     * Restores notes from a JSONArray into SharedPreferences.
     */
    public void restoreNotesFromJson(JSONArray notesArray) {
        if (notesArray == null) return;
        SharedPreferences.Editor editor = prefs.edit();
        for (int i = 0; i < notesArray.length(); i++) {
            try {
                JSONObject noteObj = notesArray.getJSONObject(i);
                String baseKey = noteObj.optString("baseKey", "");
                String pdfId = noteObj.optString("pdfIdentifier", "");
                String col1 = noteObj.optString("col1", "");
                String col2 = noteObj.optString("col2", "");
                String combined = noteObj.optString("notes", "");
                String unlim = noteObj.optString("unlimited_note", "");
                int lastPage = noteObj.optInt("last_page_counter", 0);

                if (baseKey.isEmpty() && !pdfId.isEmpty()) {
                    baseKey = getSafeKey(pdfId);
                }

                if (!baseKey.isEmpty()) {
                    if (!col1.isEmpty()) editor.putString(baseKey + "_col1", col1);
                    if (!col2.isEmpty()) editor.putString(baseKey + "_col2", col2);
                    if (!combined.isEmpty()) {
                        editor.putString(baseKey, combined);
                    } else if (!col1.isEmpty() || !col2.isEmpty()) {
                        editor.putString(baseKey, col1 + COLUMN_SPLIT_DELIMITER + col2);
                    }
                    if (!pdfId.isEmpty()) {
                        editor.putString("id_map_" + baseKey, pdfId);
                        String altKey = getSafeKey(pdfId);
                        if (!altKey.equals(baseKey)) {
                            if (!col1.isEmpty()) editor.putString(altKey + "_col1", col1);
                            if (!col2.isEmpty()) editor.putString(altKey + "_col2", col2);
                            editor.putString(altKey, col1 + COLUMN_SPLIT_DELIMITER + col2);
                        }
                        if (pdfId.contains("/") || pdfId.contains("\\")) {
                            String fName = new File(pdfId).getName();
                            String nameKey = getSafeKey(fName);
                            if (!col1.isEmpty()) editor.putString(nameKey + "_col1", col1);
                            if (!col2.isEmpty()) editor.putString(nameKey + "_col2", col2);
                            editor.putString(nameKey, col1 + COLUMN_SPLIT_DELIMITER + col2);
                        }
                        if (!unlim.isEmpty()) {
                            saveUnlimitedNoteForPdf(pdfId, unlim);
                        }
                        if (lastPage > 0) {
                            saveLastUnlimitedPageForPdf(pdfId, lastPage);
                        }
                    }
                }
            } catch (Exception ignored) {}
        }
        editor.apply();
    }

    public static String generateChapterBlock(int chapterNumber) {
        String bnNum = toBengaliDigits(chapterNumber);
        return "অধ্যায়:" + bnNum + " name= here type  পৃষ্ঠা= Type\n" +
                "ক প্রশ্ন: পৃষ্ঠা= Type\n" +
                "খ প্রশ্ন : পৃষ্ঠা= Type\n" +
                "সৃজনশীল প্রশ্ন : পৃষ্ঠা= Type\n" +
                "Extra পৃষ্ঠা= Type";
    }

    public static String generateChapters(int startChapter, int count) {
        StringBuilder sb = new StringBuilder();
        for (int i = startChapter; i < startChapter + count; i++) {
            if (sb.length() > 0) sb.append("\n\n");
            sb.append(generateChapterBlock(i));
        }
        return sb.toString();
    }

    public static String generateDefault10Chapters() {
        return generateChapters(1, 10);
    }

    public static String generateChapterTemplate(int chapterNumber) {
        return "\n\n" + generateChapterBlock(chapterNumber);
    }

    public static String toBengaliDigits(int number) {
        String numStr = String.format("%02d", number);
        StringBuilder sb = new StringBuilder();
        for (char c : numStr.toCharArray()) {
            switch (c) {
                case '0': sb.append('০'); break;
                case '1': sb.append('১'); break;
                case '2': sb.append('২'); break;
                case '3': sb.append('৩'); break;
                case '4': sb.append('৪'); break;
                case '5': sb.append('৫'); break;
                case '6': sb.append('৬'); break;
                case '7': sb.append('৭'); break;
                case '8': sb.append('৮'); break;
                case '9': sb.append('৯'); break;
                default: sb.append(c); break;
            }
        }
        return sb.toString();
    }
}
