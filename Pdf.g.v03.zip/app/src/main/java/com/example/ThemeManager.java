package com.example;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import androidx.appcompat.app.AppCompatDelegate;
import com.google.android.material.color.DynamicColors;

public class ThemeManager {

    private static final String PREF_NAME = "pdf_theme_prefs";
    private static final String KEY_DARK_MODE = "is_dark_mode";

    public static boolean isDarkMode(Context context) {
        SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        return prefs.getBoolean(KEY_DARK_MODE, false);
    }

    public static void setDarkMode(Context context, boolean darkMode) {
        SharedPreferences prefs = context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE);
        prefs.edit().putBoolean(KEY_DARK_MODE, darkMode).apply();
        applyTheme(darkMode);
    }

    public static void applySavedTheme(Context context) {
        boolean dark = isDarkMode(context);
        applyTheme(dark);
        if (context instanceof Activity) {
            DynamicColors.applyIfAvailable((Activity) context);
        }
    }

    private static void applyTheme(boolean dark) {
        AppCompatDelegate.setDefaultNightMode(
                dark ? AppCompatDelegate.MODE_NIGHT_YES : AppCompatDelegate.MODE_NIGHT_NO
        );
    }
}
