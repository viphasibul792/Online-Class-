package com.example;

import android.app.Dialog;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.ColorMatrix;
import android.graphics.ColorMatrixColorFilter;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.pdf.PdfRenderer;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.ParcelFileDescriptor;
import android.provider.MediaStore;
import android.provider.Settings;
import android.text.TextUtils;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.card.MaterialCardView;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;

import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;

public class PdfViewerActivity extends AppCompatActivity implements
        PdfPagesAdapter.OnPageCropClickListener,
        PdfPagesAdapter.OnPageLensClickListener {

    public static final String EXTRA_PDF_PATH = "extra_pdf_path";
    public static final String EXTRA_PDF_URI = "extra_pdf_uri";
    public static final String EXTRA_PDF_NAME = "extra_pdf_name";

    private static final int REQUEST_OVERLAY_PERMISSION = 202;

    // Custom Slim Title Bar Views
    private ImageButton btnViewerBack;
    private TextView tvViewerAppTitle;
    private TextView tvViewerDocName;
    private ImageButton btnViewerLensPage;
    private ImageButton btnViewerCropPage;
    private ImageButton btnViewerSearchPage;
    private ImageButton btnViewerNotes;
    private ImageButton btnViewerShareDoc;

    // Scrolling PDF & Zoom Views
    private ZoomableFrameLayout zoomableContainer;
    private RecyclerView rvPdfPages;
    private ProgressBar viewerProgressBar;
    private MaterialCardView cardQuickPagePill;
    private TextView tvFloatingPageBadge;
    private MaterialCardView cardZoomBadge;
    private TextView tvZoomPercentage;

    // Fast Scroll Views (Requirement 7)
    private LinearLayout fastScrollContainer;
    private MaterialCardView cardFastScrollThumb;
    private MaterialCardView cardFastScrollTooltip;
    private TextView tvScrollTooltipText;
    private ImageButton btnScrollToTop;
    private ImageButton btnScrollToBottom;

    private LinearLayoutManager layoutManager;
    private PdfPagesAdapter pagesAdapter;

    private Uri pdfUri;
    private String pdfPath;
    private String pdfName = "Document.pdf";

    private ParcelFileDescriptor parcelFileDescriptor;
    private PdfRenderer pdfRenderer;
    private int totalPages = 0;
    private int currentVisiblePage = 0;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pdf_viewer);

        initViews();
        parseIntentData();
        setupListeners();
        loadPdfDocument();
    }

    private void initViews() {
        btnViewerBack = findViewById(R.id.btnViewerBack);
        tvViewerAppTitle = findViewById(R.id.tvViewerAppTitle);
        tvViewerDocName = findViewById(R.id.tvViewerDocName);
        btnViewerLensPage = findViewById(R.id.btnViewerLensPage);
        btnViewerCropPage = findViewById(R.id.btnViewerCropPage);
        btnViewerSearchPage = findViewById(R.id.btnViewerSearchPage);
        btnViewerNotes = findViewById(R.id.btnViewerNotes);
        btnViewerShareDoc = findViewById(R.id.btnViewerShareDoc);

        zoomableContainer = findViewById(R.id.zoomableContainer);
        rvPdfPages = findViewById(R.id.rvPdfPages);
        viewerProgressBar = findViewById(R.id.viewerProgressBar);
        cardQuickPagePill = findViewById(R.id.cardQuickPagePill);
        tvFloatingPageBadge = findViewById(R.id.tvFloatingPageBadge);
        cardZoomBadge = findViewById(R.id.cardZoomBadge);
        tvZoomPercentage = findViewById(R.id.tvZoomPercentage);

        fastScrollContainer = findViewById(R.id.fastScrollContainer);
        cardFastScrollThumb = findViewById(R.id.cardFastScrollThumb);
        cardFastScrollTooltip = findViewById(R.id.cardFastScrollTooltip);
        tvScrollTooltipText = findViewById(R.id.tvScrollTooltipText);
        btnScrollToTop = findViewById(R.id.btnScrollToTop);
        btnScrollToBottom = findViewById(R.id.btnScrollToBottom);

        layoutManager = new LinearLayoutManager(this);
        rvPdfPages.setLayoutManager(layoutManager);
    }

    private void parseIntentData() {
        Intent intent = getIntent();
        if (intent != null) {
            if (intent.hasExtra(EXTRA_PDF_NAME)) {
                pdfName = intent.getStringExtra(EXTRA_PDF_NAME);
            }
            if (intent.hasExtra(EXTRA_PDF_PATH)) {
                pdfPath = intent.getStringExtra(EXTRA_PDF_PATH);
            }
            if (intent.hasExtra(EXTRA_PDF_URI)) {
                String uriStr = intent.getStringExtra(EXTRA_PDF_URI);
                if (uriStr != null) {
                    pdfUri = Uri.parse(uriStr);
                }
            } else if (intent.getData() != null) {
                pdfUri = intent.getData();
                if (pdfUri.getLastPathSegment() != null) {
                    pdfName = pdfUri.getLastPathSegment();
                }
            }
        }

        if (pdfUri == null && pdfPath != null) {
            File f = new File(pdfPath);
            if (f.exists()) {
                pdfUri = Uri.fromFile(f);
                pdfName = f.getName();
            }
        }

        updateHeaderInfo(0);
    }

    private void setupListeners() {
        btnViewerBack.setOnClickListener(v -> finish());

        // Requirement 3 & 6: Search / Jump to page
        btnViewerSearchPage.setOnClickListener(v -> showJumpToPageDialog());

        // Requirement 5: Top bar Google Lens
        btnViewerLensPage.setOnClickListener(v -> {
            if (totalPages > 0) {
                openGoogleLensForPage(currentVisiblePage);
            } else {
                Toast.makeText(this, "PDF লোড হচ্ছে...", Toast.LENGTH_SHORT).show();
            }
        });

        // Requirement 4: In-app crop for current PDF page
        btnViewerCropPage.setOnClickListener(v -> {
            if (totalPages > 0) {
                showPageCropDialog(currentVisiblePage);
            } else {
                Toast.makeText(this, "PDF এখনও লোড হয়নি", Toast.LENGTH_SHORT).show();
            }
        });

        // Share whole PDF
        btnViewerShareDoc.setOnClickListener(v -> {
            PdfFile file = new PdfFile(0, pdfName, pdfPath, pdfUri, 0, System.currentTimeMillis());
            PdfUtils.sharePdf(this, file);
        });

        // Requirement 4 (Point 4): PDF Note-taking & Chapter Indexing
        btnViewerNotes.setOnClickListener(v -> openNotesDialog());

        // Bottom quick pill click -> Jump to page dialog
        cardQuickPagePill.setOnClickListener(v -> showJumpToPageDialog());

        // Zoom level listener and reset badge (Requirement 4)
        zoomableContainer.setOnZoomChangedListener(scale -> {
            int pct = Math.round(scale * 100);
            tvZoomPercentage.setText(String.format("%d%%", pct));
            cardZoomBadge.setVisibility(scale > 1.01f ? View.VISIBLE : View.GONE);
        });
        cardZoomBadge.setOnClickListener(v -> zoomableContainer.resetZoom());

        // Fast Scroll buttons & scrubbing (Requirement 7)
        btnScrollToTop.setOnClickListener(v -> {
            layoutManager.scrollToPositionWithOffset(0, 0);
            updateHeaderInfo(0);
        });

        btnScrollToBottom.setOnClickListener(v -> {
            if (totalPages > 0) {
                int last = totalPages - 1;
                layoutManager.scrollToPositionWithOffset(last, 0);
                updateHeaderInfo(last);
            }
        });

        setupFastScrollScrubber();

        // Continuous scrolling page listener (Requirement 2)
        rvPdfPages.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrolled(@NonNull RecyclerView recyclerView, int dx, int dy) {
                super.onScrolled(recyclerView, dx, dy);
                int firstVisible = layoutManager.findFirstVisibleItemPosition();
                if (firstVisible >= 0 && firstVisible != currentVisiblePage) {
                    currentVisiblePage = firstVisible;
                    updateHeaderInfo(currentVisiblePage);
                    updateFastScrollThumbPosition();
                }
            }
        });
    }

    private void setupFastScrollScrubber() {
        cardFastScrollThumb.setOnTouchListener(new View.OnTouchListener() {
            private float initialTouchY;
            private float initialThumbY;
            private boolean isDragging = false;

            @Override
            public boolean onTouch(View v, MotionEvent event) {
                if (totalPages <= 1) return false;

                switch (event.getAction()) {
                    case MotionEvent.ACTION_DOWN:
                        initialTouchY = event.getRawY();
                        initialThumbY = cardFastScrollThumb.getTranslationY();
                        isDragging = true;
                        cardFastScrollTooltip.setVisibility(View.VISIBLE);
                        v.getParent().requestDisallowInterceptTouchEvent(true);
                        return true;

                    case MotionEvent.ACTION_MOVE:
                        if (isDragging) {
                            float deltaY = event.getRawY() - initialTouchY;
                            float newThumbY = initialThumbY + deltaY;

                            View parent = (View) cardFastScrollThumb.getParent();
                            float maxTravel = Math.max(1, parent.getHeight() - cardFastScrollThumb.getHeight());
                            newThumbY = Math.max(0, Math.min(newThumbY, maxTravel));
                            cardFastScrollThumb.setTranslationY(newThumbY);

                            float fraction = newThumbY / maxTravel;
                            int targetPage = Math.max(0, Math.min(totalPages - 1, Math.round(fraction * (totalPages - 1))));

                            tvScrollTooltipText.setText(String.format("Page %d / %d", targetPage + 1, totalPages));
                            layoutManager.scrollToPositionWithOffset(targetPage, 0);
                            currentVisiblePage = targetPage;
                            updateHeaderInfo(targetPage);
                        }
                        return true;

                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        isDragging = false;
                        cardFastScrollTooltip.postDelayed(() -> cardFastScrollTooltip.setVisibility(View.GONE), 1000);
                        v.getParent().requestDisallowInterceptTouchEvent(false);
                        return true;
                }
                return false;
            }
        });
    }

    private void updateFastScrollThumbPosition() {
        if (totalPages <= 1) return;
        View parent = (View) cardFastScrollThumb.getParent();
        if (parent == null || parent.getHeight() <= 0) return;

        float fraction = (float) currentVisiblePage / (float) (totalPages - 1);
        float maxTravel = Math.max(0, parent.getHeight() - cardFastScrollThumb.getHeight());
        cardFastScrollThumb.animate()
                .translationY(fraction * maxTravel)
                .setDuration(100)
                .start();
    }

    private void updateHeaderInfo(int pageIndex) {
        String cleanName = pdfName;
        if (cleanName.toLowerCase().endsWith(".pdf")) {
            cleanName = cleanName.substring(0, cleanName.length() - 4);
        }
        if (totalPages > 0) {
            tvViewerDocName.setText(String.format("%s • Page %d/%d", cleanName, pageIndex + 1, totalPages));
            tvFloatingPageBadge.setText(String.format("Page %d / %d", pageIndex + 1, totalPages));
        } else {
            tvViewerDocName.setText(cleanName);
            tvFloatingPageBadge.setText("Loading...");
        }
    }

    private void loadPdfDocument() {
        if (pdfUri == null && (pdfPath == null || pdfPath.isEmpty())) {
            Toast.makeText(this, "কোনো বৈধ PDF পাওয়া যায়নি", Toast.LENGTH_SHORT).show();
            return;
        }

        File localFile = null;
        if (pdfPath != null && !pdfPath.isEmpty()) {
            localFile = new File(pdfPath);
        } else if (pdfUri != null && "file".equalsIgnoreCase(pdfUri.getScheme())) {
            localFile = new File(pdfUri.getPath());
        }

        // Check if file exists and starts with %PDF magic header
        if (localFile != null && localFile.exists() && !UrlPdfManager.isValidPdfFile(localFile)) {
            viewerProgressBar.setVisibility(View.GONE);
            showCorruptFileDialog(localFile);
            return;
        }

        viewerProgressBar.setVisibility(View.VISIBLE);

        try {
            if (localFile != null && localFile.exists()) {
                parcelFileDescriptor = ParcelFileDescriptor.open(localFile, ParcelFileDescriptor.MODE_READ_ONLY);
            } else if (pdfUri != null && "file".equalsIgnoreCase(pdfUri.getScheme())) {
                File file = new File(pdfUri.getPath());
                parcelFileDescriptor = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY);
            } else if (pdfUri != null) {
                parcelFileDescriptor = getContentResolver().openFileDescriptor(pdfUri, "r");
            } else if (pdfPath != null) {
                File file = new File(pdfPath);
                parcelFileDescriptor = ParcelFileDescriptor.open(file, ParcelFileDescriptor.MODE_READ_ONLY);
            }

            if (parcelFileDescriptor != null) {
                pdfRenderer = new PdfRenderer(parcelFileDescriptor);
                totalPages = pdfRenderer.getPageCount();

                pagesAdapter = new PdfPagesAdapter(this, pdfRenderer, totalPages, this, this);
                rvPdfPages.setAdapter(pagesAdapter);

                updateHeaderInfo(0);
            } else {
                Toast.makeText(this, "PDF ফাইল খোলা সম্ভব হয়নি", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e) {
            e.printStackTrace();
            showCorruptFileDialog(localFile);
        } finally {
            viewerProgressBar.setVisibility(View.GONE);
        }
    }

    private void showCorruptFileDialog(File file) {
        new MaterialAlertDialogBuilder(this)
                .setTitle("PDF লোড করা সম্ভব হয়নি")
                .setMessage("ফাইলটি সঠিক PDF নয় অথবা ডাউনলোড করার সময় গুগল ড্রাইভ পেজ সেভ হয়েছিল। ফাইলটি মুছে পুনরায় ডাউনলোড করতে চান?")
                .setPositiveButton("মুছে ফেলুন ও ফিরে যান", (dialog, which) -> {
                    if (file != null && file.exists()) {
                        try { file.delete(); } catch (Exception ignored) {}
                    }
                    finish();
                })
                .setNegativeButton("বন্ধ করুন", (dialog, which) -> finish())
                .setCancelable(false)
                .show();
    }

    // Requirement 3 & 6: Fixed & Robust Search / Jump to page dialog
    private void showJumpToPageDialog() {
        if (totalPages <= 0) {
            Toast.makeText(this, "PDF পেজ লোড হচ্ছে...", Toast.LENGTH_SHORT).show();
            return;
        }

        Dialog dialog = new Dialog(this);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_jump_to_page);

        if (dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawableResource(android.R.color.transparent);
            dialog.getWindow().setLayout(
                    (int) (getResources().getDisplayMetrics().widthPixels * 0.9f),
                    ViewGroup.LayoutParams.WRAP_CONTENT
            );
        }

        TextView tvSubtitle = dialog.findViewById(R.id.tvJumpSubtitle);
        EditText etPageNumber = dialog.findViewById(R.id.etTargetPageNumber);
        MaterialButton btnCancel = dialog.findViewById(R.id.btnCancelJump);
        MaterialButton btnConfirm = dialog.findViewById(R.id.btnConfirmJump);

        tvSubtitle.setText(String.format("পৃষ্ঠা ১ থেকে %d এর মধ্যে যেকোনো নম্বর লিখুন", totalPages));
        etPageNumber.setText(String.valueOf(currentVisiblePage + 1));
        etPageNumber.selectAll();

        btnCancel.setOnClickListener(v -> dialog.dismiss());

        btnConfirm.setOnClickListener(v -> {
            String input = etPageNumber.getText().toString().trim();
            if (TextUtils.isEmpty(input)) {
                Toast.makeText(this, "অনুগ্রহ করে একটি পৃষ্ঠা নম্বর লিখুন", Toast.LENGTH_SHORT).show();
                return;
            }

            try {
                int targetPage = Integer.parseInt(input);
                if (targetPage >= 1 && targetPage <= totalPages) {
                    dialog.dismiss();
                    int targetIndex = targetPage - 1;

                    // Guarantee scrolling with top offset = 0
                    currentVisiblePage = targetIndex;
                    layoutManager.scrollToPositionWithOffset(targetIndex, 0);
                    rvPdfPages.post(() -> {
                        layoutManager.scrollToPositionWithOffset(targetIndex, 0);
                        updateHeaderInfo(targetIndex);
                        updateFastScrollThumbPosition();
                    });

                    Toast.makeText(this, String.format("পৃষ্ঠা %d এ যাওয়া হয়েছে", targetPage), Toast.LENGTH_SHORT).show();
                } else {
                    Toast.makeText(this, String.format("১ থেকে %d এর মধ্যে পৃষ্ঠা লিখুন", totalPages), Toast.LENGTH_SHORT).show();
                }
            } catch (NumberFormatException e) {
                Toast.makeText(this, "সঠিক পৃষ্ঠা সংখ্যা লিখুন", Toast.LENGTH_SHORT).show();
            }
        });

        dialog.show();
    }

    // Requirement 4 (Point 4): Open PDF Notes Dialog
    private void openNotesDialog() {
        String identifier = (pdfPath != null && !pdfPath.isEmpty())
                ? pdfPath
                : (pdfName != null ? pdfName : "current_pdf");

        PdfNotesDialog dialog = PdfNotesDialog.newInstance(identifier, pdfName);
        dialog.setOnJumpToPageListener(this::jumpToPageNumber);
        dialog.show(getSupportFragmentManager(), "PdfNotesDialog");
    }

    public void jumpToPageNumber(int targetPage) {
        if (totalPages <= 0) return;
        int targetIndex = Math.max(0, Math.min(targetPage - 1, totalPages - 1));
        currentVisiblePage = targetIndex;
        layoutManager.scrollToPositionWithOffset(targetIndex, 0);
        rvPdfPages.post(() -> {
            layoutManager.scrollToPositionWithOffset(targetIndex, 0);
            updateHeaderInfo(targetIndex);
            updateFastScrollThumbPosition();
        });
        Toast.makeText(this, String.format("পৃষ্ঠা %d এ যাওয়া হয়েছে", targetIndex + 1), Toast.LENGTH_SHORT).show();
    }

    // Requirement 5: Open Google Lens for a specific page
    @Override
    public void onPageLensClick(int pageIndex, Bitmap pageBitmap) {
        openGoogleLensWithBitmap(pageIndex, pageBitmap);
    }

    private void openGoogleLensForPage(int pageIndex) {
        if (pagesAdapter == null) return;
        Bitmap bmp = pagesAdapter.getCachedBitmap(pageIndex);
        if (bmp == null) {
            int width = Math.max(1200, getResources().getDisplayMetrics().widthPixels * 3 / 2);
            bmp = pagesAdapter.renderPageBitmap(pageIndex, width);
        }
        openGoogleLensWithBitmap(pageIndex, bmp);
    }

    private static final int REQUEST_LENS_OVERLAY_PERMISSION = 203;
    private int pendingLensPage = -1;
    private String pendingLensImagePath = null;
    private boolean lensOverlayAskedOnce = false;

    private void openGoogleLensWithBitmap(int pageIndex, Bitmap pageBitmap) {
        if (pageBitmap == null) {
            Toast.makeText(this, "পেজ রেন্ডার করা যাচ্ছে না", Toast.LENGTH_SHORT).show();
            return;
        }

        // Save page bitmap to cache file for GoogleLens
        File cachedImg = PdfUtils.saveBitmapToCache(this, pageBitmap, "lens_page_" + (pageIndex + 1) + "_");
        if (cachedImg == null) {
            Toast.makeText(this, "Google Lens চালু করতে সমস্যা", Toast.LENGTH_SHORT).show();
            return;
        }

        // The floating ◀ ▶ bar on top of Google Lens needs the "display over other apps" permission.
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M
                && !Settings.canDrawOverlays(this) && !lensOverlayAskedOnce) {
            lensOverlayAskedOnce = true;
            pendingLensPage = pageIndex;
            pendingLensImagePath = cachedImg.getAbsolutePath();
            new MaterialAlertDialogBuilder(this)
                    .setTitle("Google Lens পৃষ্ঠা বার")
                    .setMessage("Google Lens এর উপরে ◀ ▶ বার দেখাতে 'অন্য অ্যাপের উপরে দেখানো' (Display over other apps) অনুমতি দিন। তাহলে অ্যাপে না ফিরেই Lens থেকে পরের/আগের পৃষ্ঠায় যেতে পারবেন।")
                    .setPositiveButton("অনুমতি দিন", (d, w) -> {
                        Intent intent = new Intent(
                                Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:" + getPackageName()));
                        startActivityForResult(intent, REQUEST_LENS_OVERLAY_PERMISSION);
                    })
                    .setNegativeButton("বার ছাড়া চালান", (d, w) -> launchLensNow(pendingLensPage, pendingLensImagePath))
                    .setOnCancelListener(d -> launchLensNow(pendingLensPage, pendingLensImagePath))
                    .show();
            return;
        }
        launchLensNow(pageIndex, cachedImg.getAbsolutePath());
    }

    private void launchLensNow(int pageIndex, String imagePath) {
        if (imagePath == null || pageIndex < 0) return;
        boolean launched = PdfUtils.launchOfficialGoogleLens(this, imagePath);
        if (!launched) {
            Intent lensIntent = new Intent(this, GoogleLensActivity.class);
            lensIntent.putExtra(GoogleLensActivity.EXTRA_IMAGE_PATH, imagePath);
            lensIntent.putExtra(GoogleLensActivity.EXTRA_PAGE_NUMBER, pageIndex + 1);
            startActivity(lensIntent);
            return;
        }
        startLensNavigatorBar(pageIndex);
    }

    private void startLensNavigatorBar(int pageIndex) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) return;
        try {
            Intent svc = new Intent(this, LensNavigatorService.class);
            if (pdfPath != null && new File(pdfPath).exists()) {
                svc.putExtra(LensNavigatorService.EXTRA_PDF_PATH, pdfPath);
            }
            if (pdfUri != null) {
                svc.putExtra(LensNavigatorService.EXTRA_PDF_URI, pdfUri.toString());
            }
            svc.putExtra(LensNavigatorService.EXTRA_PAGE_INDEX, pageIndex);
            svc.putExtra(LensNavigatorService.EXTRA_TOTAL_PAGES, totalPages);
            // Same identifier the Unlimited Note editor uses, so Copy / Agent write to the same note
            svc.putExtra(LensNavigatorService.EXTRA_NOTE_ID,
                    (pdfPath != null && !pdfPath.isEmpty()) ? pdfPath : (pdfName != null ? pdfName : "current_pdf"));
            svc.putExtra(LensNavigatorService.EXTRA_PDF_NAME, pdfName);
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                startForegroundService(svc);
            } else {
                startService(svc);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onStart() {
        super.onStart();
        // Back in the app: the Lens page bar is no longer needed
        if (LensNavigatorService.isRunning) {
            Intent stop = new Intent(this, LensNavigatorService.class);
            stop.setAction(LensNavigatorService.ACTION_STOP);
            try { startService(stop); } catch (Exception ignored) {}
        }
    }

    // Callback when "Crop Page" is clicked on a specific page item
    @Override
    public void onPageCropClick(int pageIndex, Bitmap pageBitmap) {
        showPageCropDialogWithBitmap(pageIndex, pageBitmap);
    }

    // Requirement 4: In-app PDF Page Crop Dialog
    private void showPageCropDialog(int pageIndex) {
        if (pagesAdapter == null) return;
        Bitmap bmp = pagesAdapter.getCachedBitmap(pageIndex);
        if (bmp == null) {
            int screenWidth = getResources().getDisplayMetrics().widthPixels;
            bmp = pagesAdapter.renderPageBitmap(pageIndex, screenWidth);
        }
        showPageCropDialogWithBitmap(pageIndex, bmp);
    }

    private void showPageCropDialogWithBitmap(int pageIndex, Bitmap pageBitmap) {
        if (pageBitmap == null) {
            Toast.makeText(this, "পেজ রেন্ডার করা যাচ্ছে না", Toast.LENGTH_SHORT).show();
            return;
        }

        Dialog dialog = new Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen);
        dialog.setContentView(R.layout.dialog_pdf_page_crop);

        ImageButton btnClose = dialog.findViewById(R.id.btnCropClose);
        TextView tvTitle = dialog.findViewById(R.id.tvCropDialogTitle);
        ImageView ivCropSource = dialog.findViewById(R.id.ivCropSource);
        CropOverlayView cropOverlay = dialog.findViewById(R.id.cropOverlay);
        MaterialButton btnCropInv = dialog.findViewById(R.id.btnCropInv);
        MaterialButton btnCropBW = dialog.findViewById(R.id.btnCropBW);
        MaterialButton btnCropDownload = dialog.findViewById(R.id.btnCropDownload);
        MaterialButton btnCropDw2 = dialog.findViewById(R.id.btnCropDw2);
        MaterialButton btnCopyPrompt = dialog.findViewById(R.id.btnCopyPromptOnly);
        MaterialButton btnSave = dialog.findViewById(R.id.btnSaveSnippetOnly);
        MaterialButton btnShareBottom = dialog.findViewById(R.id.btnCropShareBottom);
        MaterialButton btnShareTop = dialog.findViewById(R.id.btnCropShareTop);

        final int[] currentPage = {pageIndex};
        final Bitmap[] currentBitmap = {pageBitmap};

        MaterialButton btnCropPrevPage = dialog.findViewById(R.id.btnCropPrevPage);
        MaterialButton btnCropNextPage = dialog.findViewById(R.id.btnCropNextPage);
        TextView tvCropNavPageIndicator = dialog.findViewById(R.id.tvCropNavPageIndicator);

        ivCropSource.setImageBitmap(pageBitmap);

        // Tell CropOverlayView the exact bitmap dimensions for accurate fitCenter mapping!
        cropOverlay.setSourceImageDimensions(pageBitmap.getWidth(), pageBitmap.getHeight());
        cropOverlay.resetToFullBounds();

        // State variables for image filters (Invert and Black & White)
        final boolean[] isInverted = {false};
        final boolean[] isBlackAndWhite = {false};

        Runnable updateNavState = () -> {
            String pageText = String.format("Page %d/%d", currentPage[0] + 1, totalPages);
            tvTitle.setText(pageText);
            if (tvCropNavPageIndicator != null) {
                tvCropNavPageIndicator.setText(pageText);
            }
            if (btnCropPrevPage != null) {
                btnCropPrevPage.setEnabled(currentPage[0] > 0);
                btnCropPrevPage.setAlpha(currentPage[0] > 0 ? 1.0f : 0.35f);
            }
            if (btnCropNextPage != null) {
                btnCropNextPage.setEnabled(currentPage[0] < totalPages - 1);
                btnCropNextPage.setAlpha(currentPage[0] < totalPages - 1 ? 1.0f : 0.35f);
            }
        };
        updateNavState.run();

        Runnable updateFilterUI = () -> {
            // Apply color filter to ivCropSource for real-time visual preview
            if (!isInverted[0] && !isBlackAndWhite[0]) {
                ivCropSource.clearColorFilter();
            } else {
                ColorMatrix matrix = new ColorMatrix();
                if (isInverted[0] && isBlackAndWhite[0]) {
                    matrix.postConcat(getInvertColorMatrix());
                    ColorMatrix sat = new ColorMatrix();
                    sat.setSaturation(0);
                    matrix.postConcat(sat);
                } else if (isInverted[0]) {
                    matrix.postConcat(getInvertColorMatrix());
                } else if (isBlackAndWhite[0]) {
                    matrix.setSaturation(0);
                }
                ivCropSource.setColorFilter(new ColorMatrixColorFilter(matrix));
            }

            // Update button styles
            if (btnCropInv != null) {
                if (isInverted[0]) {
                    btnCropInv.setBackgroundTintList(ColorStateList.valueOf(0xFF2E7D32));
                    btnCropInv.setText("Inv ✓");
                } else {
                    btnCropInv.setBackgroundTintList(ColorStateList.valueOf(0xFF333333));
                    btnCropInv.setText("Inv");
                }
            }
            if (btnCropBW != null) {
                if (isBlackAndWhite[0]) {
                    btnCropBW.setBackgroundTintList(ColorStateList.valueOf(0xFF2E7D32));
                    btnCropBW.setText("B&W ✓");
                } else {
                    btnCropBW.setBackgroundTintList(ColorStateList.valueOf(0xFF333333));
                    btnCropBW.setText("B&W");
                }
            }
        };

        // Navigation arrow listeners (change pages 17 -> 16 or 18 without leaving crop page)
        View.OnClickListener onNavArrowClick = v -> {
            int newIndex = (v.getId() == R.id.btnCropPrevPage) ? (currentPage[0] - 1) : (currentPage[0] + 1);
            if (newIndex < 0 || newIndex >= totalPages) return;

            Bitmap newBmp = null;
            if (pagesAdapter != null) {
                newBmp = pagesAdapter.getCachedBitmap(newIndex);
                if (newBmp == null) {
                    int screenWidth = getResources().getDisplayMetrics().widthPixels;
                    newBmp = pagesAdapter.renderPageBitmap(newIndex, screenWidth);
                }
            }

            if (newBmp != null) {
                currentPage[0] = newIndex;
                currentBitmap[0] = newBmp;
                ivCropSource.setImageBitmap(newBmp);
                cropOverlay.setSourceImageDimensions(newBmp.getWidth(), newBmp.getHeight());
                cropOverlay.resetToFullBounds();
                updateFilterUI.run();
                updateNavState.run();
            } else {
                Toast.makeText(this, "পেজ লোড করতে সমস্যা হয়েছে", Toast.LENGTH_SHORT).show();
            }
        };

        if (btnCropPrevPage != null) {
            btnCropPrevPage.setOnClickListener(onNavArrowClick);
        }
        if (btnCropNextPage != null) {
            btnCropNextPage.setOnClickListener(onNavArrowClick);
        }

        // Requirement 2: Inv Button (Invert page image)
        if (btnCropInv != null) {
            btnCropInv.setOnClickListener(v -> {
                isInverted[0] = !isInverted[0];
                updateFilterUI.run();
                Toast.makeText(this, isInverted[0] ? "ইনভার্ট কালার চালু করা হয়েছে" : "ইনভার্ট কালার বন্ধ করা হয়েছে", Toast.LENGTH_SHORT).show();
            });
        }

        // Requirement 2: B&W Button (Black & White page image)
        if (btnCropBW != null) {
            btnCropBW.setOnClickListener(v -> {
                isBlackAndWhite[0] = !isBlackAndWhite[0];
                updateFilterUI.run();
                Toast.makeText(this, isBlackAndWhite[0] ? "ব্ল্যাক অ্যান্ড হোয়াইট মোড চালু হয়েছে" : "রঙিন মোড চালু হয়েছে", Toast.LENGTH_SHORT).show();
            });
        }

        // Requirement 1: Download button to save cropped image directly to device Gallery
        if (btnCropDownload != null) {
            btnCropDownload.setOnClickListener(v -> {
                Bitmap cropped = extractCroppedBitmap(currentBitmap[0], cropOverlay);
                if (cropped == null) {
                    Toast.makeText(this, "ক্রপ ফ্রেম নির্বাচন করুন", Toast.LENGTH_SHORT).show();
                    return;
                }
                Bitmap filteredCropped = applyFilterToBitmap(cropped, isInverted[0], isBlackAndWhite[0]);
                boolean saved = saveBitmapToGallery(filteredCropped);
                if (saved) {
                    Toast.makeText(this, "✓ ক্রপ করা ছবি সরাসরি গ্যালারিতে সেভ হয়েছে!", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(this, "গ্যালারিতে সেভ করতে সমস্যা হয়েছে", Toast.LENGTH_SHORT).show();
                }
            });
        }

        // Requirement 2: (dw:2) button to execute pipeline: Invert & B&W -> Transparent White -> Pure Black (#000000) -> Lossless PNG Save
        if (btnCropDw2 != null) {
            btnCropDw2.setOnClickListener(v -> {
                Bitmap cropped = extractCroppedBitmap(currentBitmap[0], cropOverlay);
                if (cropped == null) {
                    Toast.makeText(this, "ক্রপ ফ্রেম নির্বাচন করুন", Toast.LENGTH_SHORT).show();
                    return;
                }

                Bitmap processed = processDw2Pipeline(cropped);
                if (processed == null) {
                    Toast.makeText(this, "ইমেজ প্রসেস করতে সমস্যা হয়েছে", Toast.LENGTH_SHORT).show();
                    return;
                }

                boolean saved = saveTransparentBitmapLossless(processed);
                if (saved) {
                    Toast.makeText(this, "✓ (dw:2) স্বচ্ছ ব্যাকগ্রাউন্ড ও কালো কালিতে সেভ হয়েছে (Lossless PNG)!", Toast.LENGTH_LONG).show();
                } else {
                    Toast.makeText(this, "গ্যালারিতে সেভ করতে সমস্যা হয়েছে", Toast.LENGTH_SHORT).show();
                }
            });
        }

        btnClose.setOnClickListener(v -> dialog.dismiss());

        // Copy AI prompt to clipboard
        btnCopyPrompt.setOnClickListener(v -> {
            ClipboardManager cb = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (cb != null) {
                cb.setPrimaryClip(ClipData.newPlainText("AI Prompt", PdfUtils.AI_PROMPT));
                Toast.makeText(this, "AI Prompt Copied: " + PdfUtils.AI_PROMPT, Toast.LENGTH_SHORT).show();
            }
        });

        // Crop and share with AI action
        View.OnClickListener shareAction = v -> {
            Bitmap cropped = extractCroppedBitmap(currentBitmap[0], cropOverlay);
            if (cropped == null) {
                Toast.makeText(this, "ক্রপ ফ্রেম নির্বাচন করুন", Toast.LENGTH_SHORT).show();
                return;
            }

            Bitmap filteredCropped = applyFilterToBitmap(cropped, isInverted[0], isBlackAndWhite[0]);
            File savedFile = PdfUtils.saveBitmapToCache(this, filteredCropped, "pdf_crop_");
            if (savedFile != null) {
                PdfUtils.shareSnippetImage(this, savedFile);
                Toast.makeText(this, "প্রম্পট কপি করা হয়েছে এবং AI শেয়ার উইন্ডো খোলা হয়েছে!", Toast.LENGTH_SHORT).show();
                dialog.dismiss();
            } else {
                Toast.makeText(this, "ইমেজ সংরক্ষণ করতে ব্যর্থ হয়েছে", Toast.LENGTH_SHORT).show();
            }
        };

        btnShareTop.setOnClickListener(shareAction);
        btnShareBottom.setOnClickListener(shareAction);

        btnSave.setOnClickListener(v -> {
            Bitmap cropped = extractCroppedBitmap(currentBitmap[0], cropOverlay);
            if (cropped != null) {
                Bitmap filteredCropped = applyFilterToBitmap(cropped, isInverted[0], isBlackAndWhite[0]);
                File savedFile = PdfUtils.saveBitmapToCache(this, filteredCropped, "saved_crop_");
                if (savedFile != null) {
                    Toast.makeText(this, "ক্রপ সংরক্ষণ করা হয়েছে: " + savedFile.getName(), Toast.LENGTH_LONG).show();
                    dialog.dismiss();
                    return;
                }
            }
            Toast.makeText(this, "সংরক্ষণ করা সম্ভব হয়নি", Toast.LENGTH_SHORT).show();
        });

        dialog.show();
    }

    private ColorMatrix getInvertColorMatrix() {
        return new ColorMatrix(new float[] {
            -1.0f,  0.0f,  0.0f, 0.0f, 255.0f,
             0.0f, -1.0f,  0.0f, 0.0f, 255.0f,
             0.0f,  0.0f, -1.0f, 0.0f, 255.0f,
             0.0f,  0.0f,  0.0f, 1.0f,   0.0f
        });
    }

    private Bitmap applyFilterToBitmap(Bitmap src, boolean invert, boolean bw) {
        if (src == null || (!invert && !bw)) return src;
        try {
            Bitmap result = Bitmap.createBitmap(src.getWidth(), src.getHeight(), Bitmap.Config.ARGB_8888);
            Canvas canvas = new Canvas(result);
            Paint paint = new Paint();

            ColorMatrix matrix = new ColorMatrix();
            if (invert && bw) {
                matrix.postConcat(getInvertColorMatrix());
                ColorMatrix sat = new ColorMatrix();
                sat.setSaturation(0);
                matrix.postConcat(sat);
            } else if (invert) {
                matrix.postConcat(getInvertColorMatrix());
            } else if (bw) {
                matrix.setSaturation(0);
            }

            paint.setColorFilter(new ColorMatrixColorFilter(matrix));
            canvas.drawBitmap(src, 0, 0, paint);
            return result;
        } catch (Exception e) {
            return src;
        }
    }

    private boolean saveBitmapToGallery(Bitmap bitmap) {
        if (bitmap == null) return false;
        String fileName = "PDF_Crop_" + System.currentTimeMillis() + ".jpg";
        OutputStream fos = null;
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.Images.Media.DISPLAY_NAME, fileName);
                values.put(MediaStore.Images.Media.MIME_TYPE, "image/jpeg");
                values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/PDF_Gallery");
                values.put(MediaStore.Images.Media.IS_PENDING, 1);

                Uri imageUri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                if (imageUri != null) {
                    fos = getContentResolver().openOutputStream(imageUri);
                    if (fos != null) {
                        bitmap.compress(Bitmap.CompressFormat.JPEG, 95, fos);
                    }
                    values.clear();
                    values.put(MediaStore.Images.Media.IS_PENDING, 0);
                    getContentResolver().update(imageUri, values, null, null);
                    return true;
                }
            } else {
                File picturesDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES);
                File subDir = new File(picturesDir, "PDF_Gallery");
                if (!subDir.exists()) subDir.mkdirs();
                File imageFile = new File(subDir, fileName);
                fos = new FileOutputStream(imageFile);
                bitmap.compress(Bitmap.CompressFormat.JPEG, 95, fos);
                fos.flush();
                fos.close();

                android.media.MediaScannerConnection.scanFile(this,
                        new String[]{imageFile.getAbsolutePath()},
                        new String[]{"image/jpeg"}, null);
                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (fos != null) {
                try { fos.close(); } catch (Exception ignored) {}
            }
        }
        return false;
    }

    /**
     * Requirement 2: Image Processing Pipeline for (dw:2):
     * 1. Invert (Inv) & Black & White (B&W): Inverts the image colors and converts to grayscale/luminance.
     * 2. White Background Transparency: Converts white/near-white pixels into 100% transparent pixels (alpha = 0).
     * 3. Color Transformation to Black: Transforms all remaining visible content/lines/text to pure black (#000000),
     *    preserving anti-aliased edge smoothing via alpha gradients.
     * 4. Zero Pixel Loss: Retains 100% original dimensions in Bitmap.Config.ARGB_8888.
     */
    private Bitmap processDw2Pipeline(Bitmap source) {
        if (source == null) return null;

        int width = source.getWidth();
        int height = source.getHeight();

        // Step 1: Apply Invert & Black & White (B&W) using ColorMatrix
        Bitmap invBwBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        Canvas canvas = new Canvas(invBwBitmap);
        Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);

        ColorMatrix matrix = new ColorMatrix();
        // Invert: R' = 255 - R, G' = 255 - G, B' = 255 - B
        matrix.postConcat(getInvertColorMatrix());
        // Black & White: saturation = 0
        ColorMatrix satMatrix = new ColorMatrix();
        satMatrix.setSaturation(0);
        matrix.postConcat(satMatrix);

        paint.setColorFilter(new ColorMatrixColorFilter(matrix));
        canvas.drawBitmap(source, 0, 0, paint);

        // Step 2 & 3: White Background Transparency & Color Transformation to Black (#000000)
        int[] pixels = new int[width * height];
        invBwBitmap.getPixels(pixels, 0, width, 0, 0, width, height);

        // Threshold parameters for clean background removal and smooth ink edges
        final int bgThreshold = 225; // Luminance >= 225 is white background -> Alpha = 0 (transparent)
        final int fgThreshold = 165; // Luminance <= 165 is solid ink -> Alpha = 255, Color = pure black #000000
        final float range = (float) (bgThreshold - fgThreshold);

        for (int i = 0; i < pixels.length; i++) {
            int color = pixels[i];
            // In invBwBitmap, R == G == B, so extracting the blue channel gives luminance directly
            int luminance = color & 0xFF;

            if (luminance >= bgThreshold) {
                // White / near-white background becomes 100% transparent
                pixels[i] = 0x00000000;
            } else if (luminance <= fgThreshold) {
                // Foreground content/lines/text transformed to pure black (#000000)
                pixels[i] = 0xFF000000;
            } else {
                // Smooth anti-aliased transition edge: pure black with proportional alpha
                float factor = (bgThreshold - luminance) / range;
                int alpha = Math.min(255, Math.max(0, Math.round(255.0f * factor)));
                pixels[i] = (alpha << 24); // Pure black (#000000) with anti-aliased alpha
            }
        }

        Bitmap resultBitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888);
        resultBitmap.setPixels(pixels, 0, width, 0, 0, width, height);

        invBwBitmap.recycle();
        return resultBitmap;
    }

    /**
     * Lossless Quality Saving:
     * Saves the transparent and pure-black bitmap directly to device storage / gallery as PNG
     * maintaining 100% original quality without any compression loss or pixel degradation (Zero Pixel Loss).
     */
    private boolean saveTransparentBitmapLossless(Bitmap bitmap) {
        if (bitmap == null) return false;
        String fileName = "PDF_DW2_" + System.currentTimeMillis() + ".png";
        OutputStream fos = null;
        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                ContentValues values = new ContentValues();
                values.put(MediaStore.Images.Media.DISPLAY_NAME, fileName);
                values.put(MediaStore.Images.Media.MIME_TYPE, "image/png");
                values.put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/PDF_Gallery");
                values.put(MediaStore.Images.Media.IS_PENDING, 1);

                Uri imageUri = getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, values);
                if (imageUri != null) {
                    fos = getContentResolver().openOutputStream(imageUri);
                    if (fos != null) {
                        // Lossless PNG format preserves 100% alpha transparency and original pixels
                        bitmap.compress(Bitmap.CompressFormat.PNG, 100, fos);
                    }
                    values.clear();
                    values.put(MediaStore.Images.Media.IS_PENDING, 0);
                    getContentResolver().update(imageUri, values, null, null);
                    return true;
                }
            } else {
                File picturesDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES);
                File subDir = new File(picturesDir, "PDF_Gallery");
                if (!subDir.exists()) subDir.mkdirs();
                File imageFile = new File(subDir, fileName);
                fos = new FileOutputStream(imageFile);
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, fos);
                fos.flush();
                fos.close();

                android.media.MediaScannerConnection.scanFile(this,
                        new String[]{imageFile.getAbsolutePath()},
                        new String[]{"image/png"}, null);
                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            if (fos != null) {
                try { fos.close(); } catch (Exception ignored) {}
            }
        }
        return false;
    }

    private Bitmap extractCroppedBitmap(Bitmap source, CropOverlayView overlay) {
        if (source == null || overlay == null) return null;
        try {
            Rect cropRect = overlay.calculateCropRect(source.getWidth(), source.getHeight());
            if (cropRect.width() > 10 && cropRect.height() > 10) {
                return Bitmap.createBitmap(
                        source,
                        cropRect.left, cropRect.top,
                        cropRect.width(), cropRect.height()
                );
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return null;
    }

    // Toggle Floating Bubble Assistant
    private void toggleFloatingService() {
        if (FloatingBubbleService.isServiceRunning) {
            Intent serviceIntent = new Intent(this, FloatingBubbleService.class);
            serviceIntent.setAction(FloatingBubbleService.ACTION_STOP);
            stopService(serviceIntent);
            FloatingBubbleService.isServiceRunning = false;
            Toast.makeText(this, "ভাসমান ক্রপ বাটন বন্ধ করা হয়েছে (Disabled)", Toast.LENGTH_SHORT).show();
        } else {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && !Settings.canDrawOverlays(this)) {
                Toast.makeText(this, "ভাসমান বাটনের জন্য Overlay অনুমতি দিন", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(
                        Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName())
                );
                startActivityForResult(intent, REQUEST_OVERLAY_PERMISSION);
            } else {
                startFloatingBubbleService();
            }
        }
    }

    private void startFloatingBubbleService() {
        Intent serviceIntent = new Intent(this, FloatingBubbleService.class);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            startForegroundService(serviceIntent);
        } else {
            startService(serviceIntent);
        }
        Toast.makeText(this, "ভাসমান ক্রপ বাটন চালু করা হয়েছে!", Toast.LENGTH_SHORT).show();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == REQUEST_LENS_OVERLAY_PERMISSION) {
            // Launch Lens whether or not the permission was granted (bar only appears if granted)
            launchLensNow(pendingLensPage, pendingLensImagePath);
            return;
        }
        if (requestCode == REQUEST_OVERLAY_PERMISSION) {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M && Settings.canDrawOverlays(this)) {
                startFloatingBubbleService();
            } else {
                Toast.makeText(this, "Overlay অনুমতি ছাড়া ভাসমান বাটন চলবে না", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (pagesAdapter != null) {
            pagesAdapter.release();
        }
        try {
            if (pdfRenderer != null) {
                pdfRenderer.close();
            }
            if (parcelFileDescriptor != null) {
                parcelFileDescriptor.close();
            }
        } catch (Exception ignored) {}
    }
}
