package com.example;

import android.text.Editable;
import android.text.TextWatcher;
import android.widget.EditText;
import java.util.LinkedList;

public class TextUndoRedoHelper implements TextWatcher {

    public interface OnUndoRedoListener {
        void onHistoryChanged(boolean canUndo, boolean canRedo);
    }

    private static final int MAX_HISTORY_SIZE = 60;
    private final EditText editText;
    private final LinkedList<TextState> undoStack = new LinkedList<>();
    private final LinkedList<TextState> redoStack = new LinkedList<>();
    private boolean isUndoingOrRedoing = false;
    private OnUndoRedoListener listener;
    private long lastEditTime = 0;

    private static class TextState {
        final String text;
        final int cursorPosition;

        TextState(String text, int cursorPosition) {
            this.text = text != null ? text : "";
            this.cursorPosition = Math.max(0, cursorPosition);
        }
    }

    public TextUndoRedoHelper(EditText editText) {
        this.editText = editText;
        if (editText != null) {
            String initialText = editText.getText().toString();
            undoStack.add(new TextState(initialText, editText.getSelectionStart()));
            editText.addTextChangedListener(this);
        }
    }

    public void setListener(OnUndoRedoListener listener) {
        this.listener = listener;
        notifyState();
    }

    @Override
    public void beforeTextChanged(CharSequence s, int start, int count, int after) {
    }

    @Override
    public void onTextChanged(CharSequence s, int start, int before, int count) {
    }

    @Override
    public void afterTextChanged(Editable s) {
        if (isUndoingOrRedoing || editText == null) return;

        String currentText = s.toString();
        int cursor = editText.getSelectionStart();
        long now = System.currentTimeMillis();

        // If the top state matches current text, ignore
        if (!undoStack.isEmpty() && undoStack.getLast().text.equals(currentText)) {
            return;
        }

        // If edits are very quick keystrokes (within 400ms), update current state rather than spamming stack
        if (!undoStack.isEmpty() && (now - lastEditTime < 350) && Math.abs(currentText.length() - undoStack.getLast().text.length()) <= 1) {
            undoStack.removeLast();
        }

        undoStack.add(new TextState(currentText, cursor));
        if (undoStack.size() > MAX_HISTORY_SIZE) {
            undoStack.removeFirst();
        }

        // Any new manual edit clears redo history
        redoStack.clear();
        lastEditTime = now;
        notifyState();
    }

    public boolean canUndo() {
        return undoStack.size() > 1;
    }

    public boolean canRedo() {
        return !redoStack.isEmpty();
    }

    public boolean undo() {
        if (!canUndo() || editText == null) return false;

        isUndoingOrRedoing = true;
        try {
            TextState currentState = undoStack.removeLast();
            redoStack.add(currentState);

            TextState previousState = undoStack.getLast();
            editText.setText(previousState.text);
            int pos = Math.min(previousState.cursorPosition, previousState.text.length());
            editText.setSelection(Math.max(0, pos));
        } finally {
            isUndoingOrRedoing = false;
        }
        notifyState();
        return true;
    }

    public boolean redo() {
        if (!canRedo() || editText == null) return false;

        isUndoingOrRedoing = true;
        try {
            TextState nextState = redoStack.removeLast();
            undoStack.add(nextState);

            editText.setText(nextState.text);
            int pos = Math.min(nextState.cursorPosition, nextState.text.length());
            editText.setSelection(Math.max(0, pos));
        } finally {
            isUndoingOrRedoing = false;
        }
        notifyState();
        return true;
    }

    public void clearHistory(String currentText) {
        undoStack.clear();
        redoStack.clear();
        int cursor = editText != null ? editText.getSelectionStart() : 0;
        undoStack.add(new TextState(currentText, cursor));
        notifyState();
    }

    private void notifyState() {
        if (listener != null) {
            listener.onHistoryChanged(canUndo(), canRedo());
        }
    }
}
