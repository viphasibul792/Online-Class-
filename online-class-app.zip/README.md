# Online Class – Native Android Subject Hub

A complete, production-ready Native Android application built with **Kotlin** and the **Android Native XML View System**, featuring an interactive subject navigation bar, robust WebView configuration, permanent cookie and login session persistence, and an automatic ACS Desktop promotional popup dismissal engine.

---

## Key Features

1. **Top Menu Actions: Home & All Course**
   - **Home Button**: Quickly opens the main Course Hub URL (`https://frb.aparsclassroom.com/course/74c3a47d-69ac-4de1-9314-3c879667996f`).
   - **All Course Button**: Opens a bottom sheet showing all 17 courses clearly numbered from top to bottom (`১` to `১৭`), with quick-click navigation to any course.
   - Both buttons are accessible directly from the top header bar and from the front of the horizontal scrollable subject bar.

2. **Full 17 Courses Numbered List**
   - **১। Physics 1st Paper**: `https://frb.aparsclassroom.com/course/74c3a47d-69ac-4de1-9314-3c879667996f/subject/54753903-a094-4a31-9cb7-50c3b472e76c?title=Physics+1st+Paper`
   - **২। Physics 2nd Paper**: `https://frb.aparsclassroom.com/course/74c3a47d-69ac-4de1-9314-3c879667996f/subject/0b348be7-23f3-4a44-9573-384a2d4597f9?title=Physics+2nd+Paper`
   - **৩। Higher Math 1st Paper**: `https://frb.aparsclassroom.com/course/74c3a47d-69ac-4de1-9314-3c879667996f/subject/a49b9a1b-b286-43a0-8b7b-53b8f3edfe71?title=Higher+Math+1st+Paper`
   - **৪। Higher Math 2nd Paper**: `https://frb.aparsclassroom.com/course/74c3a47d-69ac-4de1-9314-3c879667996f/subject/a3219208-758f-417f-ae2e-4d9b104abaad?title=Higher+Math+2nd+Paper`
   - **৫। Chemistry 1st Paper**: `https://frb.aparsclassroom.com/course/74c3a47d-69ac-4de1-9314-3c879667996f/subject/2d1eaea5-f318-4e9e-b1b8-c5ffe25727ff?title=Chemistry+1st+Paper`
   - **৬। Chemistry 2nd Paper**: `https://frb.aparsclassroom.com/course/74c3a47d-69ac-4de1-9314-3c879667996f/subject/960aa782-a774-4b73-8fda-c9c95c314ec6?title=Chemistry+2nd+Paper`
   - **৭। Biology 1st Paper**: `https://frb.aparsclassroom.com/course/74c3a47d-69ac-4de1-9314-3c879667996f/subject/c3b3faff-4878-4061-ad25-80d7c435ca56?title=Biology+1st+Paper`
   - **৮। Biology 2nd Paper**: `https://frb.aparsclassroom.com/course/74c3a47d-69ac-4de1-9314-3c879667996f/subject/333db456-b75e-4c70-82be-809a0730d4c9?title=Biology+2nd+Paper`
   - **৯। English 1st**: `https://frb.aparsclassroom.com/course/74c3a47d-69ac-4de1-9314-3c879667996f/subject/bcb896cf-a006-4bd8-8ad7-d5e92ffa59b9/classes/6a75946a-77e8-47db-8007-4186d4769bfe?title=English+1st+Paper`
   - **১০। English 2nd**: `https://frb.aparsclassroom.com/course/74c3a47d-69ac-4de1-9314-3c879667996f/subject/bcb896cf-a006-4bd8-8ad7-d5e92ffa59b9/classes/988d47df-ee40-4225-b4d1-19d7e12e7b7b?title=English+2nd+Paper`
   - **১১। বাংলা ১ম**: `https://frb.aparsclassroom.com/course/74c3a47d-69ac-4de1-9314-3c879667996f/subject/be81db09-cbd2-4b65-92d2-d1496be0aebf/classes/9bb80783-6578-4480-92c9-3b0c38348f59?title=%E0%A6%AC%E0%A6%BE%E0%A6%82%E0%A6%B2%E0%A6%BE++%E0%A6%AA%E0%A7%8D%E0%A6%B0%E0%A6%A5%E0%A6%AE+%E0%A6%AA%E0%A6%A4%E0%A7%8D%E0%A6%B0+`
   - **১২। বাংলা ২য় পত্র**: `https://frb.aparsclassroom.com/course/74c3a47d-69ac-4de1-9314-3c879667996f/subject/be81db09-cbd2-4b65-92d2-d1496be0aebf/classes/31c2ab58-57e9-4755-ae7b-b82607c517c6?title=%E0%A6%AC%E0%A6%BE%E0%A6%82%E0%A6%B2%E0%A6%BE+%E0%A6%A6%E0%A7%8D%E0%A6%AC%E0%A6%BF%E0%A6%A4%E0%A7%80%E0%A7%9F+%E0%A6%AA%E0%A6%A4%E0%A7%8D%E0%A6%B0+`
   - **১৩। তথ্য ও যোগাযোগ প্রযুক্তি**: `https://frb.aparsclassroom.com/course/74c3a47d-69ac-4de1-9314-3c879667996f/subject/4f2c48d8-e4cf-48e9-8711-01e023e17cbe?title=%E0%A6%A4%E0%A6%A5%E0%A7%8D%E0%A6%AF+%E0%A6%93+%E0%A6%AF%E0%A7%8B%E0%A6%97%E0%A6%BE%E0%A6%AF%E0%A7%8B%E0%A6%97+%E0%A6%AA%E0%A7%8D%E0%A6%B0%E0%A6%AF%E0%A7%81%E0%A6%95%E0%A7%8D%E0%A6%A4%E0%A6%BF+`
   - **১৪। ACS English 2nd**: `https://academic.aparsclassroom.com/course/b0ce59dd-09cf-498d-b99f-350fcbcb93bf/subject/e522d020-757a-44d3-b5b1-61731b981453/chapter/a6a3fc28-4be0-4422-8ad3-cb36b84dcae5?title=English+2nd+Paper`
   - **১৫। PhysicsofStupid 1st**: `https://physicsofstupid.com/dashboard/my-courses/hsc-physics-recorded-1st-2nd-paper/phy101/paper-1`
   - **১৬। PhysicsofStupid 2nd**: `https://physicsofstupid.com/dashboard/my-courses/hsc-physics-recorded-1st-2nd-paper/phy101/paper-2`
   - **১৭। Telegram web app**: `https://web.telegram.org/k/`

3. **Permanent Login Session & Cookie Persistence**
   - **CookieManager Persistence**: Automatic and proactive `flush()` on page start, page finish, pause, stop, and destroy events to flush RAM cookies directly to disk SQLite.
   - **Third-Party Cookies Enabled**: Enabled globally and on all WebView instances to support cross-domain Single Sign-On (SSO).
   - **Google & Apple Sign-In Compatibility**: Adjusted User-Agent string removing `; wv` and `Version/4.0` so Google does not block OAuth with `disallowed_useragent`, permitting durable token storage.
   - **OAuth Popup Windows Supported**: `setSupportMultipleWindows(true)` with shared `CookieManager` so OAuth popups complete and sync session cookies seamlessly.
   - **DOM & Database Storage**: `domStorageEnabled` and `databaseEnabled` keep Telegram Web and SPAs logged in permanently.

4. **Automatic ACS Desktop Promotional Popup Dismissal**
   - Injected script observes mutations and safely dismisses the `"ACS is now on Desktop"` popup automatically without impacting login dialogs, payments, or course notices.

---

## Build & Test Instructions

```bash
# Build applet
gradle assembleDebug

# Run unit tests
gradle :app:testDebugUnitTest
```
