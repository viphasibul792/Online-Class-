package com.example

import android.util.Log
import android.webkit.JavascriptInterface
import android.webkit.WebView

/**
 * Helper to automatically detect and dismiss ONLY the ACS Desktop promotional popup.
 *
 * Specific target text:
 *  - "ACS is now on Desktop"
 *  - "New · Desktop app"
 *  - "ACS is now on desktop"
 *  - "I've installed it"
 */
class PopupDismissHelper(private val onDismissed: (() -> Unit)? = null) {

    companion object {
        private const val TAG = "PopupDismissHelper"
        const val INTERFACE_NAME = "AcsPopupNativeBridge"

        /**
         * Minified and robust JavaScript payload injected on page finish and route changes.
         * Uses DOM scanning and a MutationObserver to dismiss the promo dialog.
         */
        val JS_DISMISS_PAYLOAD: String = """
            (function() {
                if (window.__acs_popup_hook_active) {
                    try {
                        if (typeof window.__acs_check_and_dismiss === 'function') {
                            window.__acs_check_and_dismiss();
                        }
                    } catch(e) {}
                    return;
                }
                window.__acs_popup_hook_active = true;

                const ACS_PROMO_KEYWORDS = [
                    "ACS is now on Desktop",
                    "New · Desktop app",
                    "ACS is now on desktop",
                    "I've installed it"
                ];

                function dismissPopup() {
                    try {
                        // Scan modal containers and dialog elements
                        const candidates = document.querySelectorAll(
                            'dialog, [role="dialog"], [role="alertdialog"], .modal, div[class*="modal"], div[class*="dialog"], div[class*="popup"], div'
                        );

                        for (let i = 0; i < candidates.length; i++) {
                            const el = candidates[i];
                            const text = (el.innerText || el.textContent || '');
                            if (!text) continue;

                            // Must contain ACS Desktop promo text
                            const isPromo = ACS_PROMO_KEYWORDS.some(k => text.includes(k));
                            if (!isPromo) continue;

                            // Safety guard: Ensure container is a modal, not the entire page body
                            if (text.length > 3500 && el.tagName !== 'DIALOG') continue;

                            // Look for the specific Close or Skip button inside this modal
                            const buttons = el.querySelectorAll('button, [role="button"], a, span[role="button"]');
                            let closed = false;

                            for (let j = 0; j < buttons.length; j++) {
                                const btn = buttons[j];
                                const btnText = (btn.innerText || btn.textContent || '').trim().toLowerCase();
                                const ariaLabel = (btn.getAttribute('aria-label') || '').toLowerCase();
                                const title = (btn.getAttribute('title') || '').toLowerCase();
                                const className = (btn.className || '').toString().toLowerCase();

                                // Matches close icon, skip button, or 'x'
                                if (
                                    btnText === 'skip' ||
                                    btnText === '×' ||
                                    btnText === '✕' ||
                                    btnText === 'x' ||
                                    ariaLabel.includes('close') ||
                                    ariaLabel.includes('dismiss') ||
                                    title.includes('close') ||
                                    className.includes('close') ||
                                    className.includes('dismiss')
                                ) {
                                    btn.click();
                                    closed = true;
                                    break;
                                }

                                // Check if button contains an SVG close icon
                                if (btn.querySelector('svg')) {
                                    // Usually top-right close button in modern modals
                                    btn.click();
                                    closed = true;
                                    break;
                                }
                            }

                            // Fallback: If no explicit button element, look for close SVG inside container
                            if (!closed) {
                                const svgs = el.querySelectorAll('svg');
                                for (let s = 0; s < svgs.length; s++) {
                                    const svg = svgs[s];
                                    const clickable = svg.closest('button, [role="button"], div, a');
                                    if (clickable && clickable !== el) {
                                        clickable.click();
                                        closed = true;
                                        break;
                                    }
                                }
                            }

                            if (closed) {
                                console.log('[APARS CLASSROOM] Auto-dismissed ACS Desktop promotional popup');
                                if (window.$INTERFACE_NAME && typeof window.$INTERFACE_NAME.onPopupDismissed === 'function') {
                                    window.$INTERFACE_NAME.onPopupDismissed();
                                }
                                return true;
                            }
                        }
                    } catch (err) {
                        console.error('[APARS CLASSROOM] Error in popup dismissal:', err);
                    }
                    return false;
                }

                window.__acs_check_and_dismiss = dismissPopup;

                // 1. Run immediately
                dismissPopup();

                // 2. Schedule short retries for delayed popups
                setTimeout(dismissPopup, 500);
                setTimeout(dismissPopup, 1200);
                setTimeout(dismissPopup, 2500);

                // 3. MutationObserver to catch dynamically injected popups efficiently
                let debounceTimer = null;
                const observer = new MutationObserver(function() {
                    if (debounceTimer) return;
                    debounceTimer = setTimeout(function() {
                        debounceTimer = null;
                        dismissPopup();
                    }, 300);
                });

                const root = document.body || document.documentElement;
                if (root) {
                    observer.observe(root, { childList: true, subtree: true });
                }
            })();
        """.trimIndent()
    }

    @JavascriptInterface
    fun onPopupDismissed() {
        Log.d(TAG, "ACS Desktop Promotional popup detected and automatically dismissed.")
        onDismissed?.invoke()
    }

    /**
     * Injects the popup dismissal script into the WebView.
     */
    fun injectDismissScript(webView: WebView) {
        webView.evaluateJavascript(JS_DISMISS_PAYLOAD) { result ->
            Log.d(TAG, "Popup script evaluation result: $result")
        }
    }
}
