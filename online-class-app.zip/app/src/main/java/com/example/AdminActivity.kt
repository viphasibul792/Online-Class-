package com.example

import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.databinding.ActivityAdminBinding
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import java.security.MessageDigest

/**
 * Admin screen: login gate + editor for the subject buttons.
 * Credentials are never stored in plain text — only salted SHA-256 hashes are compared.
 */
class AdminActivity : AppCompatActivity() {

    private lateinit var binding: ActivityAdminBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityAdminBinding.inflate(layoutInflater)
        setContentView(binding.root)
        SubjectRepository.init(this)

        ViewCompat.setOnApplyWindowInsetsListener(binding.adminRoot) { v, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(0, bars.top, 0, bars.bottom)
            insets
        }

        binding.btnAdminBack.setOnClickListener { finish() }
        binding.btnLogin.setOnClickListener { attemptLogin() }
        binding.btnAddButton.setOnClickListener { showEditDialog(null) }
        binding.btnResetDefaults.setOnClickListener {
            MaterialAlertDialogBuilder(this)
                .setTitle("ডিফল্টে ফিরে যাবেন?")
                .setMessage("সব বাটম মূল ১৭টি বাটমে ফিরে যাবে।")
                .setPositiveButton("হ্যাঁ") { _, _ ->
                    SubjectRepository.resetToDefaults()
                    renderList()
                }
                .setNegativeButton("না", null)
                .show()
        }

        // Login state is kept only in memory; leaving the screen requires logging in again.
        val loggedIn = savedInstanceState?.getBoolean("li") == true
        showPanel(loggedIn)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        outState.putBoolean("li", binding.panelContainer.visibility == View.VISIBLE)
    }

    private fun attemptLogin() {
        val email = binding.etEmail.text.toString().trim().lowercase()
        val pass = binding.etPassword.text.toString()
        if (hash(email) == EMAIL_HASH && hash(pass) == PASS_HASH) {
            binding.etPassword.text?.clear()
            binding.etEmail.text?.clear()
            showPanel(true)
        } else {
            binding.tilPassword.error = "ভুল gmail বা password"
        }
    }

    private fun showPanel(show: Boolean) {
        binding.loginContainer.visibility = if (show) View.GONE else View.VISIBLE
        binding.panelContainer.visibility = if (show) View.VISIBLE else View.GONE
        if (show) renderList()
    }

    private fun renderList() {
        val c = binding.buttonListContainer
        c.removeAllViews()
        val list = SubjectRepository.subjects
        list.forEachIndexed { index, s ->
            c.addView(buildRow(index, list.size, s))
        }
    }

    private fun buildRow(index: Int, count: Int, s: Subject): View {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundResource(R.drawable.bg_item_course)
            setPadding(dp(14), dp(10), dp(14), dp(10))
            layoutParams = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply { bottomMargin = dp(8) }
        }
        row.addView(TextView(this).apply {
            text = "${s.bengaliNumber}। ${s.displayName}"
            textSize = 15f
            setTextColor(ContextCompat.getColor(context, R.color.text_primary))
            setTypeface(typeface, android.graphics.Typeface.BOLD)
        })
        row.addView(TextView(this).apply {
            text = s.url
            textSize = 11f
            maxLines = 1
            ellipsize = android.text.TextUtils.TruncateAt.END
            setTextColor(ContextCompat.getColor(context, R.color.text_secondary))
        })
        val actions = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.END
        }
        fun action(label: String, enabled: Boolean = true, onClick: () -> Unit) {
            actions.addView(TextView(this).apply {
                text = label
                textSize = 14f
                gravity = Gravity.CENTER
                setPadding(dp(12), dp(8), dp(12), dp(8))
                setTextColor(ContextCompat.getColor(context, R.color.primary))
                alpha = if (enabled) 1f else 0.3f
                isEnabled = enabled
                setOnClickListener { onClick() }
            })
        }
        action("▲", index > 0) { SubjectRepository.move(s.id, -1); renderList() }
        action("▼", index < count - 1) { SubjectRepository.move(s.id, 1); renderList() }
        action("সম্পাদনা") { showEditDialog(s) }
        action("মুছুন") {
            MaterialAlertDialogBuilder(this)
                .setTitle("বাটম মুছবেন?")
                .setMessage(s.displayName)
                .setPositiveButton("মুছুন") { _, _ -> SubjectRepository.remove(s.id); renderList() }
                .setNegativeButton("বাতিল", null)
                .show()
        }
        row.addView(actions)
        return row
    }

    /** subject == null → add a new button; otherwise edit name/link of the given one. */
    private fun showEditDialog(subject: Subject?) {
        val form = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(24), dp(12), dp(24), 0)
        }
        val etName = EditText(this).apply {
            hint = "বাটমের নাম"
            setText(subject?.displayName.orEmpty())
            inputType = InputType.TYPE_CLASS_TEXT
        }
        val etUrl = EditText(this).apply {
            hint = "লিংক (https://...)"
            setText(subject?.url.orEmpty())
            inputType = InputType.TYPE_TEXT_VARIATION_URI
        }
        form.addView(etName)
        form.addView(etUrl)

        val dialog = MaterialAlertDialogBuilder(this)
            .setTitle(if (subject == null) "নতুন বাটম যোগ করুন" else "বাটম সম্পাদনা")
            .setView(form)
            .setPositiveButton("সেভ", null)
            .setNegativeButton("বাতিল", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(androidx.appcompat.app.AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val name = etName.text.toString().trim()
                var url = etUrl.text.toString().trim()
                if (name.isEmpty()) { etName.error = "নাম দিন"; return@setOnClickListener }
                if (url.isEmpty()) { etUrl.error = "লিংক দিন"; return@setOnClickListener }
                if (!url.startsWith("http://") && !url.startsWith("https://")) url = "https://$url"
                if (subject == null) SubjectRepository.add(name, url)
                else SubjectRepository.update(subject.id, name, url)
                renderList()
                Toast.makeText(this, "সেভ হয়েছে", Toast.LENGTH_SHORT).show()
                dialog.dismiss()
            }
        }
        dialog.show()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    companion object {
        private const val SALT = "oc#salt#9f2"
        private const val EMAIL_HASH = "a30b41ef9aa04618255895f4cf36ccb61de8dcc396170669202f32e7efa2665d"
        private const val PASS_HASH = "1837f94435b9a6f7a6fb87e9a8674c0d79dcb7b1707e1c110ce9d25b0d050d44"

        private fun hash(s: String): String =
            MessageDigest.getInstance("SHA-256").digest((SALT + s).toByteArray())
                .joinToString("") { "%02x".format(it) }
    }
}
