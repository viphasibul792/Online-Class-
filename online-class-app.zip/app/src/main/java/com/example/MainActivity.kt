package com.example

import android.annotation.SuppressLint
import android.app.Dialog
import android.content.ActivityNotFoundException
import android.content.Intent
import android.content.pm.ActivityInfo
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.os.Message
import android.view.Gravity
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.webkit.CookieManager
import android.webkit.JsResult
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.TextView
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.lifecycleScope
import androidx.lifecycle.repeatOnLifecycle
import com.example.databinding.ActivityMainBinding
import com.example.databinding.DialogAllCoursesBinding
import com.example.databinding.ItemCourseListBinding
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val viewModel: MainViewModel by viewModels()

    private val subjectButtonViews = mutableMapOf<Int, TextView>()
    private var homeButtonView: TextView? = null
    private var allCourseButtonView: TextView? = null
    private var popupDismissHelper: PopupDismissHelper? = null

    // Fullscreen video support
    private var customVideoView: View? = null
    private var fullscreenLayer: FrameLayout? = null
    private var customViewCallback: WebChromeClient.CustomViewCallback? = null
    private var originalOrientation: Int = ActivityInfo.SCREEN_ORIENTATION_UNSPECIFIED

    // File chooser support for web forms/uploads
    private var fileUploadCallback: ValueCallback<Array<Uri>>? = null
    private val fileChooserLauncher = registerForActivityResult(
        ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (fileUploadCallback != null) {
            val uris = WebChromeClient.FileChooserParams.parseResult(result.resultCode, result.data)
            fileUploadCallback?.onReceiveValue(uris)
            fileUploadCallback = null
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        SubjectRepository.init(this)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        // Handle edge-to-edge window insets
        ViewCompat.setOnApplyWindowInsetsListener(binding.rootLayout) { _, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            binding.topBar.setPadding(
                12.dpToPx(),
                systemBars.top + 4.dpToPx(),
                12.dpToPx(),
                4.dpToPx()
            )
            binding.topBar.layoutParams.height = 56.dpToPx() + systemBars.top
            insets
        }

        setupPopupDismissHelper()
        setupTopBarActions()
        setupSubjectNavigationBar()
        setupWebView()
        setupBackNavigation()
        setupErrorRetry()
        observeViewModel()

        if (savedInstanceState != null) {
            binding.webView.restoreState(savedInstanceState)
        } else {
            binding.webView.loadUrl(SubjectRepository.DEFAULT_COURSE_URL)
        }
    }

    private fun setupPopupDismissHelper() {
        popupDismissHelper = PopupDismissHelper {
            runOnUiThread {
                // Promotional popup dismissed automatically
            }
        }
    }

    private fun setupTopBarActions() {
        // App title or logo clicks navigate to course hub
        binding.tvAppTitle.setOnClickListener {
            loadSubject(SubjectRepository.homeSubject)
        }
        binding.appLogo.setOnClickListener {
            loadSubject(SubjectRepository.homeSubject)
        }

        // Web Back
        binding.btnNavBack.setOnClickListener {
            if (binding.webView.canGoBack()) {
                binding.webView.goBack()
            }
        }

        // Web Forward
        binding.btnNavForward.setOnClickListener {
            if (binding.webView.canGoForward()) {
                binding.webView.goForward()
            }
        }

        // Refresh
        binding.btnRefresh.setOnClickListener {
            binding.errorView.visibility = View.GONE
            binding.webView.reload()
        }

        // All Course Top Button
        binding.btnAllCoursesTop.setOnClickListener {
            showAllCoursesBottomSheet()
        }

        // Admin Button
        binding.btnAdmin.setOnClickListener {
            startActivity(Intent(this, AdminActivity::class.java))
        }

        // Home Top Button
        binding.btnHomeHub.setOnClickListener {
            loadSubject(SubjectRepository.homeSubject)
        }
    }

    private fun setupSubjectNavigationBar() {
        val container = binding.subjectButtonContainer
        container.removeAllViews()
        subjectButtonViews.clear()

        // 1. Home Button (Loads default Course Hub link)
        val homeBtn = createMenuActionButton(
            text = getString(R.string.home),
            backgroundRes = R.drawable.bg_home_button,
            textColorRes = R.color.on_primary
        ) {
            loadSubject(SubjectRepository.homeSubject)
        }
        container.addView(homeBtn)
        homeButtonView = homeBtn

        // 2. All Course Menu Button (Opens vertical numbered list of all courses)
        val allCourseBtn = createMenuActionButton(
            text = "☰ " + getString(R.string.all_courses),
            backgroundRes = R.drawable.bg_all_course_button,
            textColorRes = R.color.overview_inactive_text
        ) {
            showAllCoursesBottomSheet()
        }
        container.addView(allCourseBtn)
        allCourseButtonView = allCourseBtn

        // 3. All 17 Subject Buttons in exact order
        SubjectRepository.subjects.forEach { subject ->
            val btn = createSubjectButton(subject)
            container.addView(btn)
            subjectButtonViews[subject.id] = btn
        }
    }

    private fun createMenuActionButton(
        text: String,
        backgroundRes: Int,
        textColorRes: Int,
        onClick: () -> Unit
    ): TextView {
        return TextView(this).apply {
            this.text = text
            textSize = 13.5f
            isClickable = true
            isFocusable = true
            gravity = Gravity.CENTER
            setBackgroundResource(backgroundRes)
            setTextColor(ContextCompat.getColor(this@MainActivity, textColorRes))
            setPadding(16.dpToPx(), 8.dpToPx(), 16.dpToPx(), 8.dpToPx())
            minHeight = 44.dpToPx()
            contentDescription = text

            val params = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                marginEnd = 8.dpToPx()
            }
            layoutParams = params

            setOnClickListener { onClick() }
        }
    }

    private fun createSubjectButton(subject: Subject): TextView {
        return TextView(this).apply {
            text = subject.displayName
            textSize = 13.5f
            isClickable = true
            isFocusable = true
            gravity = Gravity.CENTER
            setPadding(16.dpToPx(), 8.dpToPx(), 16.dpToPx(), 8.dpToPx())
            minHeight = 44.dpToPx()
            contentDescription = subject.displayName

            val params = LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT,
                ViewGroup.LayoutParams.WRAP_CONTENT
            ).apply {
                marginEnd = 8.dpToPx()
            }
            layoutParams = params

            setOnClickListener {
                loadSubject(subject)
            }
        }
    }

    /**
     * Shows a modal bottom sheet displaying all 17 courses numbered from top to bottom.
     */
    private fun showAllCoursesBottomSheet() {
        val bottomSheet = BottomSheetDialog(this)
        val sheetBinding = DialogAllCoursesBinding.inflate(layoutInflater)
        bottomSheet.setContentView(sheetBinding.root)

        // Make behavior expanded by default
        bottomSheet.behavior.state = BottomSheetBehavior.STATE_EXPANDED
        bottomSheet.behavior.skipCollapsed = true

        sheetBinding.btnCloseAllCourses.setOnClickListener {
            bottomSheet.dismiss()
        }

        val container = sheetBinding.courseListContainer
        container.removeAllViews()

        val currentSelectedId = viewModel.selectedSubjectId.value

        SubjectRepository.subjects.forEach { subject ->
            val itemBinding = ItemCourseListBinding.inflate(
                LayoutInflater.from(this),
                container,
                false
            )

            // Numbering: ১, ২, ৩... ১৭
            itemBinding.tvCourseNumber.text = subject.bengaliNumber
            itemBinding.tvCourseTitle.text = subject.displayName
            itemBinding.tvCourseCategory.text = subject.category

            val isSelected = (subject.id == currentSelectedId)
            if (isSelected) {
                itemBinding.tvActiveBadge.visibility = View.VISIBLE
                itemBinding.root.setBackgroundResource(R.drawable.bg_subject_active)
                itemBinding.tvCourseTitle.setTextColor(
                    ContextCompat.getColor(this, R.color.subject_active_text)
                )
                itemBinding.tvCourseCategory.setTextColor(
                    ContextCompat.getColor(this, R.color.primary_container)
                )
            } else {
                itemBinding.tvActiveBadge.visibility = View.GONE
                itemBinding.root.setBackgroundResource(R.drawable.bg_item_course)
                itemBinding.tvCourseTitle.setTextColor(
                    ContextCompat.getColor(this, R.color.text_primary)
                )
                itemBinding.tvCourseCategory.setTextColor(
                    ContextCompat.getColor(this, R.color.text_secondary)
                )
            }

            itemBinding.root.setOnClickListener {
                bottomSheet.dismiss()
                loadSubject(subject)
            }

            container.addView(itemBinding.root)
        }

        bottomSheet.show()
    }

    private fun loadSubject(subject: Subject) {
        viewModel.selectSubject(subject)
        binding.errorView.visibility = View.GONE
        binding.webView.loadUrl(subject.url)
        scrollToActiveButton(subject.id)
    }

    private fun scrollToActiveButton(subjectId: Int) {
        if (subjectId == 0) {
            binding.subjectScrollView.post {
                binding.subjectScrollView.smoothScrollTo(0, 0)
            }
            return
        }
        val button = subjectButtonViews[subjectId] ?: return
        binding.subjectScrollView.post {
            val scrollX = button.left - (binding.subjectScrollView.width / 2) + (button.width / 2)
            binding.subjectScrollView.smoothScrollTo(scrollX.coerceAtLeast(0), 0)
        }
    }

    private fun updateButtonStyles(activeId: Int) {
        // Handle Home button highlighting
        if (activeId == 0) {
            homeButtonView?.setBackgroundResource(R.drawable.bg_home_button)
            homeButtonView?.elevation = 4f
        } else {
            homeButtonView?.setBackgroundResource(R.drawable.bg_subject_inactive)
            homeButtonView?.setTextColor(ContextCompat.getColor(this, R.color.primary))
            homeButtonView?.elevation = 0f
        }

        // Handle 17 subject buttons
        subjectButtonViews.forEach { (id, button) ->
            if (id == activeId) {
                // Active State: Deep Navy / Royal Blue with crisp white text
                button.setBackgroundResource(R.drawable.bg_subject_active)
                button.setTextColor(ContextCompat.getColor(this, R.color.subject_active_text))
                button.elevation = 4f
            } else {
                // Inactive State: Clean white with subtle border and legible dark blue text
                button.setBackgroundResource(R.drawable.bg_subject_inactive)
                button.setTextColor(ContextCompat.getColor(this, R.color.subject_inactive_text))
                button.elevation = 0f
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    private fun setupWebView() {
        val webView = binding.webView
        val settings = webView.settings

        // 1. JavaScript & Persistent Storage (Crucial for Session & Telegram Web)
        settings.javaScriptEnabled = true
        settings.domStorageEnabled = true
        settings.databaseEnabled = true

        // 2. Cache & Performance (Retain cached sessions)
        settings.cacheMode = WebSettings.LOAD_DEFAULT
        settings.setSupportZoom(true)
        settings.builtInZoomControls = true
        settings.displayZoomControls = false

        // 3. User-Agent Customization:
        // Removing '; wv' and 'Version/4.0' makes Google Sign-In and OAuth treat the WebView as
        // standard Chrome mobile browser. This prevents Google 'disallowed_useragent' errors and
        // ensures authentication cookies and tokens persist indefinitely!
        val defaultUa = settings.userAgentString
        val customUa = defaultUa.replace("; wv", "").replace("Version/4.0 ", "")
        settings.userAgentString = customUa

        // 4. Multi-window / OAuth Popup support
        settings.setSupportMultipleWindows(true)
        settings.javaScriptCanOpenWindowsAutomatically = true

        // 5. Media & HTML5 Video
        settings.mediaPlaybackRequiresUserGesture = false
        settings.loadWithOverviewMode = true
        settings.useWideViewPort = true

        // 6. Global Cookie Management & Third-Party Cookies (Required for cross-domain SSO/OAuth)
        val cookieManager = CookieManager.getInstance()
        cookieManager.setAcceptCookie(true)
        cookieManager.setAcceptThirdPartyCookies(webView, true)

        // Register Native JavaScript Bridge for safe popup detection
        popupDismissHelper?.let { helper ->
            webView.addJavascriptInterface(helper, PopupDismissHelper.INTERFACE_NAME)
        }

        // WebChromeClient: Progress, Fullscreen Video, File Uploads, OAuth Popups, JS Alerts
        webView.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(view: WebView?, newProgress: Int) {
                viewModel.setLoadingProgress(newProgress)
                if (newProgress == 100) {
                    binding.progressBar.visibility = View.GONE
                } else {
                    binding.progressBar.visibility = View.VISIBLE
                    binding.progressBar.progress = newProgress
                }
            }

            override fun onReceivedTitle(view: WebView?, title: String?) {
                super.onReceivedTitle(view, title)
                viewModel.updateNavigationState(webView.canGoBack(), webView.canGoForward())
            }

            // Handles OAuth & Login Popups (Google, Apple, Telegram login modals)
            override fun onCreateWindow(
                view: WebView?,
                isDialog: Boolean,
                isUserGesture: Boolean,
                resultMsg: Message?
            ): Boolean {
                val popupWebView = WebView(this@MainActivity).apply {
                    this.settings.javaScriptEnabled = true
                    this.settings.domStorageEnabled = true
                    this.settings.databaseEnabled = true
                    this.settings.userAgentString = binding.webView.settings.userAgentString
                    CookieManager.getInstance().setAcceptCookie(true)
                    CookieManager.getInstance().setAcceptThirdPartyCookies(this, true)
                }

                val dialog = Dialog(
                    this@MainActivity,
                    android.R.style.Theme_DeviceDefault_Light_NoActionBar_Fullscreen
                ).apply {
                    setContentView(popupWebView)
                }

                popupWebView.webChromeClient = object : WebChromeClient() {
                    override fun onCloseWindow(window: WebView?) {
                        dialog.dismiss()
                        CookieManager.getInstance().flush()
                        binding.webView.reload()
                    }
                }

                popupWebView.webViewClient = object : WebViewClient() {
                    override fun onPageFinished(view: WebView?, url: String?) {
                        CookieManager.getInstance().flush()
                    }

                    override fun shouldOverrideUrlLoading(
                        view: WebView?,
                        request: WebResourceRequest?
                    ): Boolean {
                        val url = request?.url?.toString() ?: return false
                        // Once redirect hits main site domains, close popup and load in main WebView
                        if (url.contains("aparsclassroom.com") ||
                            url.contains("physicsofstupid.com") ||
                            url.contains("telegram.org")
                        ) {
                            dialog.dismiss()
                            CookieManager.getInstance().flush()
                            binding.webView.loadUrl(url)
                            return true
                        }
                        return false
                    }
                }

                dialog.show()

                val transport = resultMsg?.obj as? WebView.WebViewTransport
                transport?.webView = popupWebView
                resultMsg?.sendToTarget()
                return true
            }

            // Fullscreen HTML5 Video playback
            override fun onShowCustomView(view: View?, callback: CustomViewCallback?) {
                if (customVideoView != null) {
                    callback?.onCustomViewHidden()
                    return
                }

                customVideoView = view
                customViewCallback = callback
                originalOrientation = requestedOrientation

                // The fullscreen layer lives on top of the whole window (NOT inside the
                // WebView container) so hiding the page can't hide the video as well.
                val layer = FrameLayout(this@MainActivity).apply {
                    setBackgroundColor(android.graphics.Color.BLACK)
                    addView(
                        view,
                        FrameLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT
                        )
                    )
                }
                fullscreenLayer = layer
                addContentView(
                    layer,
                    ViewGroup.LayoutParams(
                        ViewGroup.LayoutParams.MATCH_PARENT,
                        ViewGroup.LayoutParams.MATCH_PARENT
                    )
                )
                setImmersive(true)

                requestedOrientation = ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE
            }

            override fun onHideCustomView() {
                if (customVideoView == null) return

                fullscreenLayer?.let { layer ->
                    layer.removeAllViews()
                    (layer.parent as? ViewGroup)?.removeView(layer)
                }
                fullscreenLayer = null
                customVideoView = null
                customViewCallback?.onCustomViewHidden()
                customViewCallback = null
                setImmersive(false)

                requestedOrientation = originalOrientation
            }

            // HTML5 File Chooser
            override fun onShowFileChooser(
                webView: WebView?,
                filePathCallback: ValueCallback<Array<Uri>>?,
                fileChooserParams: FileChooserParams?
            ): Boolean {
                fileUploadCallback?.onReceiveValue(null)
                fileUploadCallback = filePathCallback

                val intent = fileChooserParams?.createIntent() ?: Intent(Intent.ACTION_GET_CONTENT).apply {
                    type = "*/*"
                    addCategory(Intent.CATEGORY_OPENABLE)
                }

                return try {
                    fileChooserLauncher.launch(intent)
                    true
                } catch (e: ActivityNotFoundException) {
                    fileUploadCallback = null
                    false
                }
            }

            override fun onJsAlert(view: WebView?, url: String?, message: String?, result: JsResult?): Boolean {
                MaterialAlertDialogBuilder(this@MainActivity)
                    .setTitle(R.string.app_name)
                    .setMessage(message ?: "")
                    .setPositiveButton(android.R.string.ok) { _, _ -> result?.confirm() }
                    .setOnCancelListener { result?.cancel() }
                    .show()
                return true
            }

            override fun onJsConfirm(view: WebView?, url: String?, message: String?, result: JsResult?): Boolean {
                MaterialAlertDialogBuilder(this@MainActivity)
                    .setTitle(R.string.app_name)
                    .setMessage(message ?: "")
                    .setPositiveButton(android.R.string.ok) { _, _ -> result?.confirm() }
                    .setNegativeButton(android.R.string.cancel) { _, _ -> result?.cancel() }
                    .setOnCancelListener { result?.cancel() }
                    .show()
                return true
            }
        }

        // WebViewClient: URL routing, error handling, popup dismissal injection, cookie flush
        webView.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(
                view: WebView?,
                request: WebResourceRequest?
            ): Boolean {
                val url = request?.url?.toString() ?: return false

                // Keep standard web URLs inside the WebView
                if (url.startsWith("http://") || url.startsWith("https://")) {
                    return false
                }

                // Handle external system intents (e.g. tg:, mailto:, tel:, whatsapp:)
                return try {
                    val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url))
                    startActivity(intent)
                    true
                } catch (e: Exception) {
                    false
                }
            }

            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                binding.errorView.visibility = View.GONE
                viewModel.setNetworkError(false)
                CookieManager.getInstance().flush()
                url?.let {
                    viewModel.onUrlLoaded(it)
                }
            }

            override fun onPageFinished(view: WebView?, url: String?) {
                super.onPageFinished(view, url)
                viewModel.setPageFinished()
                // Persist session cookies to disk immediately
                CookieManager.getInstance().flush()
                viewModel.updateNavigationState(webView.canGoBack(), webView.canGoForward())

                url?.let {
                    viewModel.onUrlLoaded(it)
                }

                // Automatically inject and evaluate ACS Desktop Popup Dismissal script
                view?.let {
                    popupDismissHelper?.injectDismissScript(it)
                }
            }

            override fun onReceivedError(
                view: WebView?,
                request: WebResourceRequest?,
                error: WebResourceError?
            ) {
                // Show friendly error view only for main frame failures
                if (request?.isForMainFrame == true) {
                    binding.errorView.visibility = View.VISIBLE
                    viewModel.setNetworkError(true)
                }
            }
        }
    }

    private fun setImmersive(enable: Boolean) {
        val controller = WindowInsetsControllerCompat(window, window.decorView)
        if (enable) {
            controller.systemBarsBehavior =
                WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            controller.hide(WindowInsetsCompat.Type.systemBars())
            if (android.os.Build.VERSION.SDK_INT >= 28) {
                window.attributes = window.attributes.apply {
                    layoutInDisplayCutoutMode =
                        android.view.WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
                }
            }
        } else {
            controller.show(WindowInsetsCompat.Type.systemBars())
            if (android.os.Build.VERSION.SDK_INT >= 28) {
                window.attributes = window.attributes.apply {
                    layoutInDisplayCutoutMode =
                        android.view.WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_DEFAULT
                }
            }
        }
    }

    private fun setupBackNavigation() {
        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                // 1. If fullscreen video is showing, exit fullscreen
                if (customVideoView != null) {
                    binding.webView.webChromeClient?.onHideCustomView()
                    return
                }

                // 2. If WebView can go back, navigate back
                if (binding.webView.canGoBack()) {
                    binding.webView.goBack()
                    return
                }

                // 3. Otherwise show friendly exit confirmation dialog
                showExitConfirmationDialog()
            }
        })
    }

    private fun showExitConfirmationDialog() {
        MaterialAlertDialogBuilder(this)
            .setTitle(R.string.exit_title)
            .setMessage(R.string.exit_message)
            .setPositiveButton(R.string.exit_confirm) { _, _ ->
                finish()
            }
            .setNegativeButton(R.string.exit_cancel, null)
            .show()
    }

    private fun setupErrorRetry() {
        binding.btnRetry.setOnClickListener {
            binding.errorView.visibility = View.GONE
            viewModel.setNetworkError(false)
            val url = viewModel.currentUrl.value.ifBlank { SubjectRepository.DEFAULT_COURSE_URL }
            binding.webView.loadUrl(url)
        }
    }

    private fun observeViewModel() {
        lifecycleScope.launch {
            repeatOnLifecycle(Lifecycle.State.STARTED) {
                launch {
                    viewModel.selectedSubjectId.collect { activeId ->
                        updateButtonStyles(activeId)
                        scrollToActiveButton(activeId)
                    }
                }
                launch {
                    viewModel.canGoBack.collect { canBack ->
                        binding.btnNavBack.alpha = if (canBack) 1.0f else 0.45f
                        binding.btnNavBack.isEnabled = canBack
                    }
                }
                launch {
                    viewModel.canGoForward.collect { canForward ->
                        binding.btnNavForward.alpha = if (canForward) 1.0f else 0.45f
                        binding.btnNavForward.isEnabled = canForward
                    }
                }
                launch {
                    viewModel.loadingProgress.collect { progress ->
                        binding.progressBar.progress = progress
                    }
                }
                launch {
                    viewModel.isNetworkError.collect { isError ->
                        binding.errorView.visibility = if (isError) View.VISIBLE else View.GONE
                    }
                }
            }
        }
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        CookieManager.getInstance().flush()
        binding.webView.saveState(outState)
    }

    override fun onResume() {
        super.onResume()
        // Pick up any changes made in the Admin panel
        setupSubjectNavigationBar()
        updateButtonStyles(viewModel.selectedSubjectId.value)
        binding.webView.onResume()
    }

    override fun onPause() {
        CookieManager.getInstance().flush()
        binding.webView.onPause()
        super.onPause()
    }

    override fun onStop() {
        CookieManager.getInstance().flush()
        super.onStop()
    }

    override fun onDestroy() {
        CookieManager.getInstance().flush()
        if (customVideoView != null) {
            binding.webView.webChromeClient?.onHideCustomView()
        }
        binding.webContentContainer.removeAllViews()
        binding.webView.destroy()
        super.onDestroy()
    }

    private fun Int.dpToPx(): Int {
        val density = resources.displayMetrics.density
        return (this * density).toInt()
    }
}
