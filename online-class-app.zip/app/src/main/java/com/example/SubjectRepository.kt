package com.example

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

object SubjectRepository {

    private const val PREFS = "online_class_buttons"
    private const val KEY_LIST = "subjects_json"
    private var prefs: android.content.SharedPreferences? = null
    private var items: MutableList<Subject> = mutableListOf()

    private val bnDigits = charArrayOf('০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯')
    private fun toBn(n: Int) = n.toString().map { bnDigits[it - '0'] }.joinToString("")

    /** Call once at startup; loads admin-edited buttons (or defaults). */
    fun init(context: Context) {
        if (prefs != null) return
        prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        load()
    }

    private fun load() {
        val raw = prefs?.getString(KEY_LIST, null)
        items = try {
            if (raw == null) defaultSubjects.toMutableList()
            else {
                val arr = JSONArray(raw)
                MutableList(arr.length()) { i ->
                    val o = arr.getJSONObject(i)
                    Subject(
                        id = o.getInt("id"),
                        bengaliNumber = "",
                        displayName = o.getString("name"),
                        url = o.getString("url"),
                        category = o.optString("category", "Custom")
                    )
                }
            }
        } catch (e: Exception) {
            defaultSubjects.toMutableList()
        }
    }

    private fun save() {
        val arr = JSONArray()
        items.forEach {
            arr.put(JSONObject().put("id", it.id).put("name", it.displayName)
                .put("url", it.url).put("category", it.category))
        }
        prefs?.edit()?.putString(KEY_LIST, arr.toString())?.apply()
    }

    /** Current buttons, numbered ১, ২, ৩ … in display order. */
    val subjects: List<Subject>
        get() = items.mapIndexed { i, s -> s.copy(bengaliNumber = toBn(i + 1)) }

    fun add(name: String, url: String) {
        val id = (items.maxOfOrNull { it.id } ?: 0) + 1
        items.add(Subject(id, "", name, url, "Custom"))
        save()
    }

    fun update(id: Int, name: String, url: String) {
        val i = items.indexOfFirst { it.id == id }
        if (i >= 0) { items[i] = items[i].copy(displayName = name, url = url); save() }
    }

    fun remove(id: Int) { items.removeAll { it.id == id }; save() }

    fun move(id: Int, delta: Int) {
        val i = items.indexOfFirst { it.id == id }
        val j = i + delta
        if (i >= 0 && j in items.indices) {
            val t = items[i]; items[i] = items[j]; items[j] = t; save()
        }
    }

    fun resetToDefaults() {
        items = defaultSubjects.toMutableList()
        prefs?.edit()?.remove(KEY_LIST)?.apply()
    }


    const val DEFAULT_COURSE_URL = "https://frb.aparsclassroom.com/course/74c3a47d-69ac-4de1-9314-3c879667996f"

    val homeSubject = Subject(
        id = 0,
        bengaliNumber = "০",
        displayName = "Home",
        url = DEFAULT_COURSE_URL,
        category = "Main Hub",
        isCourseOverview = true
    )

    val defaultSubjects: List<Subject> = listOf(
        Subject(
            id = 1,
            bengaliNumber = "১",
            displayName = "Physics 1st Paper",
            url = "https://frb.aparsclassroom.com/course/74c3a47d-69ac-4de1-9314-3c879667996f/subject/54753903-a094-4a31-9cb7-50c3b472e76c?title=Physics+1st+Paper",
            category = "APAR'S FRB"
        ),
        Subject(
            id = 2,
            bengaliNumber = "২",
            displayName = "Physics 2nd Paper",
            url = "https://frb.aparsclassroom.com/course/74c3a47d-69ac-4de1-9314-3c879667996f/subject/0b348be7-23f3-4a44-9573-384a2d4597f9?title=Physics+2nd+Paper",
            category = "APAR'S FRB"
        ),
        Subject(
            id = 3,
            bengaliNumber = "৩",
            displayName = "Higher Math 1st Paper",
            url = "https://frb.aparsclassroom.com/course/74c3a47d-69ac-4de1-9314-3c879667996f/subject/a49b9a1b-b286-43a0-8b7b-53b8f3edfe71?title=Higher+Math+1st+Paper",
            category = "APAR'S FRB"
        ),
        Subject(
            id = 4,
            bengaliNumber = "৪",
            displayName = "Higher Math 2nd Paper",
            url = "https://frb.aparsclassroom.com/course/74c3a47d-69ac-4de1-9314-3c879667996f/subject/a3219208-758f-417f-ae2e-4d9b104abaad?title=Higher+Math+2nd+Paper",
            category = "APAR'S FRB"
        ),
        Subject(
            id = 5,
            bengaliNumber = "৫",
            displayName = "Chemistry 1st Paper",
            url = "https://frb.aparsclassroom.com/course/74c3a47d-69ac-4de1-9314-3c879667996f/subject/2d1eaea5-f318-4e9e-b1b8-c5ffe25727ff?title=Chemistry+1st+Paper",
            category = "APAR'S FRB"
        ),
        Subject(
            id = 6,
            bengaliNumber = "৬",
            displayName = "Chemistry 2nd Paper",
            url = "https://frb.aparsclassroom.com/course/74c3a47d-69ac-4de1-9314-3c879667996f/subject/960aa782-a774-4b73-8fda-c9c95c314ec6?title=Chemistry+2nd+Paper",
            category = "APAR'S FRB"
        ),
        Subject(
            id = 7,
            bengaliNumber = "৭",
            displayName = "Biology 1st Paper",
            url = "https://frb.aparsclassroom.com/course/74c3a47d-69ac-4de1-9314-3c879667996f/subject/c3b3faff-4878-4061-ad25-80d7c435ca56?title=Biology+1st+Paper",
            category = "APAR'S FRB"
        ),
        Subject(
            id = 8,
            bengaliNumber = "৮",
            displayName = "Biology 2nd Paper",
            url = "https://frb.aparsclassroom.com/course/74c3a47d-69ac-4de1-9314-3c879667996f/subject/333db456-b75e-4c70-82be-809a0730d4c9?title=Biology+2nd+Paper",
            category = "APAR'S FRB"
        ),
        Subject(
            id = 9,
            bengaliNumber = "৯",
            displayName = "English 1st",
            url = "https://frb.aparsclassroom.com/course/74c3a47d-69ac-4de1-9314-3c879667996f/subject/bcb896cf-a006-4bd8-8ad7-d5e92ffa59b9/classes/6a75946a-77e8-47db-8007-4186d4769bfe?title=English+1st+Paper",
            category = "APAR'S FRB"
        ),
        Subject(
            id = 10,
            bengaliNumber = "১০",
            displayName = "English 2nd",
            url = "https://frb.aparsclassroom.com/course/74c3a47d-69ac-4de1-9314-3c879667996f/subject/bcb896cf-a006-4bd8-8ad7-d5e92ffa59b9/classes/988d47df-ee40-4225-b4d1-19d7e12e7b7b?title=English+2nd+Paper",
            category = "APAR'S FRB"
        ),
        Subject(
            id = 11,
            bengaliNumber = "১১",
            displayName = "বাংলা ১ম",
            url = "https://frb.aparsclassroom.com/course/74c3a47d-69ac-4de1-9314-3c879667996f/subject/be81db09-cbd2-4b65-92d2-d1496be0aebf/classes/9bb80783-6578-4480-92c9-3b0c38348f59?title=%E0%A6%AC%E0%A6%BE%E0%A6%82%E0%A6%B2%E0%A6%BE++%E0%A6%AA%E0%A7%8D%E0%A6%B0%E0%A6%A5%E0%A6%AE+%E0%A6%AA%E0%A6%A4%E0%A7%8D%E0%A6%B0+",
            category = "APAR'S FRB",
            isBengali = true
        ),
        Subject(
            id = 12,
            bengaliNumber = "১২",
            displayName = "বাংলা ২য় পত্র",
            url = "https://frb.aparsclassroom.com/course/74c3a47d-69ac-4de1-9314-3c879667996f/subject/be81db09-cbd2-4b65-92d2-d1496be0aebf/classes/31c2ab58-57e9-4755-ae7b-b82607c517c6?title=%E0%A6%AC%E0%A6%BE%E0%A6%82%E0%A6%B2%E0%A6%BE+%E0%A6%A6%E0%A7%8D%E0%A6%AC%E0%A6%BF%E0%A6%A4%E0%A7%80%E0%A7%9F+%E0%A6%AA%E0%A6%A4%E0%A7%8D%E0%A6%B0+",
            category = "APAR'S FRB",
            isBengali = true
        ),
        Subject(
            id = 13,
            bengaliNumber = "১৩",
            displayName = "তথ্য ও যোগাযোগ প্রযুক্তি",
            url = "https://frb.aparsclassroom.com/course/74c3a47d-69ac-4de1-9314-3c879667996f/subject/4f2c48d8-e4cf-48e9-8711-01e023e17cbe?title=%E0%A6%A4%E0%A6%A5%E0%A7%8D%E0%A6%AF+%E0%A6%93+%E0%A6%AF%E0%A7%8B%E0%A6%97%E0%A6%BE%E0%A6%AF%E0%A7%8B%E0%A6%97+%E0%A6%AA%E0%A7%8D%E0%A6%B0%E0%A6%AF%E0%A7%81%E0%A6%95%E0%A7%8D%E0%A6%A4%E0%A6%BF+",
            category = "APAR'S FRB",
            isBengali = true
        ),
        Subject(
            id = 14,
            bengaliNumber = "১৪",
            displayName = "ACS English 2nd",
            url = "https://academic.aparsclassroom.com/course/b0ce59dd-09cf-498d-b99f-350fcbcb93bf/subject/e522d020-757a-44d3-b5b1-61731b981453/chapter/a6a3fc28-4be0-4422-8ad3-cb36b84dcae5?title=English+2nd+Paper",
            category = "ACS Academic"
        ),
        Subject(
            id = 15,
            bengaliNumber = "১৫",
            displayName = "PhysicsofStupid 1st",
            url = "https://physicsofstupid.com/dashboard/my-courses/hsc-physics-recorded-1st-2nd-paper/phy101/paper-1",
            category = "Physics of Stupid"
        ),
        Subject(
            id = 16,
            bengaliNumber = "১৬",
            displayName = "PhysicsofStupid 2nd",
            url = "https://physicsofstupid.com/dashboard/my-courses/hsc-physics-recorded-1st-2nd-paper/phy101/paper-2",
            category = "Physics of Stupid"
        ),
        Subject(
            id = 17,
            bengaliNumber = "১৭",
            displayName = "Telegram web app",
            url = "https://web.telegram.org/k/",
            category = "Communication"
        )
    )

    fun findSubjectByUrl(url: String): Subject? {
        val cleanUrl = url.trimEnd('/')
        return items.firstOrNull {
            val base = it.url.split('?').first().trimEnd('/')
            base.isNotEmpty() && (cleanUrl == it.url.trimEnd('/') || cleanUrl.startsWith(base))
        }
    }
}
