package com.example

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.VideoView
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

/** Plays the intro video, then opens MainActivity. */
class SplashActivity : AppCompatActivity() {

    private var done = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        WindowCompat.setDecorFitsSystemWindows(window, false)
        WindowInsetsControllerCompat(window, window.decorView).apply {
            systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            hide(WindowInsetsCompat.Type.systemBars())
        }

        val video = findViewById<VideoView>(R.id.splashVideo)
        video.setVideoURI(Uri.parse("android.resource://$packageName/${R.raw.splash_video}"))
        video.setOnCompletionListener { goNext() }
        video.setOnErrorListener { _, _, _ -> goNext(); true }
        video.setOnClickListener { goNext() } // tap to skip
        video.start()

        // Safety net in case the video never reports completion.
        video.postDelayed({ goNext() }, 6000)
    }

    private fun goNext() {
        if (done) return
        done = true
        startActivity(Intent(this, MainActivity::class.java))
        finish()
        @Suppress("DEPRECATION")
        overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
    }
}
