package com.example

/**
 * Model representing a course subject in Online Class.
 *
 * @param id Unique subject identifier (0 for Home / Course Overview, 1..17 for subjects)
 * @param bengaliNumber Bengali numeral string (১, ২, ৩... ১৭)
 * @param displayName Name displayed on the native navigation button and course list
 * @param url The exact web URL to load in the WebView
 * @param category Platform / course group indicator
 * @param isBengali Whether the display name is in Bengali script
 * @param isCourseOverview True if this represents the main course overview
 */
data class Subject(
    val id: Int,
    val bengaliNumber: String,
    val displayName: String,
    val url: String,
    val category: String = "APAR'S FRB",
    val isBengali: Boolean = false,
    val isCourseOverview: Boolean = false
)
