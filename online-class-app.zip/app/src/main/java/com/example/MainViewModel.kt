package com.example

import androidx.lifecycle.ViewModel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class MainViewModel : ViewModel() {

    private val _selectedSubjectId = MutableStateFlow(0)
    val selectedSubjectId: StateFlow<Int> = _selectedSubjectId.asStateFlow()

    private val _currentUrl = MutableStateFlow(SubjectRepository.DEFAULT_COURSE_URL)
    val currentUrl: StateFlow<String> = _currentUrl.asStateFlow()

    private val _isLoading = MutableStateFlow(true)
    val isLoading: StateFlow<Boolean> = _isLoading.asStateFlow()

    private val _loadingProgress = MutableStateFlow(0)
    val loadingProgress: StateFlow<Int> = _loadingProgress.asStateFlow()

    private val _isNetworkError = MutableStateFlow(false)
    val isNetworkError: StateFlow<Boolean> = _isNetworkError.asStateFlow()

    private val _canGoBack = MutableStateFlow(false)
    val canGoBack: StateFlow<Boolean> = _canGoBack.asStateFlow()

    private val _canGoForward = MutableStateFlow(false)
    val canGoForward: StateFlow<Boolean> = _canGoForward.asStateFlow()

    fun selectSubject(subject: Subject) {
        _selectedSubjectId.value = subject.id
        _currentUrl.value = subject.url
        _isNetworkError.value = false
    }

    fun onUrlLoaded(url: String) {
        _currentUrl.value = url
        // Automatically match active subject button if url belongs to one of the 13 subjects
        val match = SubjectRepository.findSubjectByUrl(url)
        if (match != null) {
            _selectedSubjectId.value = match.id
        } else if (url.contains("/course/74c3a47d-69ac-4de1-9314-3c879667996f") && !url.contains("/subject/")) {
            _selectedSubjectId.value = 0
        }
    }

    fun setLoadingProgress(progress: Int) {
        _loadingProgress.value = progress
        _isLoading.value = progress in 1..99
    }

    fun setPageFinished() {
        _isLoading.value = false
        _loadingProgress.value = 100
    }

    fun setNetworkError(isError: Boolean) {
        _isNetworkError.value = isError
    }

    fun updateNavigationState(canBack: Boolean, canForward: Boolean) {
        _canGoBack.value = canBack
        _canGoForward.value = canForward
    }
}
