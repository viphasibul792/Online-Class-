package com.example

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test

class ExampleUnitTest {

  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }

  @Test
  fun verifySubjectRepositoryContains17Subjects() {
    assertEquals(17, SubjectRepository.subjects.size)
    assertEquals(
      "https://frb.aparsclassroom.com/course/74c3a47d-69ac-4de1-9314-3c879667996f",
      SubjectRepository.DEFAULT_COURSE_URL
    )

    SubjectRepository.subjects.forEach { subject ->
      assertTrue("Subject ${subject.displayName} has invalid ID", subject.id in 1..17)
      assertTrue("Subject ${subject.displayName} has empty URL", subject.url.isNotBlank())
      assertTrue("Subject ${subject.displayName} URL should be HTTPS", subject.url.startsWith("https://"))
      assertTrue("Subject ${subject.displayName} has empty Bengali number", subject.bengaliNumber.isNotBlank())
    }
  }

  @Test
  fun verifyExactSubjectNamesAndUrls() {
    val physics1 = SubjectRepository.subjects.first { it.id == 1 }
    assertEquals("Physics 1st Paper", physics1.displayName)
    assertEquals("১", physics1.bengaliNumber)
    assertTrue(physics1.url.contains("54753903-a094-4a31-9cb7-50c3b472e76c"))

    val ict = SubjectRepository.subjects.first { it.id == 13 }
    assertEquals("তথ্য ও যোগাযোগ প্রযুক্তি", ict.displayName)
    assertEquals("১৩", ict.bengaliNumber)
    assertTrue(ict.url.contains("4f2c48d8-e4cf-48e9-8711-01e023e17cbe"))

    // 4 newly added subjects
    val acsEng = SubjectRepository.subjects.first { it.id == 14 }
    assertEquals("ACS English 2nd", acsEng.displayName)
    assertEquals("১৪", acsEng.bengaliNumber)
    assertEquals("https://academic.aparsclassroom.com/course/b0ce59dd-09cf-498d-b99f-350fcbcb93bf/subject/e522d020-757a-44d3-b5b1-61731b981453/chapter/a6a3fc28-4be0-4422-8ad3-cb36b84dcae5?title=English+2nd+Paper", acsEng.url)

    val pos1 = SubjectRepository.subjects.first { it.id == 15 }
    assertEquals("PhysicsofStupid 1st", pos1.displayName)
    assertEquals("১৫", pos1.bengaliNumber)
    assertEquals("https://physicsofstupid.com/dashboard/my-courses/hsc-physics-recorded-1st-2nd-paper/phy101/paper-1", pos1.url)

    val pos2 = SubjectRepository.subjects.first { it.id == 16 }
    assertEquals("PhysicsofStupid 2nd", pos2.displayName)
    assertEquals("১৬", pos2.bengaliNumber)
    assertEquals("https://physicsofstupid.com/dashboard/my-courses/hsc-physics-recorded-1st-2nd-paper/phy101/paper-2", pos2.url)

    val telegram = SubjectRepository.subjects.first { it.id == 17 }
    assertEquals("Telegram web app", telegram.displayName)
    assertEquals("১৭", telegram.bengaliNumber)
    assertEquals("https://web.telegram.org/k/", telegram.url)
  }

  @Test
  fun verifyHomeSubject() {
    val home = SubjectRepository.homeSubject
    assertEquals(0, home.id)
    assertEquals("Home", home.displayName)
    assertEquals(SubjectRepository.DEFAULT_COURSE_URL, home.url)
  }

  @Test
  fun verifyPopupDismissKeywords() {
    val payload = PopupDismissHelper.JS_DISMISS_PAYLOAD
    assertTrue(payload.contains("ACS is now on Desktop"))
    assertTrue(payload.contains("New · Desktop app"))
    assertTrue(payload.contains("MutationObserver"))
  }

  @Test
  fun verifyViewModelSubjectSelection() {
    val viewModel = MainViewModel()
    val telegram = SubjectRepository.subjects.first { it.id == 17 }
    viewModel.selectSubject(telegram)
    assertEquals(17, viewModel.selectedSubjectId.value)
    assertEquals(telegram.url, viewModel.currentUrl.value)
  }
}
